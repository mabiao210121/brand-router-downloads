#!/bin/sh
set -eu
umask 077
BUNDLE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
MODE=${1:-check}
ROOT_PREFIX=
if [ "${BRAND_LAB_MODE:-0}" = 1 ]; then
    [ "$(hostname)" = lima-brand-router-lab ] || { echo 'lab_mode_requires_dedicated_vm' >&2; exit 1; }
    ROOT_PREFIX=${BRAND_LAB_ROOT:?lab_root_required}
    case "$ROOT_PREFIX" in /tmp/brand-install-lab-* ) ;; *) echo 'invalid_lab_root' >&2; exit 1;; esac
fi
STATE="$ROOT_PREFIX/root/brand-router-backups"
LOCK="$ROOT_PREFIX/var/lock/brand-router-install"
RESERVE_KIB=2097152
BACKUP_LIMIT_KIB=65536

fail() { echo "$1" >&2; exit 1; }
target_path_check() {
    parent="$ROOT_PREFIX"
    remaining=$1
    while [ -n "$remaining" ]; do
        component=${remaining%%/*}
        parent="$parent/$component"
        [ ! -L "$parent" ] || fail target_symlink_refused
        case "$remaining" in */*) remaining=${remaining#*/};; *) remaining=;; esac
    done
}
validate_paths() {
    target_path_check root/brand-router-backups
    [ -f "$BUNDLE/files.list" ] && [ ! -L "$BUNDLE/files.list" ] || fail invalid_file_list
    awk 'NF!=2 || seen[$2]++ {exit 1} END {if(NR<1 || NR>64) exit 1}' "$BUNDLE/files.list" || fail invalid_file_list
    while read -r permission relative; do
        case "$permission" in 644|755) ;; *) fail invalid_file_mode;; esac
        case "$relative" in /*|*..*|*//*|*\\*) fail invalid_payload_path;; esac
        case "$relative" in
            www/cgi-bin/brand-entry|www/brand-entry.html|www/brand-entry.js|usr/libexec/brand-network-repair|etc/init.d/brand-network-repair|usr/libexec/brand-tailscale-worker|usr/libexec/brand-assist-worker|etc/init.d/brand-assist|usr/libexec/brand-update-worker|usr/share/brand-router/build.json|usr/lib/lua/brand_router/*.lua|usr/libexec/brand-router|usr/libexec/brand-router-watchdog|usr/libexec/brand-service-gate|usr/libexec/brand-portal-handler|etc/init.d/brand-license|etc/init.d/brand-fixed|etc/init.d/brand-portal|usr/libexec/rpcd/brand.router|usr/share/rpcd/acl.d/luci-app-brand-router.json|usr/share/rpcd/acl.d/brand-router-customer.json|usr/share/luci/menu.d/luci-app-brand-router.json|www/luci-static/resources/view/brand-router/activation.js|www/brand-router/index.html|www/brand-router/portal.js|www/brand-router/telemetry.js|www/brand-router/portal.css) ;;
            *) fail unmanaged_payload_path;;
        esac
        [ -f "$BUNDLE/payload/$relative" ] && [ ! -L "$BUNDLE/payload/$relative" ] || fail invalid_payload_file
        target_path_check "$relative"
    done < "$BUNDLE/files.list"
    (cd "$BUNDLE" && sha256sum -c checksums.sha256 >/dev/null) || fail candidate_checksum_failed
}
firmware_check() {
    release="$ROOT_PREFIX/etc/openwrt_release"
    [ -f "$release" ] || fail unsupported_firmware
    # Do not source firmware or bundle text as shell code.
    grep -Eq "^DISTRIB_ID=['\"]?iStoreOS['\"]?$" "$release" || fail istoreos_required
    grep -Eq "^DISTRIB_RELEASE=['\"]?24\.10([.][0-9]+)?[^[:space:]]*" "$release" || fail unsupported_firmware_release
    architecture=$(uname -m)
    [ "${BRAND_LAB_MODE:-0}" != 1 ] || architecture=${BRAND_LAB_ARCH:-$architecture}
    [ "$architecture" = x86_64 ] || fail unsupported_cpu_architecture
    command -v opkg >/dev/null || fail opkg_required
    [ -f "$ROOT_PREFIX/etc/opkg.conf" ] || fail signed_feeds_required
    awk '$1=="option" && $2=="check_signature" {found=1; if($3!="" && $3!="1" && substr($3,1,1)!="#") bad=1} END {exit !found || bad}' "$ROOT_PREFIX/etc/opkg.conf" || fail signed_feeds_required
    memory=$(awk '/MemTotal:/ {print int($2/1024)}' /proc/meminfo)
    storage_path="$ROOT_PREFIX/overlay"
    [ -d "$storage_path" ] || storage_path="${ROOT_PREFIX:-/}"
    storage=$(df -kP "$storage_path" | awk 'NR==2 {print int($2/1024)}')
    # Allow firmware-reserved RAM on nominal 4GiB machines (verified J4125:
    # 4096MiB installed, 3510MiB visible). Do not accept 3GiB machines.
    [ "$memory" -ge 3328 ] || fail 'visible_memory_below_3328_mib'
    [ "$storage" -ge 13500 ] || fail 'writable_partition_below_13500_mib_expand_overlay_first'
    available_memory=$(awk '/MemAvailable:/ {print int($2/1024)}' /proc/meminfo)
    available_storage=$(df -kP "$storage_path" | awk 'NR==2 {print int($4/1024)}')
    [ "${available_memory:-0}" -ge 512 ] && [ "$available_storage" -ge 2048 ] || fail installation_headroom_required
}
storage_check() {
    # Keep recovery bounded without deleting an owner's existing backup.
    # du counts allocated blocks; include directory/manifest overhead and both
    # the old-file backup and the new payload even when updates overwrite files.
    backup_needed=1024
    while read -r permission relative; do
        if [ -e "$ROOT_PREFIX/$relative" ]; then
            [ -f "$ROOT_PREFIX/$relative" ] || fail target_must_be_regular_file
            size=$(du -k "$ROOT_PREFIX/$relative" | awk '{print $1}')
            backup_needed=$((backup_needed + size))
        fi
    done < "$BUNDLE/files.list"
    backup_used=0
    [ ! -d "$STATE" ] || backup_used=$(du -sk "$STATE" | awk '{print $1}')
    [ "$((backup_used + backup_needed))" -le "$BACKUP_LIMIT_KIB" ] || fail backup_capacity_exceeded
    payload_size=$(du -sk "$BUNDLE/payload" | awk '{print $1}')
    free=$(df -kP "$storage_path" | awk 'NR==2 {print $4}')
    [ "$free" -ge "$((RESERVE_KIB + backup_needed + payload_size))" ] || fail installation_headroom_required
}
rollback_storage_check() {
    storage_path="$ROOT_PREFIX/overlay"
    [ -d "$storage_path" ] || storage_path="${ROOT_PREFIX:-/}"
    restore_size=1024
    [ ! -d "$1/before" ] || restore_size=$((restore_size + $(du -sk "$1/before" | awk '{print $1}')))
    free=$(df -kP "$storage_path" | awk 'NR==2 {print $4}')
    [ "$free" -ge "$((RESERVE_KIB + restore_size))" ] || fail rollback_headroom_required
}
missing_packages() {
    installed=$(opkg list-installed)
    for package in curl ca-bundle lua openssl-util luci-lib-jsonc luci-lib-nixio rpcd luci-base nftables-json uhttpd uhttpd-mod-lua libubus-lua xray-core sing-box kmod-nft-tproxy avahi-dbus-daemon avahi-utils; do
        printf '%s\n' "$installed" | awk -v p="$package" '$1==p {found=1} END {exit !found}' || printf '%s\n' "$package"
    done
}
rpc_files_changed() {
    for relative in usr/libexec/rpcd/brand.router usr/share/rpcd/acl.d/luci-app-brand-router.json usr/share/rpcd/acl.d/brand-router-customer.json; do
        [ -f "$backup/before/$relative" ] && [ -f "$ROOT_PREFIX/$relative" ] || return 0
        cmp -s "$backup/before/$relative" "$ROOT_PREFIX/$relative" || return 0
    done
    return 1
}
reload_rpc() {
    # Preserve existing customer sessions when RPC service and ACL are unchanged.
    [ "${RPC_CHANGED:-0}" = 1 ] || rpc_files_changed || return 0
    [ ! -x "$ROOT_PREFIX/etc/init.d/rpcd" ] || "$ROOT_PREFIX/etc/init.d/rpcd" reload >/dev/null 2>&1 || true
}
runtime_check() {
    # Fake-filesystem lab deliberately does not claim installed package/ABI acceptance.
    [ "${BRAND_LAB_MODE:-0}" != 1 ] || return 0
    lua -e "require('luci.jsonc');require('nixio.fs');require('ubus');require('brand_router.license');require('brand_router.portal')" || fail lua_runtime_probe_failed
    probe=$(mktemp -d /tmp/brand-router-probe.XXXXXX) || fail private_probe_directory_failed
    if printf 'brand-runtime-probe' > "$probe/message" &&
        openssl genpkey -algorithm ED25519 -out "$probe/key" >/dev/null 2>&1 &&
        openssl pkey -in "$probe/key" -pubout -out "$probe/public" >/dev/null 2>&1 &&
        openssl pkeyutl -sign -rawin -inkey "$probe/key" -in "$probe/message" -out "$probe/signature" >/dev/null 2>&1 &&
        openssl pkeyutl -verify -rawin -pubin -inkey "$probe/public" -in "$probe/message" -sigfile "$probe/signature" >/dev/null 2>&1; then
        verified=1
    else verified=0; fi
    rm -f "$probe/message" "$probe/key" "$probe/public" "$probe/signature"
    rmdir "$probe"
    [ "$verified" = 1 ] || fail ed25519_runtime_probe_failed
}
stop_assist() {
    # Filesystem-only fixtures do not provide OpenWrt procd/rc.common.
    [ "${BRAND_LAB_MODE:-0}" != 1 ] || return 0
    if [ -x "$ROOT_PREFIX/usr/libexec/brand-assist-worker" ]; then
        # Use the validated candidate shutdown implementation, not an older
        # installed worker which may be the very bug this update repairs.
        LUA_PATH="$BUNDLE/payload/usr/lib/lua/?.lua;;" lua -e "assert(require('brand_router.tailscale_assist').stop({}), 'assist_stop_failed')" >/dev/null 2>&1 || fail assist_stop_failed
    fi
}
restore() {
    backup=$1
    if rpc_files_changed; then RPC_CHANGED=1; fi
    stop_assist
    if [ "${BRAND_LAB_MODE:-0}" != 1 ] && [ -f "$backup/absent/www/brand-entry.html" ]; then
        LUA_PATH="$BUNDLE/payload/usr/lib/lua/?.lua;;" lua -e "require('brand_router.local_entry').remove()" || fail entry_restore_failed
    fi
    if [ -f "$backup/fixed-control/complete" ]; then
        "$ROOT_PREFIX/etc/init.d/brand-license" stop >/dev/null 2>&1 || true
        "$ROOT_PREFIX/etc/init.d/brand-fixed" stop >/dev/null 2>&1 || true
    fi
    while read -r permission relative; do
        if [ -f "$backup/before/$relative" ]; then
            mkdir -p "$(dirname "$ROOT_PREFIX/$relative")"
            cp -p "$backup/before/$relative" "$ROOT_PREFIX/$relative"
        elif [ -f "$backup/absent/$relative" ]; then
            rm -f "$ROOT_PREFIX/$relative"
        fi
    done < "$backup/files.list"
    reload_rpc
    if [ -f "$backup/fixed-control/complete" ]; then
        for name in current.json previous.json failure.nft; do
            target_path_check "etc/brand-router/fixed/$name"
            if [ -f "$backup/fixed-control/$name" ]; then
                cp -p "$backup/fixed-control/$name" "$ROOT_PREFIX/etc/brand-router/fixed/$name.restore"
                mv -f "$ROOT_PREFIX/etc/brand-router/fixed/$name.restore" "$ROOT_PREFIX/etc/brand-router/fixed/$name"
            else
                rm -f "$ROOT_PREFIX/etc/brand-router/fixed/$name"
            fi
        done
        "$ROOT_PREFIX/etc/init.d/brand-license" start >/dev/null 2>&1 || true
        "$ROOT_PREFIX/etc/init.d/brand-fixed" start >/dev/null 2>&1 || true
    fi
}
backup_fixed_runtime() {
    [ -f "$ROOT_PREFIX/etc/brand-router/fixed/current.json" ] || return 0
    mkdir "$backup/fixed-control"
    for name in current.json previous.json failure.nft; do
        target_path_check "etc/brand-router/fixed/$name"
        [ ! -f "$ROOT_PREFIX/etc/brand-router/fixed/$name" ] || cp -p "$ROOT_PREFIX/etc/brand-router/fixed/$name" "$backup/fixed-control/$name"
    done
    : > "$backup/fixed-control/complete"
}
refresh_fixed_runtime() {
    # An already-enabled runtime must use the newly installed DNS compiler.
    # This never enables bindings on a fresh installation.
    [ -f "$ROOT_PREFIX/etc/brand-router/fixed/current.json" ] || return 0
    lua "$ROOT_PREFIX/usr/libexec/brand-router" fixed-refresh || fail fixed_runtime_refresh_failed
}
rollback_check() {
    while read -r expected relative; do
        target_path_check "$relative"
        [ -f "$ROOT_PREFIX/$relative" ] || fail rollback_target_changed
        actual=$(sha256sum "$ROOT_PREFIX/$relative")
        [ "${actual%% *}" = "$expected" ] || fail rollback_target_changed
    done < "$1/installed.sha256"
}
files_current() {
    while read -r permission relative; do
        [ -f "$ROOT_PREFIX/$relative" ] || return 1
        expected=$(sha256sum "$BUNDLE/payload/$relative")
        actual=$(sha256sum "$ROOT_PREFIX/$relative")
        [ "${expected%% *}" = "${actual%% *}" ] || return 1
        [ "$(stat -c %a "$ROOT_PREFIX/$relative")" = "$permission" ] || return 1
    done < "$BUNDLE/files.list"
}
validate_paths
case "$MODE" in
    check|plan)
        firmware_check
        if ! files_current; then storage_check; fi
        echo 'Compatible baseline and candidate checksums verified; this does not enable enforcement.'
        echo 'Missing basic packages:'
        missing_packages
        echo 'No router network, DHCP, license state or business service changed.'
        exit 0;;
    apply)
        [ "$(id -u)" = 0 ] || fail root_required
        firmware_check
        if ! files_current; then storage_check; fi;;
    rollback)
        [ "$(id -u)" = 0 ] || fail root_required
        backup_id=${2:?backup_id_required}
        case "$backup_id" in *[!0-9T-]*|'') fail invalid_backup_id;; esac
        [ -f "$STATE/$backup_id/files.list" ] && [ -f "$STATE/$backup_id/installed.sha256" ] && [ -f "$STATE/$backup_id/complete" ] || fail backup_not_found
        rollback_check "$STATE/$backup_id";;
    *) fail use_check_plan_apply_or_rollback;;
esac
mkdir -p "$(dirname "$LOCK")" "$STATE"
chmod 700 "$STATE"
mkdir "$LOCK" 2>/dev/null || fail installation_busy
backup=
temporary=
probe=
committed=0
cleanup() {
    status=$?
    trap - EXIT INT TERM
    [ -z "$temporary" ] || rm -f "$temporary"
    if [ -n "$probe" ] && [ -d "$probe" ]; then
        rm -f "$probe/message" "$probe/key" "$probe/public" "$probe/signature"
        rmdir "$probe" 2>/dev/null || true
    fi
    if [ "$status" != 0 ] && [ -n "$backup" ] && [ "$committed" = 0 ]; then
        # A restore failure must not exit this cleanup before releasing the lock.
        set +e
        (set -e; restore "$backup")
        restore_status=$?
        [ "$restore_status" = 0 ] || echo 'rollback_failed: backup retained for recovery' >&2
    fi
    rmdir "$LOCK" 2>/dev/null || true
    exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
if [ "$MODE" = rollback ]; then
    rollback_storage_check "$STATE/$backup_id"
    restore "$STATE/$backup_id"
    committed=1
    echo 'Brand application files restored; installed shared dependencies were retained.'
    exit 0
fi
missing=$(missing_packages)
if [ -z "$missing" ] && files_current; then
    runtime_check
    committed=1
    echo 'Brand application already current; no file rewrite, dependency installation or rpcd reload.'
    exit 0
fi
if [ -n "$missing" ]; then
    # No force flags or whole-system upgrades. opkg enforces available package/kernel dependencies.
    opkg update
    set -- $missing
    opkg --noaction install "$@"
    opkg install "$@"
fi
# Dependencies can consume disk/memory after the initial plan. Recheck before
# writing any application files or creating another rollback snapshot.
firmware_check
storage_check
backup_id=${BRAND_UPDATE_BACKUP_ID:-$(date -u +%Y%m%dT%H%M%S)-$$}
case "$backup_id" in *[!0-9T-]*|'') fail invalid_backup_id;; esac
[ ${#backup_id} -le 64 ] || fail invalid_backup_id
mkdir "$STATE/$backup_id"
backup="$STATE/$backup_id"
cp "$BUNDLE/files.list" "$backup/files.list"
while read -r permission relative; do
    if [ -e "$ROOT_PREFIX/$relative" ]; then
        [ -f "$ROOT_PREFIX/$relative" ] || fail target_must_be_regular_file
        mkdir -p "$(dirname "$backup/before/$relative")"
        cp -p "$ROOT_PREFIX/$relative" "$backup/before/$relative"
    else
        mkdir -p "$(dirname "$backup/absent/$relative")"
        : > "$backup/absent/$relative"
    fi
done < "$BUNDLE/files.list"
backup_fixed_runtime
stop_assist
while read -r permission relative; do
    mkdir -p "$(dirname "$ROOT_PREFIX/$relative")"
    temporary="$ROOT_PREFIX/$relative.brand-install-$$"
    cp "$BUNDLE/payload/$relative" "$temporary"
    chmod "$permission" "$temporary"
    mv -f "$temporary" "$ROOT_PREFIX/$relative"
    temporary=
    actual=$(sha256sum "$ROOT_PREFIX/$relative")
    printf '%s %s\n' "${actual%% *}" "$relative" >> "$backup/installed.sha256"
done < "$BUNDLE/files.list"
runtime_check
reload_rpc
refresh_fixed_runtime
: > "$backup/complete"
committed=1
echo "Installed experimental brand application. Rollback ID: $backup_id"
echo 'Enforcement remains disabled; keys, license state, site configuration and existing business were preserved.'
