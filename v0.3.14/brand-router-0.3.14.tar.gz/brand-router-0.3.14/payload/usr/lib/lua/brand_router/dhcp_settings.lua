-- DHCP settings and pure capacity planning; LAN changes use the repair transaction.
local util=require 'brand_router.util'
local M={}
local function number(ip)
    if type(ip)~='string' or not ip:match('^%d+%.%d+%.%d+%.%d+$') then return end
    local n=0;for x in ip:gmatch('%d+') do x=tonumber(x);if x>255 then return end;n=n*256+x end;return n
end
local function address(n)
    return math.floor(n/16777216)..'.'..math.floor(n/65536)%256 ..'.'..math.floor(n/256)%256 ..'.'..n%256
end
local function subnet(ip,mask)
    local n,m=number(ip),number(mask);if not n or not m then return end
    for prefix=16,24 do local size=2^(32-prefix);if m==4294967296-size then return math.floor(n/size)*size,size,prefix,n end end
end
function M.plan(v)
    local p={supported=false,message='此网络需要管理员配置，未修改网络。'}
    local base,size,bits,host=subnet(v.ip,v.mask)
    local start,limit=tonumber(v.start),tonumber(v.limit)
    if not v.simple or not base or not start or not limit or start%1~=0 or limit%1~=0 or start<1 or limit<1 or start+limit-1>size-2 then return p end
    host=host-base;if host>=start and host<start+limit then return p end
    local n,unit=(v.leasetime or ''):match('^(%d+)([mhd])$');n=tonumber(n)
    local minutes=n and n*({m=1,h=60,d=1440})[unit] or nil
    if not minutes then return p end
    local last=start+limit-1;local maximum=host>=start and host-1 or size-2
    local used=0;local seen={}
    for line in (v.leases or ''):gmatch('[^\n]+') do
        local expiry,ip=line:match('^(%d+)%s+[%x:]+%s+(%d+%.%d+%.%d+%.%d+)%s')
        local num=number(ip)
        if num and num>=base+start and num<=base+last and (tonumber(expiry)==0 or tonumber(expiry)>v.now) and not seen[ip] then used=used+1;seen[ip]=true end
    end
    return {supported=true,minutes=minutes,subnet=address(base)..'/'..bits,start=address(base+start),finish=address(base+last),total=limit,used=used,remaining=limit-used,
        expandable=maximum>last,expanded_finish=address(base+maximum),expanded_total=maximum-start+1,fingerprint=v.fingerprint,
        message='当前网段内扩充只扩大可发放范围；跨网段请使用下方容量规划。'}
end
-- Capacity is planned against a server-collected inventory, not client-supplied routes.
function M.capacity(v,input)
    local no={state='manual',message='当前网络需要管理员检查，未修改配置。'}
    if not v.simple or not v.snapshot or not v.snapshot.available or v.portal_ip~=v.ip or not v.device then return no end
    local base,size,bits,old=subnet(v.ip,v.mask)
    local start,limit=tonumber(v.start),tonumber(v.limit)
    if not base or not start or not limit or start<1 or limit<1 or start%1~=0 or limit%1~=0 or start+limit>size-1 then return no end
    if old>=base+start and old<base+start+limit then return no end
    local total=input.total
    assert(type(total)=='number' and total%1==0 and total>=256 and total<=60000,'capacity_invalid_total')
    assert(input.mode=='auto' or input.mode=='custom','capacity_invalid_mode')
    local first=base+start
    if input.mode=='custom' then
        local raw=input.start_subnet
        assert(type(raw)=='string','capacity_invalid_start')
        if raw:match('^%d+%.%d+%.%d+$') then raw=raw..'.0' end
        raw=raw:gsub('/24$','')
        local n=number(raw);assert(n and n%256==0,'capacity_invalid_start');first=n+100
    end
    local last=first+total-1
    local chosen,block,prefix
    for b=24,16,-1 do
        local z=2^(32-b);local a=math.floor(first/z)*z
        if last<a+z-1 and (input.mode~='auto' or a<=base and a+z>=base+size and total>=limit) then chosen,block,prefix=a,z,b;break end
    end
    assert(chosen,'capacity_out_of_range')
    local private=false
    for _,r in ipairs({{167772160,184549375},{2886729728,2887778303},{3232235520,3232301055}}) do
        if chosen>=r[1] and chosen+block-1<=r[2] then private=true end
    end
    assert(private,'capacity_private_required')
    local gateway=(old>chosen and old<chosen+block-1 and (old<first or old>last)) and old or chosen+1
    assert(gateway<first or gateway>last,'capacity_gateway_overlap')
    local others={available=true,networks={}}
    for _,n in ipairs(v.snapshot.networks or {}) do
        -- Exclude only the existing connected LAN prefix, not arbitrary routes on its interface.
        local ip,cb=tostring(n.cidr):match('^([%d.]+)/(%d+)$');local value=number(ip);cb=tonumber(cb)
        local own=n.interface==v.device and value and ((cb==bits and math.floor(value/size)*size==base) or cb==32 and (value==old or value==base or value==base+size-1))
        if not own then others.networks[#others.networks+1]=n end
    end
    local cidr=address(chosen)..'/'..prefix
    local result=require('brand_router.network_probe').check(others,{subnet=cidr})
    if result.verdict~='no_known_overlap' then return {state='conflict',message='目标范围与已知网络或路由重叠，请减少容量或更换起始网段。'} end
    local new=address(gateway)
    return {state='ready',kind='capacity',mode=input.mode,start_subnet=input.start_subnet,total=total,
        subnet=cidr,netmask=address(4294967296-block),prefix=prefix,start=address(first),finish=address(last),dhcp_start=first-chosen,
        old_ip=v.ip,new_ip=new,port=v.port,old_url='https://'..v.ip..':'..v.port,new_url='https://'..new..':'..v.port,
        fingerprint=v.fingerprint,preserves_addresses=first<=base+start and last>=base+start+limit-1,
        message='未发现已知网段冲突。应用会调整掩码并短暂重载网络；设备需续租或重新连接。检查不能排除未知网络或手动 IP 占用。'}
end
function M.adapter(c)
    local a={};local u=require('uci').cursor()
    function a.inventory()
        u=require('uci').cursor() -- Discard stale in-memory deltas after commit.
        local lan=u:get_all('network','lan') or {};local d=u:get_all('dhcp','lan') or {}
        local simple=lan.proto=='static' and d.interface=='lan' and d.ignore~='1' and not d.dhcp_option and not d.dhcp_option_force and not d.tag and not d.instance and not d.match_tag and not d.networkid
        u:foreach('dhcp','host',function() simple=false end)
        local active=0
        u:foreach('dhcp','dhcp',function(x) if x.ignore~='1' then active=active+1;if x.interface~='lan' then simple=false end end end)
        if active~=1 then simple=false end
        for _,name in ipairs({'network','dhcp'}) do if next(u:changes(name) or {}) then simple=false end end
        return {simple=simple,ip=lan.ipaddr,mask=lan.netmask,start=d.start,limit=d.limit,leasetime=d.leasetime or '12h',
            leases=util.read('/tmp/dhcp.leases',524288),now=os.time(),fingerprint=util.capture('sha256sum /etc/config/network /etc/config/dhcp',1024)}
    end
    function a.save(minutes,limit)
        local before=assert(util.read('/etc/config/dhcp',262144),'dhcp_backup_failed')
        util.atomic(c.state_dir..'/dhcp-settings-backup',before)
        local ok=pcall(function()
            assert(u:set('dhcp','lan','leasetime',minutes..'m'))
            if limit then assert(u:set('dhcp','lan','limit',tostring(limit))) end
            assert(u:commit('dhcp'));assert(util.exec('/etc/init.d/dnsmasq restart >/dev/null 2>&1 && /etc/init.d/dnsmasq running >/dev/null 2>&1'))
            local fresh=require('uci').cursor();assert(fresh:get('dhcp','lan','leasetime')==minutes..'m')
            if limit then assert(tonumber(fresh:get('dhcp','lan','limit'))==limit) end
        end)
        if not ok then
            pcall(function() u:revert('dhcp') end)
            util.atomic('/etc/config/dhcp',before)
            assert(util.exec('/etc/init.d/dnsmasq restart >/dev/null 2>&1 && /etc/init.d/dnsmasq running >/dev/null 2>&1'),'dhcp_rollback_failed')
            error('dhcp_save_failed',0)
        end
    end
    return a
end
function M.inspect(c,a)
    if c.allow_lab_http then return {supported=false,message='演示环境不修改 DHCP。'} end
    return M.plan((a or M.adapter(c)).inventory())
end
function M.apply(c,input,a)
    assert(not c.allow_lab_http,'preview_only')
    assert(input.confirm==true,'dhcp_confirmation_required')
    assert(type(input.minutes)=='number' and input.minutes%1==0 and input.minutes>=2 and input.minutes<=43200,'dhcp_invalid_minutes')
    return util.with_lock('/var/lock/brand-router-state',function()
        assert(not require('brand_router.network_repair').pending(c),'network_repair_busy')
        local update=require('brand_router.updater').status(c);assert(not(update.job and update.job.busy),'state_busy')
        a=a or M.adapter(c);local p=M.inspect(c,a)
        assert(p.supported,'dhcp_manual_required');assert(type(input.fingerprint)=='string' and input.fingerprint==p.fingerprint,'revision_conflict')
        assert(input.expand==nil or type(input.expand)=='boolean','dhcp_invalid_request')
        if input.expand then assert(p.expandable,'dhcp_pool_full') end
        a.save(input.minutes,input.expand and p.expanded_total or nil)
        return M.inspect(c,a)
    end)
end
return M
