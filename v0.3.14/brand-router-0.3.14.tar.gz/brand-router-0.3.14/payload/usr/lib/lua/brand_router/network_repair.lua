-- Explicit, bounded LAN migration. No autonomous network changes or device scanning.
local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local probe=require 'brand_router.network_probe'
local M={}
local active={prepared=true,applying=true,waiting=true,rolling_back=true,rollback_failed=true}
local function fail(code) error(code,0) end
local function check(ok,code) if not ok then fail(code) end end
local function read(path) return json.parse(util.read(path,262144) or '') end
function M.root(c) return c.repair_dir or '/etc/brand-router/network-repair' end
function M.state(c)
    local path=M.root(c)..'/state.json';local s=read(path)
    check(not fs.lstat(path) or type(s)=='table' and type(s.phase)=='string','network_repair_state_invalid')
    return s
end
function M.pending(c) local s=M.state(c);return s and active[s.phase] or false end
local function write(c,s)
    local path=M.root(c)..'/state.json';util.atomic(path,json.stringify(s))
    for _,target in ipairs({path,M.root(c)}) do
        local f=assert(require('nixio').open(target,'r'));local ok=f:sync();f:close();check(ok,'network_repair_persist_failed')
    end
end
local function locked(c,callback)
    local f=assert(require('nixio').open(M.root(c)..'/lock','w','600'))
    if not f:lock('tlock') then f:close();fail('network_repair_busy') end
    local ok,result=pcall(callback);f:close();if not ok then error(result,0) end;return result
end
local function ip24(ip)
    if type(ip)~='string' then return end
    local a,b,d,e=ip:match('^(%d+)%.(%d+)%.(%d+)%.(%d+)$')
    a,b,d,e=tonumber(a),tonumber(b),tonumber(d),tonumber(e)
    if not e or a>255 or b>255 or d>255 or e<1 or e>254 then return end
    if not (a==10 or a==172 and b>=16 and b<=31 or a==192 and b==168) then return end
    return a..'.'..b..'.'..d..'.'
end
-- Pure planner; inventory is collected locally, never accepted from the HTTP client.
function M.plan(v)
    local no={state='manual',message='当前网络需要管理员检查，未修改任何配置。'}
    if type(v)~='table' or not v.simple or not v.snapshot or not v.snapshot.available then return no end
    local prefix=ip24(v.ip)
    if not prefix or v.mask~='255.255.255.0' or v.portal_ip~=v.ip or not v.device then return no end
    local other={available=true,networks={}}
    for _,n in ipairs(v.snapshot.networks or {}) do if n.interface~=v.device then other.networks[#other.networks+1]=n end end
    local result=probe.check(other,{subnet=prefix..'0/24'})
    if result.verdict~='conflict' then return {state='normal',message='未发现已知网段冲突，无需调整。此检查不能排除离线设备或未知网络占用。'} end
    -- Keep current LAN excluded only for conflict detection; candidates avoid every known route.
    local choices={'192.168.50.','192.168.60.','192.168.70.','10.77.10.','10.88.20.','172.27.50.'}
    for _,p in ipairs(choices) do
        if probe.check(v.snapshot,{subnet=p..'0/24'}).verdict=='no_known_overlap' then
            return {state='conflict',message='发现上游与内网地址重叠，可选择新地址修复。',old_ip=v.ip,new_ip=p..'1',port=v.port,
                old_url='https://'..v.ip..':'..v.port,new_url='https://'..p..'1:'..v.port,
                subnet=p..'0/24',fingerprint=v.fingerprint}
        end
    end
    return no
end
function M.public(s)
    if not s then return nil end
    return {phase=s.phase,old_url=s.old_url,new_url=s.new_url,deadline=s.deadline,id=s.id,kind=s.kind,subnet=s.subnet,total=s.total}
end
function M.inspect(c,adapter)
    if c.allow_lab_http then return {state='manual',message='演示环境不修改网络。'} end
    if M.pending(c) then return {state='pending',operation=M.public(M.state(c))} end
    local a=adapter or require('brand_router.network_repair_system').new(c)
    local p=M.plan(a.inventory());p.operation=M.public(M.state(c))
    if p.state=='conflict' and a.verified and not a.verified() then p.state='manual';p.message='发现已知网段冲突。自动改址尚未通过本机验收，请管理员处理。' end
    return p
end
function M.request(c,input,a)
    check(not c.allow_lab_http,'preview_only')
    a=a or require('brand_router.network_repair_system').new(c)
    if input.action=='capacity-preview' then
        check(not M.pending(c),'network_repair_busy')
        local p=require('brand_router.dhcp_settings').capacity(a.inventory(),input)
        p.can_apply=p.state=='ready' and (not a.verified or a.verified('capacity'))
        if p.state=='ready' and not p.can_apply then p.message=p.message..' 本机扩容执行尚未验收，暂只提供规划。' end
        return p
    end
    util.private_dir(M.root(c),c.private_uid)
    return locked(c,function()
        local s=M.state(c)
        if input.action=='confirm' then
            check(s and s.phase=='waiting' and input.id==s.id,'network_repair_not_waiting')
            check(a.boot()==s.boot and a.uptime()<s.expires,'network_repair_expired')
            check(a.host()==s.new_ip..':'..s.port,'network_repair_new_address_required')
            check(a.healthy(s),'network_repair_unhealthy')
            s.phase='confirmed';write(c,s);return M.public(s)
        end
        check((input.action=='start' or input.action=='capacity-start') and input.confirm==true,'network_repair_confirmation_required')
        check(not a.verified or a.verified(input.action=='capacity-start' and 'capacity' or nil),'network_repair_not_verified')
        check(not M.pending(c) and not (a.worker_running and a.worker_running()),'network_repair_busy')
        local capacity=input.action=='capacity-start'
        local p=capacity and require('brand_router.dhcp_settings').capacity(a.inventory(),input) or M.plan(a.inventory())
        check(p.state==(capacity and 'ready' or 'conflict') and input.fingerprint==p.fingerprint and input.new_ip==p.new_ip,'network_repair_recheck')
        s={id=util.random_hex(16),phase='prepared',boot=a.boot(),expires=a.uptime()+240,deadline=os.time()+240,
            old_ip=p.old_ip,new_ip=p.new_ip,old_url=p.old_url,new_url=p.new_url,port=p.port,fingerprint=p.fingerprint}
        if capacity then
            for _,key in ipairs({'kind','mode','start_subnet','total','subnet','netmask','prefix','dhcp_start'}) do s[key]=p[key] end
        end
        a.backup(s) -- completed before the pending marker; no configuration changed yet
        write(c,s)
        if not a.launch() then s.phase='cancelled';write(c,s);fail('network_repair_launch_failed') end
        return M.public(s)
    end)
end
-- One bounded worker; a restarted worker rolls an interrupted change back.
function M.run(c,a)
    a=a or require('brand_router.network_repair_system').new(c)
    local s=M.state(c);if not s or not active[s.phase] then return end
    if s.phase=='prepared' then
        local valid,p=pcall(function() return s.kind=='capacity' and require('brand_router.dhcp_settings').capacity(a.inventory(),s) or M.plan(a.inventory()) end)
        if a.boot()~=s.boot or a.uptime()>=s.expires or not valid or p.state~=(s.kind=='capacity' and 'ready' or 'conflict') or p.fingerprint~=s.fingerprint or p.new_ip~=s.new_ip then
            s.phase='cancelled';write(c,s);return -- no writes yet; never overwrite a concurrent owner's configuration
        end
        s.phase='applying';write(c,s)
        local ok=pcall(function()
            a.apply(s);check(a.healthy(s),'network_repair_unhealthy')
        end)
        if ok then
            s.phase='waiting';write(c,s)
            while a.boot()==s.boot and a.uptime()<s.expires do
                local latest=M.state(c)
                if not latest or latest.id~=s.id or latest.phase=='confirmed' then return end
                a.sleep(1)
            end
        end
    end
    -- Serialize deadline rollback against user confirmation, including at the boundary.
    locked(c,function()
        local latest=M.state(c)
        if not latest or latest.id~=s.id or latest.phase=='confirmed' then return end
        s.phase='rolling_back';write(c,s)
        local ok=pcall(function() a.restore(s);check(a.restored(s),'network_repair_restore_failed') end)
        s.phase=ok and 'rolled_back' or 'rollback_failed';write(c,s)
    end)
end
return M
