local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local M={}
local paths={'/etc/config/network','/etc/config/dhcp','/etc/brand-router/portal.json','/etc/brand-router/portal.crt'}
local function read(p) return json.parse(util.read(p,262144) or '') end
-- Bounded child process group; iStoreOS may not include the timeout utility.
function M.command(cmd)
    local n=require 'nixio';local pid=assert(n.fork(),'network_repair_command_failed')
    if pid==0 then
        if not n.setsid() then os.exit(127) end
        n.exec('/bin/sh','-c','exec '..cmd..' >/dev/null 2>&1');os.exit(127)
    end
    for _=1,250 do
        local got,reason,code=n.waitpid(pid,'nohang')
        if got==pid then return reason=='exited' and code==0 end
        n.nanosleep(0,100000000)
    end
    n.kill(-pid,9);n.kill(pid,9);n.waitpid(pid);return false
end
local function run(cmd) assert(M.command(cmd),'network_repair_command_failed') end
function M.new(c)
    local a={};local dir=require('brand_router.network_repair').root(c)
    function a.verified(kind)
        local site=read('/etc/brand-router/site.json') or {}
        return (kind=='capacity' and site.network_capacity_verified==true or kind~='capacity' and site.network_repair_verified==true)
    end
    function a.boot() return (util.read('/proc/sys/kernel/random/boot_id') or ''):match('%S+') end
    function a.uptime() return assert(tonumber((util.read('/proc/uptime') or ''):match('^[%d.]+'))) end
    function a.host() return c.repair_host end
    function a.sleep(n) require('nixio').nanosleep(n) end
    function a.inventory()
        local u=require('uci').cursor();local lan=u:get_all('network','lan') or {};local dh=u:get_all('dhcp','lan') or {}
        local portal=read('/etc/brand-router/portal.json') or {};local ip,port=tostring(portal.listen):match('^([%d.]+):(%d+)$')
        local s=require('brand_router.network_probe').inspect(c)
        local status=json.parse(util.capture('ubus -t 3 call network.interface.lan status',32768) or '') or {}
        local simple=lan.proto=='static' and status.up==true and type(status['ipv4-address'])=='table' and #status['ipv4-address']==1
            and status['ipv4-address'][1].address==lan.ipaddr and type(status['ipv4-address'][1].mask)=='number' and status['ipv4-address'][1].mask>=16 and status['ipv4-address'][1].mask<=24
            and dh.interface=='lan' and dh.ignore~='1' and dh.start and dh.limit and not lan.gateway and not lan.dns
            and type(port)=='string' and tonumber(port)>=1024 and tonumber(port)<=65535 and portal.origin=='https://'..tostring(portal.listen)
        local bits=status['ipv4-address'] and status['ipv4-address'][1] and status['ipv4-address'][1].mask
        if type(bits)~='number' or bits<16 or bits>24 then simple=false else
            local size=2^(32-bits);local mask=4294967296-size
            local expected=math.floor(mask/16777216)..'.'..math.floor(mask/65536)%256 ..'.'..math.floor(mask/256)%256 ..'.'..mask%256
            if lan.netmask~=expected then simple=false end
        end
        if type(status.l3_device)~='string' or status.l3_device:find('[^%w_-]') then simple=false end
        for _,kind in ipairs({'route','route6','rule','rule6','bridge-vlan'}) do u:foreach('network',kind,function() simple=false end) end
        u:foreach('network','interface',function(x) if not ({lan=true,wan=true,wan6=true,loopback=true})[x['.name']] and not (x.auto=='0' and x.proto=='dhcp' and not x.ipaddr) then simple=false end end)
        for _,kind in ipairs({'host','domain','ipset','boot','relay'}) do u:foreach('dhcp',kind,function() simple=false end) end
        local pools=0
        u:foreach('dhcp','dhcp',function(x) if x.ignore~='1' then pools=pools+1;if x.interface~='lan' then simple=false end end end)
        if pools~=1 then simple=false end
        if dh.dhcp_option or dh.dhcp_option_force or dh.tag or dh.instance or dh.match_tag or dh.networkid then simple=false end
        u:foreach('dhcp','dnsmasq',function(x) if x.server or x.address or x.interface or x.listen_address then simple=false end end)
        -- Unrelated IPv6 rules are not IPv4 conflicts. Keep IPv4 rule ranges reserved.
        local function reserve(value)
            if type(value)=='table' then for _,part in ipairs(value) do reserve(part) end;return end
            if type(value)~='string' then simple=false;return end
            for part in value:gmatch('%S+') do
                if not part:find(':',1,true) then
                    local cidr=part:find('/',1,true) and part or part..'/32'
                    local valid=pcall(require('brand_router.network_probe').check,{available=true,networks={}},{subnet=cidr})
                    if not valid then simple=false else s.networks=s.networks or {};s.networks[#s.networks+1]={cidr=cidr,interface='firewall-reserved',source='firewall'} end
                end
            end
        end
        for _,kind in ipairs({'rule','redirect','nat'}) do u:foreach('firewall',kind,function(x)
            if x.src_ip then reserve(x.src_ip) end;if x.dest_ip then reserve(x.dest_ip) end
        end) end
        for _,name in ipairs({'network','dhcp','firewall'}) do if next(u:changes(name) or {}) then simple=false end end
        local doc=require('brand_router.business').load(c)
        if next(doc.mode_plans or {}) then simple=false end
        if fs.lstat('/var/lock/brand-fixed') or fs.lstat('/var/lock/brand-router-install') then simple=false end
        local update=require('brand_router.updater').status(c)
        if update.job and update.job.busy then simple=false end
        -- Only observed standard devices; VPNs and extra routed interfaces require manual review.
        local dump=json.parse(util.capture('ubus -t 3 call network.interface dump',65536) or '')
        if not dump then simple=false else
            for _,v in ipairs(dump.interface or {}) do
                if v.up and not ({lan=true,wan=true,wan6=true,loopback=true})[v.interface] then simple=false end
            end
        end
        local fingerprint=util.capture('sha256sum /etc/config/network /etc/config/dhcp /etc/config/firewall /etc/brand-router/portal.json /etc/brand-router/portal.crt',4096)
        if not fingerprint or #fingerprint<320 then simple=false end
        return {start=dh.start,limit=dh.limit,simple=simple,ip=lan.ipaddr,mask=lan.netmask,portal_ip=ip,port=port,device=status.l3_device,snapshot=s,fingerprint=fingerprint}
    end
    function a.backup(s)
        local b={files={},fixed=require('brand_router.fixed_runtime').enabled(c)}
        for _,p in ipairs(paths) do
            local st=fs.lstat(p);assert(st and st.type=='reg','network_repair_backup_failed')
            b.files[p]=assert(util.read(p,262144),'network_repair_backup_failed')
        end
        local raw=json.stringify(b);assert(#raw<=240000,'network_repair_backup_large')
        util.atomic(dir..'/backup.json',raw);run('/bin/sync')
    end
    function a.worker_running()
        local result=json.parse(util.capture("ubus -t 2 call service list '{\"name\":\"brand-network-repair\"}'",16384) or '')
        if not result then return true end
        local svc=result['brand-network-repair']
        for _,v in pairs(svc and svc.instances or {}) do if v.running then return true end end
        return false
    end
    function a.launch()
        return util.exec('/etc/init.d/brand-network-repair enable >/dev/null 2>&1') and util.exec('/etc/init.d/brand-network-repair start >/dev/null 2>&1')
    end
    local function refresh()
        local b=assert(read(dir..'/backup.json'))
        if b.fixed then
            run('/usr/libexec/brand-network-repair refresh')
        end
    end
    local function reload(ip)
        run('/etc/init.d/network reload')
        local ready=false
        for i=1,12 do
            local lan=json.parse(util.capture('ubus -t 2 call network.interface.lan status',32768) or '')
            if lan and lan.up and lan['ipv4-address'] and lan['ipv4-address'][1] and lan['ipv4-address'][1].address==ip then ready=true;break end
            a.sleep(1)
        end
        assert(ready,'network_repair_interface_failed')
        local dnsok=pcall(run,'/etc/init.d/dnsmasq restart');local fwok=pcall(run,'/etc/init.d/firewall reload')
        local fixedok=pcall(refresh);run('/etc/init.d/brand-portal restart')
        assert(dnsok and fwok and fixedok,'network_repair_services_failed')
    end
    function a.apply(s)
        local p=read('/etc/brand-router/portal.json');assert(p,'network_repair_config_invalid')
        -- Preserve private key and include both addresses for rollback/reconnection.
        if s.new_ip~=s.old_ip then run('/usr/bin/openssl req -x509 -key /etc/brand-router/portal.key -out '..util.quote(dir..'/next.crt')..
            ' -days 3650 -subj /CN=BrandRouter-local -addext '..util.quote('subjectAltName=DNS:gkglht.local,IP:'..s.old_ip..',IP:'..s.new_ip)) end
        local u=require('uci').cursor()
        assert(u:set('network','lan','ipaddr',s.new_ip));assert(u:set('network','lan','netmask',s.netmask or '255.255.255.0'))
        assert(u:set('dhcp','lan','start',tostring(s.dhcp_start or 50)));assert(u:set('dhcp','lan','limit',tostring(s.total or 200)))
        assert(u:commit('network'));assert(u:commit('dhcp'))
        if s.new_ip~=s.old_ip then
            p.listen=s.new_ip..':'..s.port;p.origin=s.new_url
            util.atomic('/etc/brand-router/portal.json',json.stringify(p));util.atomic('/etc/brand-router/portal.crt',assert(util.read(dir..'/next.crt')))
        end
        run('/bin/sync');reload(s.new_ip)
        for i=1,6 do if a.healthy(s) then return end;a.sleep(1) end
        error('network_repair_unhealthy')
    end
    function a.restore(s)
        local b=assert(read(dir..'/backup.json'),'network_repair_backup_missing')
        for _,p in ipairs(paths) do assert(type(b.files[p])=='string','network_repair_backup_invalid') end
        for _,p in ipairs(paths) do util.atomic(p,b.files[p]) end
        run('/bin/sync');reload(s.old_ip)
        for i=1,6 do if a.restored(s) then return end;a.sleep(1) end
        error('network_repair_restore_failed')
    end
    local function health(ip,port)
        local lan=json.parse(util.capture('ubus -t 2 call network.interface.lan status',32768) or '')
        if not (lan and lan.up and lan['ipv4-address'] and lan['ipv4-address'][1] and lan['ipv4-address'][1].address==ip) then return false end
        local b=read(dir..'/backup.json')
        if b and b.fixed and not require('brand_router.fixed_runtime').runtime_healthy(c) then return false end
        -- Local certificate can be self-signed; only this locally generated endpoint is probed.
        return util.exec('curl --noproxy "*" -kfsS --connect-timeout 2 --max-time 4 '..util.quote('https://'..ip..':'..port..'/api/state')..' >/dev/null 2>&1')
    end
    function a.healthy(s)
        if s.kind=='capacity' then
            local u=require('uci').cursor()
            local lan=json.parse(util.capture('ubus -t 2 call network.interface.lan status',32768) or '')
            if not (lan and lan['ipv4-address'] and lan['ipv4-address'][1] and lan['ipv4-address'][1].mask==s.prefix) then return false end
            if u:get('network','lan','netmask')~=s.netmask or tonumber(u:get('dhcp','lan','start'))~=s.dhcp_start or tonumber(u:get('dhcp','lan','limit'))~=s.total then return false end
        end
        return health(s.new_ip,s.port)
    end
    function a.restored(s) return health(s.old_ip,s.port) end
    return a
end
return M
