-- Read only current DHCP leases for registered MACs; never expose host names or unrelated clients.
local M={}
function M.collect(raw,bindings,now)
    local wanted,out={},{}
    for _,b in pairs(bindings or {}) do if type(b.mac)=='string' and b.mac~='' then wanted[b.mac:lower()]=true end end
    for line in (raw or ''):gmatch('[^\n]+') do
        local expiry,mac,ip=line:match('^(%d+)%s+([%x:]+)%s+(%d+%.%d+%.%d+%.%d+)%s')
        if expiry and wanted[mac:lower()] and (tonumber(expiry)==0 or tonumber(expiry)>now) then
            local valid=true;for part in ip:gmatch('%d+') do if tonumber(part)>255 then valid=false end end
            if valid then
                mac=mac:lower();out[mac]=out[mac] or {};local duplicate=false
                for _,old in ipairs(out[mac]) do if old==ip then duplicate=true end end
                if not duplicate then out[mac][#out[mac]+1]=ip end
            end
        end
    end
    return out
end
function M.inspect(bindings,now)
    return M.collect(require('brand_router.util').read('/tmp/dhcp.leases',524288),bindings,now)
end
return M
