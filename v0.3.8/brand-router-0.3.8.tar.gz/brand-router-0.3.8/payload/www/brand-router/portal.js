'use strict';
const $ = id => document.getElementById(id);
let updateManager=null,updatePoll=null,updatePollCount=0,pendingUpdateAction=null,pendingUpdateBuild=null;
let updateGeneration=0,updateLoaded=false,deviceGeneration=0,deviceBusy=false,previousDevice=null;
let csrf = '', renewal = false, config = null, page = 'fixed', editingNode = null, editingBinding = null, editRevision = 0, pendingAction = null;
const labels = {tcp:'TCP / RAW',ws:'WebSocket',grpc:'gRPC',httpupgrade:'HTTPUpgrade',xhttp:'XHTTP',quic:'QUIC',none:'无',tls:'TLS',reality:'REALITY'};
const states = {active:'授权有效',not_activated:'尚未激活',expired_cutoff:'业务已暂停',revoked:'授权已停用',wrong_device:'授权与设备不匹配',clock_rollback:'需要校准设备时间',clock_not_synchronized:'需要校准设备时间',clock_source_unavailable:'需要检查设备时间'};
const errors = {authorization_required:'授权已暂停，请导入续期码。',login_failed:'账号或密码不正确。',customer_role_required:'该账号尚未配置设备管理权限。',rate_limited:'操作较频繁，请稍后再试。',portal_unavailable:'设备中心暂时不可用，请联系管理员。',invalid_signature:'授权码校验失败。',wrong_device:'此授权码属于另一台设备。',stale_lease:'请使用管理员最新签发的授权码。',session_capacity:'管理会话较多，请稍后再试。',invalid_mac:'MAC 格式不正确，或填写了广播/组播地址。',duplicate_mac:'这个 MAC 已经登记，请编辑原设备。',node_in_use:'该节点仍被设备或模式节点池使用，请先解除相应引用。',revision_conflict:'其他页面已修改配置，当前草稿未覆盖。请复制需要保留的内容，再点“重新读取”。',node_not_found:'节点已不存在，请重新选择。',binding_not_found:'设备记录已不存在，请刷新。',invalid_server:'请填写有效 IP 或域名，不要包含网址前缀或端口。',invalid_port:'端口必须是 1–65535 的整数。',invalid_uuid:'请填写完整的 UUID。',password_required:'请填写节点认证密码。',authentication_pair_required:'用户名与密码需要同时填写，或同时留空。',invalid_reality_key:'REALITY 公钥应为 43 位 Base64URL 字符。',invalid_short_id:'Short ID 应为至多 16 位、长度为偶数的十六进制字符。',sni_required:'REALITY 需要填写服务器名称 SNI。',invalid_sni:'SNI 格式不正确。',invalid_transport_path:'请求路径应以 / 开头，且不含空格。',invalid_service_name:'请填写有效的 gRPC Service Name。',flow_transport_conflict:'Vision 仅适用于 VLESS、TCP 和 TLS/REALITY 组合。',reality_transport_conflict:'REALITY 只能搭配当前支持的 TCP、gRPC 或 XHTTP。',unsupported_transport:'该协议暂不支持所选传输方式。',unsupported_security:'该协议不支持所选安全设置。',unsupported_protocol:'该协议还未开放配置。',unsupported_cipher:'该加密方式尚未开放配置。',node_name_required:'请填写节点名称。',device_name_required:'请填写设备名称。',config_capacity:'配置数量或大小达到当前上限，请先整理已有配置。',config_corrupt:'本机配置文件异常，已停止写入，请联系管理员恢复。',config_file_not_private:'配置文件权限异常，已停止读取。',configuration_unavailable:'配置暂时不可用，请稍后重试。',no_previous_config:'还没有可以恢复的上一次配置。',feature_required:'当前授权未开放配置管理功能。'};
Object.assign(errors,{invalid_share_link:'请粘贴带协议前缀的完整节点链接（含服务器和端口）。',unsupported_link_scheme:'暂不支持这个链接协议，请使用页面列出的 8 类节点链接。',invalid_link_base64:'链接的 Base64 编码不完整或不正确，请重新复制。',invalid_vmess_json:'VMess 链接中的配置不完整或格式不正确。',unsupported_vmess_version:'暂不支持此 VMess 分享格式版本。',unsupported_vmess_legacy:'暂不支持 alterId 非 0 的旧版 VMess。',invalid_link_credentials:'节点链接缺少认证信息，或用户名与密码格式不正确。',invalid_udp_relay_mode:'TUIC UDP 转发只支持 native 或 quic。',invalid_congestion:'TUIC 拥塞控制只支持 cubic、bbr 或 new_reno。',invalid_alpn:'ALPN 请用英文逗号分隔，不含空格。',invalid_fingerprint:'暂不支持这个客户端指纹。',invalid_vless_link:'不是有效的 VLESS 链接，请粘贴完整 vless:// 地址。',invalid_link_encoding:'链接编码不正确，或包含无效字符。',unsupported_link_parameter:'链接包含暂不支持的参数，未忽略或保存，请检查节点参数。',duplicate_link_parameter:'链接包含重复参数，请检查。',unsupported_vless_encryption:'当前仅支持 encryption=none，此加密方式尚未接入。',link_parameter_conflict:'链接的参数与传输或安全方式冲突。',invalid_transport_mode:'不支持此传输模式。',invalid_rows:'每次最多 200 行，请检查内容。',invalid_note:'备注过长或包含控制字符。',invalid_group_name:'请输入有效分组名称（最多 80 字节）。',group_not_found:'分组不存在，请重新读取配置。',duplicate_group:'分组名称已存在。',group_not_empty:'请先移走组内记录，再删除空分组。',document_too_large:'内容过大，请分批添加。'});
function date(epoch) { return epoch ? new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(epoch*1000)) : '—'; }
function message(text, success=false, owner=page) { $('message').textContent=text;$('message').dataset.page=owner;$('message').classList.toggle('success',success);renderMessage(); }
function renderMessage() { const item=$('message');item.hidden=!item.textContent||(config&&item.dataset.page!==page); }
function countsUnavailable() { $('node-count').textContent='—';$('device-count').textContent='—';$('quick-counts').title='尚未读取已保存配置'; }
function list(value) { return Array.isArray(value) ? value : Object.values(value || {}); }
function normalize(value) { value.nodes=list(value.nodes);value.bindings=list(value.bindings);value.catalog=list(value.catalog);value.groups=list(value.groups);value.mode_plans=value.mode_plans||{};return value; }
function clearWorkspace() {
  clearTimeout(updatePoll);updateManager=null;message('');countsUnavailable();deviceGeneration++;deviceBusy=false;previousDevice=null;updateGeneration++;updateLoaded=false;config=null;csrf='';$('dashboard').hidden=true;$('business-nav').hidden=true;
  // Password recovery is public and must survive auth expiry/background refresh.
  document.querySelectorAll('dialog[open]').forEach(dialog=>{if(!['recover-account','recovery-result'].includes(dialog.id))dialog.close();});
  probeAbort?.abort();probeQueue.length=0;probeResults.clear();rows=[];modeDrafts.clear();for(const mode of ['fixed','rotation','dynamic'])$('mode-'+mode).replaceChildren();selected.clear();previewGeneration++;clearTimeout(previewTimer);$('node-form').reset();$('paste-links').value='';$('binding-rows').replaceChildren();
}
async function api(path, input, signal) {
  let response;
  try {response=await fetch(path,{method:input ? 'POST':'GET',credentials:'same-origin',headers:input ? {'Content-Type':'application/json','X-CSRF-Token':csrf}:{},body:input ? JSON.stringify(input):undefined,cache:'no-store',signal});}
  catch {throw new Error('无法连接设备服务，请检查服务是否运行后重试。');}
  const value=await response.json();
  if(!response.ok) {
    if(response.status===423) {clearWorkspace();showState(value.license);}
    if(response.status===401 && path!=='/api/login') {clearWorkspace();$('login').hidden=false;}
    const error=new Error((value.row?'第 '+value.row+' 行：':'')+(errors[value.error] || states[value.license?.state] || '操作未完成，请检查输入后重试。'));error.status=response.status;error.row=value.row;error.code=value.error;throw error;
  }
  return value;
}
function showState(status) {
  if(!status) return;
  $('license-badge').textContent=states[status.state] || '需要检查授权';$('license-badge').classList.toggle('locked',!status.customer_login_allowed);
  if(!status.customer_login_allowed) { clearWorkspace();$('login').hidden=true;$('activation').hidden=false;$('activation-title').textContent=status.state==='not_activated'?'激活这台设备':'续期恢复连接';renewal=false; }
  else {$('activation').hidden=!renewal;$('login-expiry').textContent='实际业务停用时间：'+date(status.stop_at);}
}
function showPage(name) {
  const previous=page;page=name;if(previous!==name)window.scrollTo(0,0);$('page-title').textContent=({fixed:'固定绑定',rotation:'租约轮询',dynamic:'动态会话',overview:'授权与概览',updates:'系统更新',settings:'系统设置'})[name]||'设备中心';document.querySelectorAll('.workspace-page').forEach(panel=>panel.hidden=panel.id!=='page-'+name);
  document.querySelectorAll('[data-page]').forEach(button=>button.classList.toggle('active',button.dataset.page===name));
  $('config-footer').hidden=['updates','overview','settings'].includes(name);$('runtime-status').hidden=['updates','settings'].includes(name);$('quick-counts').hidden=['updates','settings'].includes(name);renderMessage();
  if(name==='settings'&&previous!=='settings')loadAccount();
  if(name==='fixed'&&previous!=='fixed'&&config)loadFixedStatus();
  if(name==='updates'&&(previous!=='updates'||!updateLoaded))loadUpdateStatus();
  if(name==='overview'&&document.visibilityState!=='hidden')loadDeviceStatus();
}
async function loadUpdateStatus({quiet=false}={}){
  if(quiet&&(page!=='updates'||!config))return;
  quiet=quiet&&!!updateManager;
  clearTimeout(updatePoll);
  const generation=++updateGeneration;updateLoaded=true;
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),10000);
  if(!quiet){
  disableUpdateActions();
  $('refresh-update-status').disabled=true;$('refresh-update-status').textContent='正在刷新…';
  $('page-updates').setAttribute('aria-busy','true');
  $('update-status-message').textContent='正在读取本机版本与更新功能状态…';
  for(const id of ['update-current','update-source'])$(id).textContent='读取中…';
  $('update-release-detail').textContent='';$('update-source-detail').textContent='';$('update-environment').textContent='';
  $('update-firmware').textContent='系统版本：读取中…';$('update-checked').textContent='正在刷新本机状态';$('update-history').textContent='正在读取记录状态…';
  }
  try{
    const data=await api('/api/update/status',undefined,controller.signal);if(generation!==updateGeneration||!config)return;
    const installed=data.installed||{},preview=installed.kind==='development_preview';
    $('update-current').textContent=preview?'本地演示版':installed.version?'v'+installed.version:'版本未记录';
    $('update-release-detail').textContent=preview?'演示环境不代表路由器实机':installed.build_id?(data.manager?.release?.build_id===installed.build_id?'已发布版本 · 构建 ':'本机构建 · ')+installed.build_id.slice(0,12):'未获取构建记录，无法确认应用版本';
    $('update-source').textContent=data.source?.configured?'已配置，尚未检查':'尚未接通';
    $('update-source-detail').textContent='本页尚未连接版本检查和安装服务';
    $('update-firmware').textContent='系统版本：'+(installed.firmware||(preview?'演示环境无实机系统版本':'未获取'));
    $('update-checked').textContent=data.checked_at?'本机状态刷新于 '+date(data.checked_at)+' · 未检查远端新版本':'本机状态已读取 · 未获取检查时间';
    $('update-status-message').textContent='本机状态已读取。在线更新、离线安装和版本恢复暂未开放。';
    $('update-history').textContent=data.history_available?'本页暂不支持查看安装记录':'尚未接入安装记录与恢复服务，无法在此页回退版本。';
    $('update-environment').textContent=preview?'当前为本地演示环境。':'当前为设备实机页面。';renderUpdateManager(data.manager);
  }catch(error){
    if(generation!==updateGeneration)return;
    if(quiet){
      renderUpdateManager(null);updateLoaded=false;
      $('update-source').textContent='进度读取中断';
      $('update-status-message').textContent='暂时无法读取任务进度，已保留上次显示内容。请点击“刷新本机状态”重新确认；不要重复安装。';
      return;
    }
    renderUpdateManager(null);updateLoaded=false;$('update-current').textContent='读取失败';$('update-release-detail').textContent='请刷新重试';$('update-source').textContent='无法确认';$('update-history').textContent='未能读取记录状态';
    $('update-source-detail').textContent='连接恢复后可重试';$('update-firmware').textContent='系统版本：未获取';$('update-checked').textContent='刷新失败 · 当前状态未知';
    $('update-status-message').textContent=error.message;
  }finally{clearTimeout(timeout);if(generation===updateGeneration){$('refresh-update-status').disabled=false;$('refresh-update-status').textContent='刷新本机状态';$('page-updates').setAttribute('aria-busy','false');}}
}

function bytes(value) {if(!Number.isFinite(value))return '未获取';const units=['B','KiB','MiB','GiB','TiB'];let i=0;while(value>=1024&&i<units.length-1){value/=1024;i++;}return value.toFixed(i?1:0)+' '+units[i];}
function percent(value){return Number.isFinite(value)?value.toFixed(1)+'%':'未获取';}
function duration(value){if(!Number.isFinite(value))return '未获取';return Math.floor(value/86400)+' 天 '+Math.floor(value%86400/3600)+' 小时 '+Math.floor(value%3600/60)+' 分钟';}
function detail(root,label,value){const box=element('div','');box.append(element('dt',label),element('dd',value??'未获取'));root.append(box);}
function renderDevice(data){
  const delta=BrandTelemetry.delta(data,previousDevice),mem=data.memory||{},cpu=data.cpu||{},system=data.system||{};
  const usage=$('device-usage');usage.replaceChildren();
  const cards=[['CPU 使用率',delta.cpu===null&&cpu.total_ticks!==undefined?'等待下次采样':percent(delta.cpu),cpu.logical_cores?cpu.logical_cores+' 个逻辑处理器':'逻辑处理器未获取'],['内存使用',percent(BrandTelemetry.percent(mem.used_bytes,mem.total_bytes)),'已用 '+bytes(mem.used_bytes)+' / 总计 '+bytes(mem.total_bytes)+' · 可用 '+bytes(mem.available_bytes)],['持续运行',duration(system.uptime_seconds),'重启后重新计时'],['温度',list(data.temperatures).map(t=>t.name+' '+t.celsius.toFixed(1)+' °C').join(' · ')||'未获取','以系统提供的温度传感器为准']];
  for(const [label,value,note] of cards){const card=element('article','','card');card.append(element('p',label),element('strong',value),element('span',note));usage.append(card);}
  const hardware=$('device-hardware');hardware.replaceChildren();
  for(const [label,value] of [['厂商 / 机型',[system.vendor,system.model].filter(Boolean).join(' · ')||null],['CPU 型号',cpu.model],['架构 / 平台',[system.architecture,system.target].filter(Boolean).join(' · ')||null],['系统版本',system.firmware],['内核版本',system.kernel],['系统负载（1 / 5 / 15 分钟）',[cpu.load_1,cpu.load_5,cpu.load_15].map(v=>Number.isFinite(v)?v.toFixed(2):'—').join(' / ')],['交换空间','总计 '+bytes(mem.swap_total_bytes)+' · 可用 '+bytes(mem.swap_free_bytes)]])detail(hardware,label,value);
  const disks=$('device-disks');disks.replaceChildren();
  for(const disk of list(data.storage?.disks))disks.append(element('p',disk.name+' · '+(disk.model||'型号未获取')+' · 容量 '+bytes(disk.bytes)));
  for(const volume of list(data.storage?.filesystems))disks.append(element('p','分区 '+volume.mount+' · 已用 '+bytes(volume.used_bytes)+' / '+bytes(volume.total_bytes)+' · 可用 '+bytes(volume.available_bytes)));
  if(!disks.childElementCount)disks.append(element('p','尚未获取磁盘与分区数据','subtle'));
  const network=$('device-interfaces');network.replaceChildren();const interfaces=list(data.interfaces);
  if(interfaces.length){const table=element('table',''),head=element('tr','');for(const title of ['接口','连接 / 速率','接收 / 发送速率','累计接收 / 发送','接收 / 发送错误'])head.append(element('th',title));const thead=element('thead','');thead.append(head);table.append(thead);const tbody=element('tbody','');
    for(const net of interfaces){const row=element('tr',''),rate=delta.rates[net.name]||{},speed=v=>Number.isFinite(v)?bytes(v)+'/s':'等待采样';const state=net.carrier===1?'已连接':net.carrier===0?'未连接':net.state||'未知';for(const value of [net.name+(net.kind==='logical'?'（逻辑）':''),state+' · '+(net.speed_mbps?net.speed_mbps+' Mbps':'速率未获取'),speed(rate.rx)+' / '+speed(rate.tx),bytes(net.rx_bytes)+' / '+bytes(net.tx_bytes),(net.rx_errors??'—')+' / '+(net.tx_errors??'—')])row.append(element('td',value));tbody.append(row);}table.append(tbody);network.append(table);
  }else network.append(element('p',data.interfaces_available?'没有可展示的非回环接口':'尚未连接设备，无法读取接口','subtle'));
  const connections=$('device-connections');connections.replaceChildren();detail(connections,'有效 DHCP 租约',data.dhcp_active_leases);detail(connections,'连接跟踪条目',(data.conntrack?.count??'未获取')+' / 上限 '+(data.conntrack?.maximum??'未获取'));detail(connections,'真实代理运行','尚未接通监测');
  previousDevice=data.available?data:null;
}
async function loadDeviceStatus(){
  if(deviceBusy||!config)return;deviceBusy=true;const generation=++deviceGeneration;$('refresh-device-status').disabled=true;
  try{const data=await api('/api/device/status');if(generation!==deviceGeneration||!config)return;renderDevice(data);
    $('device-status-message').textContent=data.source==='preview'?'本地演示尚未连接工控机。下列硬件与使用情况不填模拟值；部署到设备后读取该设备的数据。':data.available?'本机只读采集 · '+date(data.sampled_at)+' · 本页每 15 秒刷新，CPU 与网口速率需两次采样；缺失项显示未获取。':'采集不可用，尚未获取设备运行数据。';
  }catch(error){if(generation===deviceGeneration){previousDevice=null;$('device-status-message').textContent='刷新失败，下面可能保留上次数据：'+error.message;}}
  finally{if(generation===deviceGeneration){deviceBusy=false;$('refresh-device-status').disabled=false;}}
}
function element(tag,text,className) {const value=document.createElement(tag);value.textContent=text;if(className)value.className=className;return value;}
function button(text,work,className='secondary') {const value=element('button',text,className);value.type='button';value.addEventListener('click',work);return value;}
function empty(container,title,text,action,work) {const box=element('div','','empty-state');box.append(element('h3',title),element('p',text));if(action)box.append(button(action,work,''));container.append(box);}
function protocolName(id) {return config?.catalog.find(item=>item.id===id)?.label || id;}
function nodeDescription(node) {return [protocolName(node.protocol),labels[node.transport],labels[node.security]].join(' · ');}
function nodeScheme(node) {return node?.protocol==='shadowsocks'?'ss':node?.protocol==='http'&&node.security==='tls'?'https':node?.protocol||'vless';}
let rows=[],activeGroup='',selected=new Set(),previewTimer,previewGeneration=0,busy=false,groupEditing=null;
function groups() {return [{id:'',name:'未分组'},...config.groups];}
function groupName(id) {return groups().find(g=>g.id===id)?.name || '未分组';}
function dirtyRows() {return rows.filter(r=>r.dirty);}
function buildRows(value) {
  const bindings=value.bindings.map(b=>({...b,key:b.id,group_id:b.group_id||'',link:'',dirty:false,preview:value.nodes.find(n=>n.id===b.node_id)}));
  const used=new Set([...bindings.map(b=>b.node_id),...Object.values(value.mode_plans).flatMap(p=>list(p.node_ids))]);
  for(const n of value.nodes)if(!used.has(n.id))bindings.push({key:'node-'+n.id,node_id:n.id,mac:'',note:n.note||'',group_id:'',link:'',preview:n,dirty:false,orphan:true});
  return bindings;
}
function acceptConfig(value,acknowledged=[]) {
  const retained=rows.filter(r=>r.dirty&&!acknowledged.includes(r.key));
  const hadConfig=!!config;const previousNodes=new Map((config?.nodes||[]).map(n=>[n.id,JSON.stringify(n)]));
  config=normalize(value);rows=buildRows(config);
  for(const draft of retained) {const i=rows.findIndex(r=>r.key===draft.key);if(i>=0)rows[i]=draft;else rows.push(draft);}
  if(!groups().some(g=>g.id===activeGroup))activeGroup='';
  selected.clear();renderConfig();renderModePanels();
  if(hadConfig)for(const n of config.nodes)if(!previousNodes.has(n.id)||previousNodes.get(n.id)!==JSON.stringify(n)){probeResults.delete(n.id);queueProbe(n.id);}
}
function markDirty(row) {row.dirty=true;updateSaveState();}
function updateSaveState() {
  const pending=dirtyRows().length;
  $('save-all').textContent=pending?'保存全部修改（'+pending+' 行）':'全部已保存';$('save-all').disabled=busy||!pending;
  $('draft-state').textContent=pending?'有未保存修改；切换分组会保留草稿。':'MAC 留空可以先保存线路，填写后形成设备绑定。';
  $('delete-selected').disabled=busy||!selected.size;$('delete-selected').textContent=selected.size?'删除选中 '+selected.size+' 行':'删除选中项';
  $('selection-count').textContent='已选 '+selected.size+' 行';$('move-selected').textContent=selected.size?'转移选中 '+selected.size+' 行':'转移选中项';$('move-selected').disabled=busy||!selected.size||$('move-target').value==='__choose__';
}
function deleteSelected() {
  const chosen=rows.filter(r=>selected.has(r.key));
  if(busy||!chosen.length)return;
  if(dirtyRows().length){message('请先保存当前修改，再批量删除。');return;}
  if(chosen.length>200){message('每次最多删除 200 行，请分批操作。');return;}
  confirmChange('删除选中 '+chosen.length+' 行','将删除选中线路及其 MAC 绑定；不再被使用的节点一并删除，其他行或模式共用的节点保留。分组保留。保存删除后需点击“应用固定绑定”才更新实际转发。',{action:'delete_selection',ids:chosen.filter(r=>r.id).map(r=>r.id),node_ids:chosen.filter(r=>r.orphan).map(r=>r.node_id)});
}
function visibleRows() {
  const q=$('row-search').value.trim().toLowerCase();
  return rows.filter(r=>r.group_id===activeGroup&&[r.mac,r.note,r.preview?.name,r.preview?.server].join(' ').toLowerCase().includes(q));
}
function statusText(row) {
  if(row.error)return row.error;
  if(row.link&&!row.preview)return '正在识别链接…';
  if(row.preview)return [row.preview.name,nodeDescription(row.preview),row.preview.server+':'+row.preview.port,row.mac?'':'待填写 MAC'].filter(Boolean).join(' · ');
  return '粘贴完整节点链接，自动识别协议与传输方式';
}
function updateRowStatus(row) {
  const target=$('row-'+row.key)?.querySelector('.link-status');if(!target)return;
  target.textContent=statusText(row);target.classList.toggle('invalid',!!row.error);
  const probe=$('row-'+row.key)?.querySelector('.probe-status');if(probe){probe.dataset.node=row.link?'':row.node_id||'';if(row.link)probe.textContent='链接修改未保存，保存后测试';else if(row.node_id)paintProbe(row.node_id);}
}
function editInput(value,label,placeholder,limit) {
  const input=element('input','');input.value=value||'';input.setAttribute('aria-label',label);input.placeholder=placeholder;input.maxLength=limit;input.autocomplete='off';input.spellcheck=false;return input;
}
function renderConfig() {
  if(!config)return;
  $('quick-counts').title='已保存的节点与设备记录；未保存草稿不计入';$('node-count').textContent=config.nodes.length;$('device-count').textContent=config.bindings.filter(b=>b.mac).length;
  $('config-version').textContent='配置版本 '+config.revision+(config.updated_at?' · 保存于 '+date(config.updated_at):'');
  $('runtime-status').textContent=config.runtime.message;
  $('undo-change').disabled=config.revision===0;
  const target=$('move-target'),previousTarget=target.value;target.replaceChildren(new Option('选择目标分组','__choose__'));for(const g of groups())if(g.id!==activeGroup)target.add(new Option(g.name,g.id));target.value=[...target.options].some(o=>o.value===previousTarget)?previousTarget:'__choose__';
  const tabs=$('group-tabs');tabs.replaceChildren();
  for(const g of groups()) {const count=rows.filter(r=>r.group_id===g.id).length;const tab=button(g.name+'  '+count,()=>{activeGroup=g.id;selected.clear();renderConfig();},'group-tab'+(g.id===activeGroup?' active':''));tab.setAttribute('aria-pressed',String(g.id===activeGroup));tabs.append(tab);}
  $('current-group').textContent=groupName(activeGroup);$('rename-group').hidden=!activeGroup;$('delete-group').hidden=!activeGroup;
  const body=$('binding-rows');body.replaceChildren();const visible=visibleRows();
  $('group-empty').hidden=!!visible.length;$('row-table').hidden=false;
  $('select-all').checked=visible.length>0&&visible.every(r=>selected.has(r.key));
  for(const [index,row] of visible.entries()) {
    const tr=element('tr','');tr.id='row-'+row.key;tr.classList.toggle('draft-row',row.dirty);
    const macCell=element('td',''),macWrap=element('div','','mac-entry'),choose=element('input','');choose.type='checkbox';choose.checked=selected.has(row.key);choose.setAttribute('aria-label','选择第 '+(index+1)+' 行');
    choose.addEventListener('change',()=>{if(choose.checked)selected.add(row.key);else selected.delete(row.key);updateSaveState();});
    const mac=editInput(row.mac,'第 '+(index+1)+' 行 MAC','AA:BB:CC:DD:EE:FF',17);
    mac.addEventListener('input',()=>{row.mac=mac.value;markDirty(row);updateRowStatus(row);});macWrap.append(choose,mac);macCell.append(macWrap);
    const linkCell=element('td',''),link=element('textarea','');link.rows=2;link.maxLength=4096;link.value=row.link||'';link.autocomplete='off';link.spellcheck=false;link.setAttribute('aria-label','第 '+(index+1)+' 行节点链接');
    link.placeholder=row.node_id?nodeScheme(row.preview)+'://••••@'+(row.preview?.server||'节点')+':'+(row.preview?.port||'')+'（已保存，粘贴可替换本行）':'粘贴节点链接，如 vless://、vmess://（可多行）';
    link.addEventListener('input',()=>{row.link=link.value.trim();row.preview=row.link?null:config.nodes.find(n=>n.id===row.node_id);row.error='';markDirty(row);updateRowStatus(row);schedulePreview();});
    link.addEventListener('paste',event=>{const raw=event.clipboardData?.getData('text')||'';if(raw.includes('\n')||raw.includes('\r')){event.preventDefault();pasteLines(raw,row);}});
    const status=element('p',statusText(row),'link-status'+(row.error?' invalid':''));linkCell.append(link,status);
    const probe=element('p','','probe-status subtle');probe.dataset.node=row.link?'':row.node_id||'';if(row.link)probe.textContent='链接修改未保存，保存后测试';linkCell.append(probe);
    const test=button('测试连接',()=>{if(row.link||!row.node_id){message('请先保存此节点，再测试连接。',false,'fixed');return;}queueProbe(row.node_id,true);},'text-button');linkCell.append(test);
    if(row.node_id)paintProbe(row.node_id);
    const noteCell=element('td',''),note=editInput(row.note,'第 '+(index+1)+' 行备注','设备或线路备注',240);note.addEventListener('input',()=>{row.note=note.value;markDirty(row);});noteCell.append(note);
    const actions=element('td',''),buttons=element('div','','row-actions');buttons.append(button('＋ 相同节点',()=>copyRow(row),'same-node'),button('移动分组',()=>openMove([row.key]),'text-button'),button('删除',()=>deleteRow(row),'text-button danger'));
    if(row.node_id)buttons.append(button('节点参数',()=>{if(dirtyRows().length){message('请先保存当前修改，再编辑节点参数。');return;}openNode(config.nodes.find(n=>n.id===row.node_id));},'text-button'));
    actions.append(buttons);tr.append(macCell,linkCell,noteCell,actions);body.append(tr);
  }
  updateSaveState();for(const row of visible)if(row.node_id)paintProbe(row.node_id);
}
function newRow(extra={}) {return {key:'draft-'+crypto.randomUUID(),mac:'',link:'',note:'',group_id:activeGroup,dirty:true,...extra};}
function addRow() {const row=newRow();rows.push(row);renderConfig();$('row-'+row.key)?.querySelector('textarea').focus();}
function copyRow(source) {
  if(!source.node_id&&!source.link){message('请先填写这一行的节点链接。');return;}
  const copy=newRow({node_id:source.node_id,link:source.link,preview:source.preview,group_id:source.group_id,after_id:source.id||source.after_id});
  rows.splice(rows.indexOf(source)+1,0,copy);renderConfig();$('row-'+copy.key)?.querySelector('.mac-entry input:not([type=checkbox])').focus();schedulePreview();
}
function pasteLines(raw,anchor=null) {
  const links=raw.split(/\r?\n|\r/).map(v=>v.trim()).filter(Boolean);
  if(!links.length)return;
  if(links.length>200||dirtyRows().length+links.length-(anchor?.dirty?1:0)>200){message('每次最多保存 200 行，请先保存当前修改。');return;}
  if(links.some(s=>s.length>4096)){message('某行链接过长，请检查是否粘贴了其他内容。');return;}
  const created=links.map(link=>newRow({link}));
  if(anchor){const at=rows.indexOf(anchor);Object.assign(anchor,{link:links[0],preview:null,error:'',dirty:true});rows.splice(at+1,0,...created.slice(1));}
  else rows.push(...created);
  $('paste-dialog').close();$('paste-links').value='';renderConfig();schedulePreview();message('已拆成 '+links.length+' 行，正在识别；填写 MAC 后保存。',true);
}
function schedulePreview() {clearTimeout(previewTimer);previewTimer=setTimeout(previewLinks,350);}
async function previewLinks() {
  const pending=rows.filter(r=>r.dirty&&r.link),generation=++previewGeneration;
  if(!pending.length||!config)return;
  const snapshot=pending.map(r=>({key:r.key,link:r.link}));
  try {
    const data=await api('/api/config/preview',{links:snapshot.map(r=>r.link)});
    if(generation!==previewGeneration||!config)return;
    list(data.results).forEach((item,i)=>{const row=rows.find(r=>r.key===snapshot[i].key);if(!row||row.link!==snapshot[i].link)return;row.preview=item.error?null:item;row.error=item.error?(errors[item.error]||'链接参数不受支持，请检查。'):'';updateRowStatus(row);});
  }catch(error){if(generation!==previewGeneration||!config)return;for(const sample of snapshot){const row=rows.find(r=>r.key===sample.key);if(row&&row.link===sample.link){row.error=error.message;updateRowStatus(row);}}}
}
async function saveAll() {
  const owner=page,pending=dirtyRows();if(!pending.length||busy)return;
  const macs=new Map();
  for(const row of rows){const mac=row.mac.trim().toLowerCase().replaceAll('-',':');if(!mac)continue;if(!/^[0-9a-f]{2}(:[0-9a-f]{2}){5}$/.test(mac)||parseInt(mac.slice(0,2),16)%2||mac==='00:00:00:00:00:00'){message('MAC 格式不正确：请检查对应行。');return;}if(macs.has(mac)){message('同一个 MAC 只能绑定一个节点，请检查重复项。');return;}macs.set(mac,true);}
  const payload={action:'save_rows',revision:config.revision,rows:pending.map(r=>({...(r.id?{id:r.id}:{}),...(r.after_id?{after_id:r.after_id}:{}),node_id:r.node_id||'',link:r.link||'',mac:r.mac.trim(),note:r.note,group_id:r.group_id}))};
  if(pending.length>200||new TextEncoder().encode(JSON.stringify(payload)).length>131072){message('本次内容超过保存上限（200 行 / 128KiB），请分批添加。');return;}
  busy=true;setBusy(true);message('');
  try{const data=await api('/api/config/change',payload);acceptConfig(data,pending.map(r=>r.key));message('已保存 '+pending.length+' 行，可刷新回读。',true,owner);}
  catch(error){const row=error.row&&pending[error.row-1];if(row){activeGroup=row.group_id;row.error=errors[error.code]||error.message;renderConfig();message('分组「'+groupName(row.group_id)+'」第 '+(rows.filter(r=>r.group_id===row.group_id).indexOf(row)+1)+' 行：'+row.error,false,owner);}else message(error.message,false,owner);}
  finally{busy=false;setBusy(false);updateSaveState();}
}
function setBusy(value) {document.querySelectorAll('#dashboard input,#dashboard textarea,#dashboard button,#dashboard select').forEach(e=>{if(value){e.dataset.busyDisabled=String(e.disabled);e.disabled=true;}else if(e.dataset.busyDisabled!==undefined){e.disabled=e.dataset.busyDisabled==='true';delete e.dataset.busyDisabled;}});}
function openGroup(id=null) {groupEditing=id;$('group-title').textContent=id?'重命名分组':'新建分组';$('group-name').value=id?groupName(id):'';$('group-error').hidden=true;$('group-dialog').showModal();$('group-name').focus();}
function openMove(keys) {
  $('move-error').hidden=true;selected=new Set(keys);const select=$('move-group');select.replaceChildren();for(const g of groups())select.add(new Option(g.name,g.id));select.value=activeGroup;$('move-dialog').showModal();updateSaveState();
}
async function moveSelected(target=$('move-group').value) {
  const owner=page,chosen=rows.filter(r=>selected.has(r.key));
  if(!chosen.length||busy)return;
  if(target==='__choose__'||!groups().some(g=>g.id===target))throw new Error('请先选择目标分组。');
  if(chosen.every(r=>r.group_id===target))throw new Error('所选记录已在这个分组，请选择其他分组。');
  const targetName=groupName(target);busy=true;setBusy(true);
  try {
    const saved=chosen.every(r=>r.id&&!r.dirty)&&!dirtyRows().length;
    if(saved)await change({action:'move_rows',revision:config.revision,ids:chosen.map(r=>r.id),group_id:target});
    else for(const row of chosen){row.group_id=target;markDirty(row);}
    activeGroup=target;selected.clear();$('move-dialog').close();renderConfig();
    message('已转移 '+chosen.length+' 行到「'+targetName+'」'+(saved?'，已保存。':'；含未保存修改，请点击“保存全部修改”。'),true,owner);
  } finally {busy=false;setBusy(false);updateSaveState();}
}
function deleteRow(row) {
  if(!row.id&&!row.orphan){rows=rows.filter(r=>r!==row);selected.delete(row.key);renderConfig();return;}
  if(dirtyRows().length){message('请先保存当前修改，再删除已保存记录。');return;}
  confirmChange('删除这一行','仅删除这一行；其他 MAC 使用的相同节点会保留。',row.orphan?{action:'delete_node',id:row.node_id}:{action:'delete_rows',ids:[row.id]});
}
async function loadConfig() {try{acceptConfig(await api('/api/config'));}catch(error){countsUnavailable();$('quick-counts').title='配置读取失败，数量未知';throw error;}}

async function dashboard() {
  const data=await api('/api/dashboard');csrf=data.csrf;showState(data.license);
  $('login').hidden=true;$('dashboard').hidden=false;$('business-nav').hidden=false;$('activation').hidden=!renewal;
  document.querySelectorAll('[data-brand]').forEach(e=>e.textContent=data.brand_name);
  $('expires-text').textContent='截止：'+date(data.license.expires_at);$('stop-text').textContent=date(data.license.stop_at);
  $('resources-text').textContent='内存 '+(data.resources.effective_memory_mib/1024).toFixed(1)+' GiB · 分区 '+(data.resources.storage_mib/1024).toFixed(1)+' GiB';
  $('tier-text').textContent=data.resources.source==='preview'?'演示预设规格，并非本机实测':data.resources.minimum_supported?'容量满足最低要求，性能需另行验收':'容量信息不足或未满足最低要求';
  if(data.account?.first_setup){showPage('settings');await loadAccount();return;}
  if(!config) await loadConfig();showPage(page);if(page==='fixed')await loadFixedStatus();
}
async function refresh() {
  const owner=page;
  try {const data=await api('/api/state');document.querySelectorAll('[data-brand]').forEach(e=>e.textContent=data.brand_name);showState(data.license);setLoginAccount(data.account);
    if(data.license.customer_login_allowed) {try {await dashboard();} catch(error) {if(error.status===401) {$('login').hidden=false;} else message(error.message,false,owner);}}
  } catch(error) {message(error.message,false,owner);}
}
async function submit(form,work,errorId) {
  const owner=page;
  const submitter=form.querySelector('[type="submit"]') || form.querySelector('button');submitter.disabled=true;
  if(errorId) $(errorId).hidden=true;else message('');
  try {await work();} catch(error) {
    // A stale revision never silently rebases unsaved edits.
    if(errorId) {$(errorId).textContent=error.message;$(errorId).hidden=false;} else message(error.message,false,owner);
  } finally {submitter.disabled=false;if(form.id==='batch-transfer')updateSaveState();}
}
function options(select,values,selected) {select.replaceChildren();for(const value of values)select.add(new Option(labels[value] || value,value));select.value=values.includes(selected)?selected:values[0];}
function nodeFields() {
  const form=$('node-form'),p=form.elements.protocol.value,t=form.elements.transport.value,s=form.elements.security.value;
  const fields={method:p==='shadowsocks',vmess_cipher:p==='vmess',udp_relay_mode:p==='tuic',username:['socks5','http'].includes(p),password:['socks5','http','trojan','shadowsocks','hysteria2','tuic'].includes(p),uuid:['vless','vmess','tuic'].includes(p),sni:s!=='none',alpn:s!=='none',flow:p==='vless'&&t==='tcp'&&s!=='none',fingerprint:['vless','vmess','trojan'].includes(p)&&s!=='none',public_key:s==='reality',short_id:s==='reality',path:['ws','httpupgrade','xhttp'].includes(t),host:['ws','httpupgrade','xhttp'].includes(t),service_name:t==='grpc',obfs_password:p==='hysteria2',congestion:p==='tuic',mode:['grpc','xhttp'].includes(t),authority:t==='grpc',spider_x:s==='reality'};
  for(const [name,visible] of Object.entries(fields)) {const field=form.querySelector('[data-field="'+name+'"]'),input=form.elements[name];field.hidden=!visible;input.disabled=!visible;input.required=false;}
  const credential=name=>!(editingNode?.protocol===p && editingNode.credentials?.[name]);
  form.elements.uuid.required=fields.uuid&&credential('uuid');
  form.elements.password.required=['trojan','shadowsocks','hysteria2','tuic'].includes(p)&&credential('password');
  form.elements.sni.required=s==='reality';form.elements.public_key.required=s==='reality';form.elements.path.required=fields.path;form.elements.service_name.required=fields.service_name;
  for(const name of ['uuid','password','obfs_password']) form.elements[name].placeholder=credential(name)?(name==='uuid'?'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx':''):'已保存，留空保留原值';
}
function nodeChoices(keep=true) {
  const form=$('node-form'),spec=config.catalog.find(p=>p.id===form.elements.protocol.value);
  options(form.elements.transport,spec.transports,keep?form.elements.transport.value:null);
  options(form.elements.security,spec.security,keep?form.elements.security.value:(spec.security.includes('tls')?'tls':null));
  securityChoices();
}
function securityChoices() {
  const form=$('node-form'),spec=config.catalog.find(p=>p.id===form.elements.protocol.value);
  const values=spec.security.filter(v=>v!=='reality'||['tcp','grpc','xhttp'].includes(form.elements.transport.value));
  options(form.elements.security,values,form.elements.security.value);nodeFields();
}
function openNode(node=null) {
  if(!config)return;editingNode=node;editRevision=config.revision;
  const form=$('node-form');form.reset();$('node-error').hidden=true;
  const select=form.elements.protocol;select.replaceChildren();for(const p of config.catalog)select.add(new Option(p.label,p.id));
  select.value=node?.protocol || 'vless';nodeChoices(false);
  if(node) {for(const [key,value] of Object.entries(node)) if(form.elements[key] && typeof value!=='object') form.elements[key].value=value;}
  securityChoices();$('node-title').textContent=node?'编辑节点':'添加节点';$('node-sharing').textContent=node&&config.bindings.filter(b=>b.node_id===node.id).length>1?'这个节点有多行共用。修改这里的参数会影响这些行；只改一个 MAC 时，请在对应行粘贴新的节点链接。':'';$('node-dialog').showModal();form.elements.name.focus();
}
function confirmChange(title,text,input) {pendingAction={...input,revision:config.revision};$('confirm-title').textContent=title;$('confirm-text').textContent=text;$('confirm-error').hidden=true;$('confirm-dialog').showModal();}
async function change(input) {const owner=page;acceptConfig(await api('/api/config/change',input));message('配置已保存；业务运行状态请查看页面提示。',true,owner);}
$('node-form').addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;submit(form,async()=>{
  const node=Object.fromEntries(new FormData(form));node.port=Number(node.port);if(editingNode)node.id=editingNode.id;
  await change({action:'save_node',revision:editRevision,node});$('node-dialog').close();form.reset();showPage('fixed');
},'node-error');});
$('confirm-action').addEventListener('click',async()=>{
  $('confirm-action').disabled=true;try {await change(pendingAction);$('confirm-dialog').close();} catch(error) {$('confirm-error').textContent=error.message;$('confirm-error').hidden=false;} finally {$('confirm-action').disabled=false;}
});
$('node-protocol').addEventListener('change',()=>nodeChoices(false));$('node-transport').addEventListener('change',securityChoices);$('node-security').addEventListener('change',nodeFields);
$('add-node').addEventListener('click',addRow);
$('manual-node').addEventListener('click',()=>{if(dirtyRows().length){message('请先保存当前修改。');return;}openNode();});
$('row-search').addEventListener('input',()=>{selected.clear();renderConfig();});
$('save-all').addEventListener('click',saveAll);
$('open-paste').addEventListener('click',()=>{$('paste-dialog').showModal();$('paste-links').focus();});
$('paste-form').addEventListener('submit',event=>{event.preventDefault();pasteLines($('paste-links').value);});
$('add-group').addEventListener('click',()=>openGroup());$('rename-group').addEventListener('click',()=>openGroup(activeGroup));
$('delete-group').addEventListener('click',()=>{if(rows.some(r=>r.group_id===activeGroup)){message('请先移走分组内的记录，再删除空分组。');return;}confirmChange('删除空分组','删除“'+groupName(activeGroup)+'”？',{action:'delete_group',id:activeGroup});});
$('group-form').addEventListener('submit',event=>{event.preventDefault();submit(event.currentTarget,async()=>{await change({action:'save_group',revision:config.revision,id:groupEditing||'',name:$('group-name').value.trim()});activeGroup=config.groups.find(g=>g.name===$('group-name').value.trim()).id;$('group-dialog').close();renderConfig();},'group-error');});
$('select-all').addEventListener('change',()=>{selected=new Set($('select-all').checked?visibleRows().map(r=>r.key):[]);renderConfig();});
$('move-target').addEventListener('change',updateSaveState);
$('delete-selected').addEventListener('click',deleteSelected);
$('move-selected').addEventListener('click',()=>submit($('batch-transfer'),()=>moveSelected($('move-target').value)));
$('move-form').addEventListener('submit',event=>{event.preventDefault();submit(event.currentTarget,moveSelected,'move-error');});
$('undo-change').addEventListener('click',()=>{if(hasDrafts()){message('请先保存草稿，再恢复上一版。');return;}confirmChange('恢复上一次配置','将分组、节点、MAC 绑定及三个模式的方案一起恢复到上次保存之前。',{action:'restore_previous'});});
$('reload-config').addEventListener('click',()=>{if(hasDrafts()){$('discard-dialog').showModal();return;}const owner=page;loadConfig().catch(e=>message(e.message,false,owner));});
$('discard-reload').addEventListener('click',async()=>{const owner=page;try{const data=await api('/api/config');rows=[];modeDrafts.clear();acceptConfig(data);$('discard-dialog').close();message('已重新读取。',true,owner);}catch(error){message(error.message,false,owner);}});
window.addEventListener('beforeunload',event=>{if(hasDrafts()){event.preventDefault();event.returnValue='';}});
const modeDrafts=new Map();
const modeNames={fixed:'固定绑定',rotation:'租约轮询',dynamic:'动态会话'};
Object.assign(errors,{invalid_mode_plan:'模式方案格式不正确。',business_interface_required:'请填写业务接口。',invalid_business_interface:'接口名无效或重复，请填写实际网口或桥名。',invalid_network_address:'请填写有效的 IPv4 地址。',invalid_subnet:'请填写带掩码长度的内网段，例如 192.168.20.0/24。',subnet_not_network_address:'请填写网段起始地址，例如 192.168.20.0/24，而非设备地址。',private_subnet_required:'业务网段应使用 10、172.16–31 或 192.168 开头的私有地址范围。',gateway_outside_subnet:'网关必须位于该网段内，不能使用网络或广播地址。',invalid_dhcp_range:'地址池必须在网段内、起点不大于终点，并避开网关。',mode_interface_conflict:'该接口已被另一种模式占用，请使用独立接口或 VLAN。',mode_subnet_conflict:'网段与另一种模式的已保存方案重叠，请重新分配。',pool_nodes_required:'请至少选择或粘贴一个节点。',duplicate_pool_node:'节点池存在重复节点，请删除重复项。',invalid_dynamic_kind:'请选择动态出口来源。',invalid_session_limits:'会话时间为 60–86400 秒，并发上限为 1–200。',insufficient_dhcp_addresses:'地址池数量少于配置的并发会话上限。',upstream_requires_one_node:'供应商动态出口模式只选择一个入口节点；多个入口请使用节点池会话。',mode_plan_not_found:'还没有已保存的模式方案。'});
function hasDrafts(){return dirtyRows().length>0||modeDrafts.size>0;}
function modeDraft(mode){
  if(modeDrafts.has(mode))return modeDrafts.get(mode);
  const saved=config.mode_plans[mode]||{};
  return {revision:config.revision,interfaces:list(saved.interfaces).join(', '),subnet:saved.subnet||'',gateway:saved.gateway||'',dhcp_start:saved.dhcp_start||'',dhcp_end:saved.dhcp_end||'',node_ids:[...list(saved.node_ids)],dynamic_kind:saved.dynamic_kind||'upstream',session_seconds:saved.session_seconds||1800,max_sessions:saved.max_sessions||32,links:''};
}
function changeDraft(mode,draft){modeDrafts.set(mode,draft);const status=$('mode-draft-'+mode);if(status)status.textContent='有未保存的方案修改；切换菜单会保留。';}
function modeField(form,mode,draft,name,title,placeholder,type='text'){
  const label=element('label',title),input=element('input','');input.name=name;input.type=type;input.value=draft[name];input.placeholder=placeholder;input.autocomplete='off';input.maxLength=128;
  input.addEventListener('input',()=>{draft[name]=type==='number'?Number(input.value):input.value;changeDraft(mode,draft);});label.append(input);form.append(label);return input;
}
function renderModePanels(){
  if(!config)return;
  $('fixed-plan-state').textContent=config.mode_plans.fixed?'方案已保存 · 未下发':'尚未配置';
  for(const mode of Object.keys(modeNames))renderModePanel(mode);
}
function renderModePanel(mode){
  const root=$('mode-'+mode),draft=modeDraft(mode),saved=config.mode_plans[mode];root.replaceChildren();
  const status=element('div','','mode-status');status.append(element('strong',saved?'方案已保存':'尚未配置'),element('span','运行未接入','badge pending'),element('p','网络规则、DHCP 和真实代理尚未下发；实际租约与会话数据暂不可用。','subtle'));root.append(status);
  const form=element('form','','mode-form');form.autocomplete='off';
  const network=element('section','','mode-card');network.append(element('h3','业务网络'),element('p','多个接口用英文逗号分隔，可规划同模式多口共池。实际接线与 VLAN 需在设备上核对。','subtle'));
  const fields=element('div','','form-grid');
  modeField(fields,mode,draft,'interfaces','业务接口','例如：br-business 或 eth1, eth2');
  modeField(fields,mode,draft,'subnet','内网网段','例如：192.168.20.0/24');
  modeField(fields,mode,draft,'gateway','网关地址','例如：192.168.20.1');
  modeField(fields,mode,draft,'dhcp_start','地址池起点','例如：192.168.20.50');
  modeField(fields,mode,draft,'dhcp_end','地址池终点','例如：192.168.20.249');
  const netResult=element('p','可读取本机接口和已知路由，检查拟用网段是否重叠；不会修改网络。','network-check');
  const netTools=element('div','','toolbar');
  netTools.append(button('识别本机接口',async()=>{netResult.textContent='正在读取…';try{const data=await api('/api/network/status');netResult.textContent=data.available?'本机接口：'+list(data.interfaces).map(x=>x.name+(list(x.roles).length?'（'+list(x.roles).join('、')+'）':'')).join('；')+'。管理口和上网口不要直接改作业务口。':'尚未获取实机接口，不能自动判断。';}catch(e){netResult.textContent=e.message;}}),
    button('检查网段冲突',async()=>{netResult.textContent='正在检查…';try{const data=await api('/api/network/check',{subnet:draft.subnet});netResult.textContent=data.verdict==='unknown'?'未获取本机网络，检查结果未知。':data.verdict==='conflict'?'发现重叠：'+list(data.conflicts).map(x=>x.cidr+'（'+x.interface+'）').join('；'):'与本机已知接口和路由没有重叠。不能据此排除离线设备、其他 DHCP 或未发现的网络占用。';}catch(e){netResult.textContent=e.message;}}));
  network.append(fields,netTools,netResult);form.append(network);
  if(mode==='dynamic'){
    const settings=element('section','','mode-card');settings.append(element('h3','会话规则'));
    const grid=element('div','','form-grid'),label=element('label','动态出口来源'),select=element('select','');select.name='dynamic_kind';select.add(new Option('供应商动态出口（单个入口）','upstream'));select.add(new Option('本机节点池会话（多个节点）','session_pool'));select.value=draft.dynamic_kind;
    select.addEventListener('change',()=>{draft.dynamic_kind=select.value;changeDraft(mode,draft);});label.append(select);grid.append(label);
    const duration=modeField(grid,mode,draft,'session_seconds','本机会话保持（秒）','60–86400','number');duration.min=60;duration.max=86400;
    const limit=modeField(grid,mode,draft,'max_sessions','并发会话上限','1–200','number');limit.min=1;limit.max=200;
    settings.append(grid,element('p','供应商动态出口是否换 IP 由上游决定；本机会话保持时间不控制供应商的换 IP 周期。节点池会话按配置的节点建立会话。','subtle'));form.append(settings);
  }
  if(mode!=='fixed'){
    const pool=element('section','','mode-card');pool.append(element('h3',mode==='rotation'?'有序节点池':'会话入口节点'),element('p',mode==='rotation'?'按下列顺序轮询，新租约走下一个节点；续租保持原分配。节点故障按阻断策略处理，不自动跳过或直连。':'选择一个供应商动态入口，或为本机节点池会话选择多个节点。','subtle'));
    const choices=element('div','','pool-picker'),select=element('select','');select.setAttribute('aria-label',modeNames[mode]+'已有节点');select.add(new Option('选择已保存节点',''));
    for(const n of config.nodes.filter(n=>!draft.node_ids.includes(n.id)))select.add(new Option(n.name+' · '+protocolName(n.protocol)+' · '+n.server,n.id));
    choices.append(select,button('加入节点池',()=>{if(!select.value){message('请先选择节点。');return;}draft.node_ids.push(select.value);changeDraft(mode,draft);renderModePanel(mode);},'secondary'));pool.append(choices);
    const ordered=element('ol','','node-pool');
    draft.node_ids.forEach((id,i)=>{const n=config.nodes.find(n=>n.id===id),row=element('li','');row.append(element('span',n?n.name+' · '+nodeDescription(n)+' · '+n.server:'节点已不存在，请移除'));
      const up=button('上移',()=>{if(i===0)return;[draft.node_ids[i-1],draft.node_ids[i]]=[draft.node_ids[i],draft.node_ids[i-1]];changeDraft(mode,draft);renderModePanel(mode);},'text-button');up.disabled=i===0;
      const down=button('下移',()=>{if(i>=draft.node_ids.length-1)return;[draft.node_ids[i+1],draft.node_ids[i]]=[draft.node_ids[i],draft.node_ids[i+1]];changeDraft(mode,draft);renderModePanel(mode);},'text-button');down.disabled=i===draft.node_ids.length-1;
      row.append(up,down,button('移除',()=>{draft.node_ids.splice(i,1);changeDraft(mode,draft);renderModePanel(mode);},'text-button danger'));ordered.append(row);
    });pool.append(ordered);
    if(!draft.node_ids.length)pool.append(element('p','尚未选择节点，可从已有节点加入或在下方粘贴。','subtle'));
    const label=element('label','粘贴新节点链接（一行一个）'),links=element('textarea','');links.rows=4;links.maxLength=120000;links.value=draft.links;links.placeholder='vless://…\nvmess://…\ntrojan://…';links.spellcheck=false;links.autocomplete='off';
    let linkTimer;links.addEventListener('input',()=>{draft.links=links.value;changeDraft(mode,draft);clearTimeout(linkTimer);linkTimer=setTimeout(previewPoolLinks,450);});label.append(links);pool.append(label);
    const result=element('p','','subtle');result.setAttribute('role','status');
    async function previewPoolLinks(){if(!links.isConnected||!config)return;const value=draft.links;const lines=value.split(/\r?\n|\r/).map(s=>s.trim()).filter(Boolean);if(!lines.length){result.textContent='请先粘贴节点链接。';return;}try{const data=await api('/api/config/preview',{links:lines});if(draft.links!==value)return;result.textContent=list(data.results).map((n,i)=>'第 '+(i+1)+' 行：'+(n.error?(errors[n.error]||'识别失败'):n.name+' · '+nodeDescription(n))).join('；');}catch(error){result.textContent=error.message;}}
    pool.append(button('重新识别链接',previewPoolLinks,'secondary'),result);form.append(pool);
  }
  const footer=element('div','','mode-actions'),state=element('span',modeDrafts.has(mode)?'有未保存的方案修改；切换菜单会保留。':'方案与固定绑定记录一起支持“恢复上一次配置”。','subtle');state.id='mode-draft-'+mode;
  const save=element('button','检查并保存方案');save.type='submit';footer.append(state,save);
  if(saved)footer.append(button('移除本模式方案',()=>{if(hasDrafts()){message('请先保存或放弃草稿。');return;}confirmChange('移除'+modeNames[mode]+'方案','只移除本模式网络与分配方案，保留节点和固定绑定记录。',{action:'delete_mode',mode});},'text-button danger'));
  footer.append(button('放弃本模式草稿',()=>{modeDrafts.delete(mode);renderModePanel(mode);},'text-button'));form.append(footer);
  form.addEventListener('submit',async event=>{event.preventDefault();save.disabled=true;try{
    const plan={interfaces:draft.interfaces.split(',').map(s=>s.trim()).filter(Boolean),subnet:draft.subnet.trim(),gateway:draft.gateway.trim(),dhcp_start:draft.dhcp_start.trim(),dhcp_end:draft.dhcp_end.trim(),node_ids:draft.node_ids};
    if(mode==='dynamic')Object.assign(plan,{dynamic_kind:draft.dynamic_kind,session_seconds:draft.session_seconds,max_sessions:draft.max_sessions});
    const links=draft.links.split(/\r?\n|\r/).map(s=>s.trim()).filter(Boolean),input={action:'save_mode',revision:draft.revision,mode,plan,...(links.length?{links}:{})};
    if(links.length>200||new TextEncoder().encode(JSON.stringify(input)).length>131072)throw new Error('每批最多 200 条链接 / 128KiB。');
    const data=await api('/api/config/change',input);modeDrafts.delete(mode);acceptConfig(data);message(modeNames[mode]+'方案已保存；实际网络尚未下发。',true,mode);
  }catch(error){message(error.message,false,mode);}finally{save.disabled=false;}});
  root.append(form);
}
$('refresh-device-status').addEventListener('click',loadDeviceStatus);
$('refresh-update-status').addEventListener('click',loadUpdateStatus);
for(const e of document.querySelectorAll('[data-close]'))e.addEventListener('click',()=>$(e.dataset.close).close());
for(const e of document.querySelectorAll('[data-page]'))e.addEventListener('click',()=>showPage(e.dataset.page));
$('enroll').addEventListener('click',()=>submit($('activation'),async()=>{const data=await api('/api/enrollment');$('machine-code').value=data.machine_code;message('机器码已生成，请复制给管理员。',true);}));
$('activation-form').addEventListener('submit',event=>{event.preventDefault();submit(event.currentTarget,async()=>{const data=await api('/api/activate',{code:$('authorization-code').value.trim()});showState(data.license);$('authorization-code').value='';renewal=false;message('授权已更新，请登录设备中心。',true);await refresh();});});
$('login-form').addEventListener('submit',event=>{event.preventDefault();submit(event.currentTarget,async()=>{const data=await api('/api/login',{username:$('username').value.trim(),password:$('password').value});csrf=data.csrf;$('password').value='';await dashboard();});});
$('logout').addEventListener('click',async()=>{try {await api('/api/logout',{});clearWorkspace();renewal=false;$('login').hidden=false;$('activation').hidden=true;}catch(error){message(error.message);}});
$('show-renewal').addEventListener('click',()=>{renewal=true;$('activation-title').textContent='导入新的续期码';$('activation').hidden=false;$('activation').scrollIntoView({behavior:'smooth',block:'start'});});
refresh();setInterval(refresh,15000);

Object.assign(errors,{fixed_core_required:'尚未安装 Xray 核心，请管理员补齐依赖。',fixed_protocol_not_supported:'当前固定转发执行器仅支持 VLESS；其他协议暂时只能保存，未应用本次修改。',fixed_transport_not_supported:'节点传输参数暂不支持实际转发，未应用本次修改。',fixed_bindings_required:'请先保存至少一条带 MAC 的节点绑定。',fixed_existing_lan_only:'当前执行器使用现有 LAN；自定义业务网段方案尚未接入，请管理员检查。',fixed_offload_not_supported:'检测到流量加速规则，请管理员核查后再应用。',fixed_apply_failed:'固定绑定未能应用，请管理员检查；不要把配置已保存视为已经转发。'});
async function loadFixedStatus(){
  const revision=config?.revision;
  try{const value=await api('/api/fixed/status');if(config&&config.revision===revision){config.runtime=value;if(page==='fixed')$('runtime-status').textContent=value.message;}return value;}
  catch(error){if(config&&page==='fixed')$('runtime-status').textContent='无法确认固定转发状态：'+error.message;}
}
$('fixed-apply').addEventListener('click',async()=>{
  if(hasDrafts()){message('请先保存节点和 MAC 修改，再应用固定绑定。',false,'fixed');return;}
  if(!window.confirm('将按当前已保存的 MAC 绑定接通固定出口，现有连接可能短暂重连。节点不可用时阻断该设备外网，不回落本地宽带。是否应用？'))return;
  $('fixed-apply').disabled=true;
  try{const result=await api('/api/fixed/apply',{revision:config.revision,confirm:true});const d=result.changes;message(d?'本次新增 '+d.added+'、修改 '+d.changed+'、删除 '+d.removed+' 条；当前共 '+result.count+' 条绑定。'+(result.reloaded?'已提交整套转发重载，正在确认运行。':'转发内容未变，无需重启。'):'已提交整套配置，共 '+result.count+' 条绑定。',true,'fixed');
    for(let i=0;i<10;i++){const state=await loadFixedStatus();if(state?.state!=='starting')break;await new Promise(resolve=>setTimeout(resolve,1000));}}
  catch(error){message(error.message,false,'fixed');}
  finally{$('fixed-apply').disabled=false;}
});

const updatePhases={queued:'任务已提交',checking:'正在检查新版本（第 1/2 次，最多约 20 秒）',checking_retry:'更新源连接不稳定，正在重试（第 2/2 次）',checked:'版本检查完成',downloading:'正在下载更新包',downloading_retry:'下载连接中断，正在重新下载（第 2/2 次）',verifying:'正在核对文件完整性',preflight:'正在检查兼容性和可用空间',ready:'检查通过，可以安装',installing:'正在备份并安装',verifying_install:'正在验证更新后的面板',completed:'应用更新完成',rolling_back:'正在恢复更新前版本',rolled_back:'新版本验证失败，已恢复原版本',recovered:'已恢复更新前版本',failed:'操作失败',interrupted:'上次操作被中断，请联系管理员检查'};
Object.assign(errors,{update_dns_failed:'工控机无法解析更新源域名，两次尝试均失败；已保留当前版本。',update_connect_failed:'工控机无法连接更新源，两次尝试均失败；已保留当前版本。',update_timeout:'更新源响应超时，两次尝试均未完成；已保留当前版本，可稍后重试。',update_tls_failed:'更新源加密连接失败，两次尝试均未完成；已保留当前版本。',update_certificate_failed:'更新源证书验证失败，已停止下载；请检查设备时间与证书环境。',update_http_failed:'更新源返回错误状态，未下载成功；当前版本保留。',update_write_failed:'更新文件写入失败，请检查设备存储。',preview_only:'演示环境不能执行设备更新。',check_release_first:'请先联网检查官方版本，取得可信校验信息。',release_changed:'版本信息已变化，请重新检查。',no_newer_release:'当前没有可安装的更新版本。',update_busy:'已有更新任务正在执行，请等待完成。',update_confirmation_required:'请先下载并完成检查，再确认安装。',recovery_unavailable:'没有可以恢复的应用备份。',invalid_update_upload:'文件大小或格式不符合所选发布版本。',package_hash_mismatch:'更新包校验不一致，已停止操作。',download_failed:'无法连接官方更新源，请检查设备网络后重试。',invalid_release_metadata:'官方版本信息不完整或格式不正确，已停止更新。',invalid_update_archive:'更新包内容不符合安装格式，已拒绝。',preflight_failed:'兼容性或空间检查未通过，未执行安装。',storage_reserve_required:'可用空间不足，需要保留至少 2 GiB 余量。',install_failed:'安装失败，请检查任务记录；安装器会尝试恢复已修改的应用文件。',recovery_failed:'恢复失败，请联系管理员检查应用备份。',recovery_health_failed:'恢复后服务验证未通过，请联系管理员。',new_version_health_failed:'新版本验证失败，已回退到原版本。',update_interrupted:'上次更新被中断，不能确认结果，请联系管理员检查。',update_failed:'更新未完成，请联系管理员检查本机任务日志。'});
function disableUpdateActions(){for(const id of ['check','apply','upload','recover'])$('update-'+id).disabled=true;}
function renderUpdateManager(manager){
  updateManager=manager;disableUpdateActions();clearTimeout(updatePoll);
  if(!manager?.enabled)return;
  const running=!!manager.job?.busy,available=manager.availability==='available';
  $('update-check').disabled=running;$('update-upload').disabled=running||!available;
  $('update-apply').disabled=running||!available;$('update-apply').textContent=manager.staged?'安装已导入版本':'立即更新';$('update-recover').disabled=running||!manager.recoverable;
  const checkFailed=manager.job?.action==='check'&&manager.job?.phase==='failed';
  $('update-source').textContent=checkFailed?'本次检查失败':running?'操作进行中':manager.availability==='unchecked'?'尚未检查':available?'发现新版本':manager.availability==='current'?'已是最新版本':'本机版本不低于发布版';
  $('update-source-detail').textContent=manager.release?(checkFailed?'上次获知版本 v':'更新源版本 v')+manager.release.version:'点击“检查新版本”获取发布信息';
  const job=manager.job;$('update-status-message').textContent=job?(updatePhases[job.phase]||'状态未知')+(job.error?' · '+(errors[job.error]||'请联系管理员检查'):''):'更新仅在你点击后执行，不会后台自动安装。';
  $('update-online-reason').textContent=manager.availability==='current'?'本机已安装这个版本，无需重复下载。检查新版本只查询版本信息，不会自动安装。':'检查新版本只查询信息；发现新版本后，点击“立即更新”，自动完成下载、校验、备份和安装。';
  $('update-offline-reason').textContent='需先联网取得该版本的官方校验信息；之后可导入同版本文件（最大 2 MiB）。不接受任意来源的安装包。';
  $('update-history').textContent=list(manager.history).length?list(manager.history).map(x=>date(x.at)+' · '+(updatePhases[x.phase]||x.phase)+(x.error?' · '+(errors[x.error]||'操作异常'):'')).join('\n'):'还没有通过本页执行更新的记录。';
  $('update-release-notes').textContent=manager.release?.notes||'';
  $('update-checked').textContent=(manager.last_check?.at?'最近成功检查：'+date(manager.last_check.at):'尚无成功检查时间记录')+(job?.finished_at?' · 最近操作：'+date(job.finished_at):'');
  if(running&&page==='updates'&&config&&updatePollCount++<180)updatePoll=setTimeout(()=>loadUpdateStatus({quiet:true}),2000);
  if(!running)updatePollCount=0;
}
async function runUpdate(action,extra={}){
  if((action==='apply'||action==='upgrade'||action==='recover')&&hasDrafts()){message('请先保存或放弃其他页面的未保存修改，再执行更新。',false,'updates');return;}
  disableUpdateActions();$('update-status-message').textContent='正在提交操作…';
  try{await api('/api/update/action',{action,build_id:updateManager?.release?.build_id,...extra});updatePollCount=0;await loadUpdateStatus();}
  catch(error){renderUpdateManager(updateManager);$('update-status-message').textContent=error.message;}
}
$('update-check').addEventListener('click',()=>runUpdate('check'));
for(const action of ['apply','recover'])$('update-'+action).addEventListener('click',()=>{
  pendingUpdateAction=action==='apply'&&!updateManager.staged?'upgrade':action;pendingUpdateBuild=updateManager?.release?.build_id;$('update-confirm-title').textContent=action==='apply'?'安装品牌应用更新':'恢复更新前的品牌应用';
  $('update-confirm-text').textContent=action==='apply'?'将安装 v'+updateManager.release.version+'，自动下载、校验、备份并安装。期间面板可能短暂重连，不会刷写 iStoreOS 系统。':'仅恢复应用文件，不撤销你后来保存的节点、分组和授权。';$('update-confirm').showModal();
});
$('update-confirm-run').addEventListener('click',()=>{$('update-confirm').close();runUpdate(pendingUpdateAction,{confirm:true,build_id:pendingUpdateBuild});});
$('update-upload').addEventListener('click',()=>$('update-file').click());
$('update-file').addEventListener('change',async()=>{
 const file=$('update-file').files[0];$('update-file').value='';if(!file)return;
 if(file.size>2097152){$('update-status-message').textContent='更新包超过 2 MiB 上限。';return;}
 const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
 await runUpdate('upload',{package:btoa(binary).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'')});
});

let accountInfo=null;
Object.assign(errors,{account_unavailable:'账号状态异常，请联系管理员；未覆盖原有设置。',invalid_panel_password:'密码应为 8–128 个字符，不能包含换行。',current_password_incorrect:'当前面板密码不正确。',invalid_recovery_code:'恢复码不正确、已使用或不属于这台设备。',account_changed:'账号刚刚发生变化，请重新登录。',passwordless_confirmation_required:'请确认免密登录的影响。',initial_setup_required:'请先选择是否设置面板密码。'});
function setLoginAccount(info){if(!info)return;accountInfo=info;if(document.activeElement!==$('username'))$('username').value=info.username;$('password').required=info.password_required;$('password').disabled=!info.password_required;$('login-security').textContent=info.first_setup?'首次登录密码留空，进入后选择是否设置密码。':info.password_required?'':'本机已选择免密登录；可在系统设置中启用密码。';}
function accountMode(){const none=$('account-mode').value==='none';$('new-password-fields').hidden=none;$('passwordless-label').hidden=!none;$('new-panel-password').required=!none;$('confirm-panel-password').required=!none;}
async function loadAccount(){try{const info=await api('/api/account');accountInfo=info;$('account-status').textContent=info.first_setup?'首次设置：请选择设置密码，或确认免密登录。':'当前账号：'+info.username+' · '+(info.password_required?'密码登录':'免密登录');$('current-password-label').hidden=!info.password_required;$('current-panel-password').required=info.password_required;}catch(e){$('account-status').textContent=e.message;}}
function showRecoveryCode(result){clearWorkspace();$('login').hidden=false;$('activation').hidden=true;setLoginAccount({username:result.username,password_required:result.mode==='password',mode:result.mode});$('new-recovery-code').value=result.recovery_code;$('recovery-result').showModal();}
$('account-mode').addEventListener('change',accountMode);accountMode();
$('account-form').addEventListener('submit',e=>{e.preventDefault();submit(e.currentTarget,async()=>{if(hasDrafts())throw new Error('请先保存或放弃其他页面的草稿，再修改账号。');const mode=$('account-mode').value;if(mode==='password'&&$('new-panel-password').value!==$('confirm-panel-password').value)throw new Error('两次新密码不一致。');const result=await api('/api/account/change',{mode,current_password:$('current-panel-password').value,new_password:$('new-panel-password').value,confirm_no_password:$('passwordless-confirm').checked});e.target.reset();accountMode();showRecoveryCode(result);});});
for(const id of ['forgot-password','forgot-password-locked'])$(id).addEventListener('click',()=>{$('recover-account-form').reset();$('recover-error').hidden=true;$('recover-account').showModal();});
$('recover-account-form').addEventListener('submit',e=>{e.preventDefault();submit(e.currentTarget,async()=>{if($('recover-new-password').value!==$('recover-confirm-password').value)throw new Error('两次新密码不一致。');const result=await api('/api/account/recover',{recovery_code:$('recovery-code').value.trim(),new_password:$('recover-new-password').value});e.target.reset();$('recover-account').close();showRecoveryCode(result);},'recover-error');});
$('recovery-saved').addEventListener('click',()=>{$('new-recovery-code').value='';$('recovery-result').close();void refresh();});
$('recovery-result').addEventListener('cancel',e=>e.preventDefault());
$('download-recovery').addEventListener('click',()=>{const link=document.createElement('a');link.href=URL.createObjectURL(new Blob(['工控机管理系统面板恢复码\n账号：root\n'+$('new-recovery-code').value+'\n仅用于本机密码恢复，请安全保存。\n'],{type:'text/plain;charset=utf-8'}));link.download='工控机管理系统-恢复码.txt';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);});


// One saved node at a time; no background periodic testing.
const probeResults=new Map(),probeQueue=[];let probeBusy=false,probeAbort=null;
function paintProbe(id){
  const r=probeResults.get(id),text=!r?'尚未测试':r.state==='queued'?'等待测试':r.state==='testing'?'正在测试连接…':r.state==='reachable'?'可连接 · HTTPS 延迟 '+r.latency_ms+' ms · '+date(r.checked_at):r.state==='unreachable'?'连接失败 · '+date(r.checked_at):r.message||'测试失败';
  document.querySelectorAll('.probe-status').forEach(p=>{if(p.dataset.node===id)p.textContent=text;});
}
function queueProbe(id,manual=false){
  if(!config?.nodes.some(n=>n.id===id)||probeQueue.includes(id)||probeResults.get(id)?.state==='testing')return;
  if(!manual&&probeResults.has(id))return;
  probeResults.set(id,{state:'queued'});probeQueue.push(id);paintProbe(id);runProbeQueue();
}
async function runProbeQueue(){
  if(probeBusy)return;probeBusy=true;
  try{while(probeQueue.length&&config){
    const id=probeQueue.shift(),revision=config.revision;
    if(!config.nodes.some(n=>n.id===id))continue;
    const ticket={state:'testing'};probeResults.set(id,ticket);paintProbe(id);
    probeAbort=new AbortController();const timeout=setTimeout(()=>probeAbort?.abort(),15000);
    try{const result=await api('/api/node/test',{node_id:id,revision},probeAbort.signal);if(config&&config.revision===revision&&probeResults.get(id)===ticket)probeResults.set(id,result);else if(probeResults.get(id)===ticket){probeResults.delete(id);if(config)queueProbe(id);}}
    catch(error){if(config&&probeResults.get(id)===ticket)probeResults.set(id,{state:'error',message:error.message});}
    finally{clearTimeout(timeout);probeAbort=null;}
    paintProbe(id);await new Promise(resolve=>setTimeout(resolve,700));
  }}finally{probeBusy=false;}
}
Object.assign(errors,{probe_protocol_unsupported:'此协议暂不支持实测，不代表连接成功。',probe_core_required:'未安装测试所需的代理核心。',probe_config_invalid:'节点参数未通过核心检查。',probe_failed:'测试未完成，请稍后重试。',lock_busy:'另一项测试进行中，请稍后重试。'});

// Network repair is explicit. No periodic background scans or automatic renumbering.
let networkRepairPlan=null;
Object.assign(errors,{network_repair_busy:'网络修复进行中，请先完成确认或等待恢复。',network_repair_failed:'无法执行网络修复，请重新检查；如仍失败，请管理员处理。未确认的修改会尝试自动恢复。'});
function renderNetworkRepair(data) {
  networkRepairPlan=data;
  const op=data.operation;
  const states={prepared:'已安排修复，请记下新地址并重新连接 Wi-Fi。',applying:'正在调整网络，请重新连接 Wi-Fi 后打开新地址。',waiting:'请确认可以正常上网，再保留修改。',confirmed:'已确认并保留新网络地址。',rolled_back:'未完成确认或修复失败，已恢复原网络配置。',rollback_failed:'自动恢复未完成，需要管理员处理。请保留现场，不要反复修改。',rolling_back:'正在恢复原网络配置。',cancelled:'修复未启动，网络配置未改变。'};
  $('network-repair-status').textContent=op&&data.state==='pending'?states[op.phase]:(data.message||states[op?.phase]||'请重新检查网络。');
  const url=data.new_url||op?.new_url,old=data.old_url||op?.old_url;
  $('network-repair-address').textContent=(url?'原地址：'+old+'；新地址：'+url:'')+(op?.deadline&&data.state==='pending'?'；确认截止：'+date(op.deadline):'');
  $('network-repair-start').hidden=data.state!=='conflict';
  $('network-repair-confirm').hidden=!(op?.phase==='waiting'&&location.origin===op.new_url);
  $('network-repair-open').hidden=!url;
  if(url)$('network-repair-open').href=op?.phase==='rolled_back'?old:url;
}
$('network-repair-check').addEventListener('click',async()=>{
  $('network-repair-check').disabled=true;
  try{renderNetworkRepair(await api('/api/network/repair-status'));}
  catch(e){networkRepairPlan=null;$('network-repair-start').hidden=true;$('network-repair-confirm').hidden=true;$('network-repair-status').textContent=e.message;}
  finally{$('network-repair-check').disabled=false;}
});
$('network-repair-start').addEventListener('click',async()=>{
  const p=networkRepairPlan;if(p?.state!=='conflict')return;
  if(!window.confirm('将更换内网地址并短暂断网。新管理地址：'+p.new_url+'。请重新连接 Wi-Fi、登录新地址并在 4 分钟内确认；否则尝试恢复。是否继续？'))return;
  $('network-repair-start').disabled=true;
  try{const op=await api('/api/network/repair',{action:'start',confirm:true,new_ip:p.new_ip,fingerprint:p.fingerprint});renderNetworkRepair({state:'pending',operation:op});}
  catch(e){$('network-repair-status').textContent='请求结果未确认。请先尝试页面显示的新地址，或等待 4 分钟恢复，再检查。';}
  finally{$('network-repair-start').disabled=false;}
});
$('network-repair-confirm').addEventListener('click',async()=>{
  const op=networkRepairPlan?.operation;if(!op||location.origin!==op.new_url)return;
  $('network-repair-confirm').disabled=true;
  try{const saved=await api('/api/network/repair',{action:'confirm',id:op.id});renderNetworkRepair({operation:saved});}
  catch(e){$('network-repair-status').textContent=e.message;}
  finally{$('network-repair-confirm').disabled=false;}
});
