-- Isolated, bounded proxy HTTPS probe. Never changes running bindings or routes.
local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local nixio=require 'nixio'
local M={}
function M.config(node,port)
    assert(node.protocol=='vless','probe_protocol_unsupported')
    return {log={loglevel='none'},inbounds={{listen='127.0.0.1',port=port,protocol='socks',settings={auth='noauth',udp=false}}},
        outbounds={require('brand_router.fixed_plan').outbound(node,'probe')}}
end
function M.parse(raw,alive)
    local code,seconds=(raw or ''):match('^(%d%d%d) ([%d.]+)$')
    seconds=tonumber(seconds)
    if alive and code=='204' and seconds and seconds>0 and seconds<=9 then
        return {state='reachable',latency_ms=math.floor(seconds*1000+0.5),checked_at=os.time(),method='proxy_https'}
    end
    return {state='unreachable',checked_at=os.time(),method='proxy_https'}
end
function M.run(c,node)
    assert(util.exec('test -x /usr/bin/xray'),'probe_core_required')
    -- Kernel-owned lock cannot remain held after worker death. Keep its inode.
    local lock=assert(nixio.open(c.probe_lock or '/var/lock/brand-node-probe.fd','w',384),'state_busy')
    if not lock:lock('tlock') then lock:close();error('state_busy') end
    local dir,pid,watchdog,reaped
    local outer_ok,outer_result=pcall(function()
        dir=util.tempdir(c.temp_parent or '/tmp')
        local ok,result=pcall(function()
            local port=43000+tonumber(util.random_hex(2),16)%10000
            util.write(dir..'/xray.json',json.stringify(M.config(node,port)))
            assert(util.exec('xray run -test -c '..util.quote(dir..'/xray.json')..' >/dev/null 2>&1'),'probe_config_invalid')
            pid=assert(nixio.fork(),'probe_start_failed')
            if pid==0 then
                nixio.exec('/bin/sh','-c','exec /usr/bin/xray run -c '..util.quote(dir..'/xray.json')..' >/dev/null 2>&1');os.exit(127)
            end
            -- Independent short-lived watchdog also cleans up if the HTTP worker disappears.
            watchdog=assert(nixio.fork(),'probe_start_failed')
            if watchdog==0 then
                nixio.nanosleep(12)
                local cmd=util.read('/proc/'..pid..'/cmdline',8192) or ''
                if cmd:find(dir..'/xray.json',1,true) then pcall(nixio.kill,pid,9) end
                util.cleanup(dir,{'xray.json'})
                lock:close()
                os.exit(0)
            end
            nixio.nanosleep(0,300000000)
            if nixio.waitpid(pid,'nohang')==pid then reaped=true;return M.parse(nil,false) end
            local raw=util.capture('curl --silent --show-error --noproxy "" --proxy '..util.quote('socks5h://127.0.0.1:'..port)..
                ' --connect-timeout 4 --max-time 8 --proto "=https" -o /dev/null --write-out "%{http_code} %{time_starttransfer}" https://www.gstatic.com/generate_204 2>/dev/null',128)
            local alive=nixio.waitpid(pid,'nohang')~=pid;reaped=not alive
            return M.parse(raw,alive)
        end)
        if pid and not reaped then pcall(nixio.kill,pid,9);pcall(nixio.waitpid,pid) end
        if watchdog then pcall(nixio.kill,watchdog,9);pcall(nixio.waitpid,watchdog) end
        util.cleanup(dir,{'xray.json'})
        if not ok then error(result,0) end
        return result
    end)
    lock:close()
    if not outer_ok then
        if dir then util.cleanup(dir,{'xray.json'}) end
        error(outer_result,0)
    end
    return outer_result
end
function M.test(c,input)
    assert(not c.allow_lab_http,'preview_only')
    assert(type(input.node_id)=='string' and #input.node_id==32 and input.node_id:match('^[a-f0-9]+$'),'node_not_found')
    local doc=require('brand_router.business').load(c)
    assert(doc.revision==input.revision,'revision_conflict')
    local node=doc.nodes[input.node_id];assert(node,'node_not_found')
    assert(node.protocol=='vless','probe_protocol_unsupported')
    return M.run(c,node)
end
return M
