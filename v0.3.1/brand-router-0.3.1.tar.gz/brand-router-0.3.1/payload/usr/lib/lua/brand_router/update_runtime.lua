local updater=require 'brand_router.updater'
local archive=require 'brand_router.update_archive'
local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local M={}
local function check(ok,code) assert(ok,code) end
local function digest(path) return (util.capture('sha256sum '..util.quote(path),1024) or ''):match('^([0-9a-f]+)') end
function M.create(context)
    local root=updater.root(context);local stage=root..'/staging';local backend={}
    local function space()
        local raw=util.capture('df -Pk '..util.quote(root),4096) or ''
        local free=tonumber(raw:match('\n[^\n]+%s+%d+%s+%d+%s+(%d+)%s+%d+%%'))
        check(free and free>=2117632,'storage_reserve_required')
    end
    local function download(url,path,limit,seconds)
        check(util.exec('curl --fail --location --proto "=https" --proto-redir "=https" --connect-timeout 10 --max-time '..(seconds or 120)..' --max-filesize '..limit..' --silent --show-error '..util.quote(url)..' -o '..util.quote(path)..' 2>/dev/null'),'download_failed')
        local st=fs.lstat(path);check(st and st.type=='reg' and st.size<=limit,'update_package_too_large')
    end
    function backend.check()
        local file=root..'/release-download.json'
        download(updater.BASE..'/stable.json',file,16384,20)
        local data=json.parse(util.read(file,16384) or '');fs.unlink(file);return data
    end
    function backend.prepare(release,uploaded,phase)
        space();check(util.exec('rm -rf '..util.quote(stage)..' && mkdir -m 700 '..util.quote(stage)),'update_failed')
        local package=stage..'/package.tar.gz'
        if uploaded then check(fs.rename(root..'/upload.bin',package),'invalid_update_upload')
        else download(updater.BASE..'/v'..release.version..'/brand-router-'..release.version..'.tar.gz',package,updater.MAX_PACKAGE) end
        check(fs.lstat(package).size==release.bytes and digest(package)==release.sha256,'package_hash_mismatch');phase('verifying')
        -- Bound decompression independently of the compressed-size limit.
        check(util.exec('gzip -dc '..util.quote(package)..' 2>/dev/null | head -c 8388609 > '..util.quote(stage..'/payload.tar')),'invalid_update_archive')
        local raw=util.read(stage..'/payload.tar',8388608);check(raw,'invalid_update_archive')
        local bundle=stage..'/bundle';check(fs.mkdir(bundle,'700'),'update_failed')
        local build=archive.extract(raw,release.version,bundle);check(build.build_id==release.build_id,'package_hash_mismatch')
        fs.unlink(stage..'/payload.tar');phase('preflight')
        check(util.exec('sh '..util.quote(bundle..'/install.sh')..' plan > '..util.quote(root..'/operation.log')..' 2>&1'),'preflight_failed')
    end
    local function validated_bundle(directory,release)
        local package=directory..'/package.tar.gz';check(digest(package)==release.sha256,'package_hash_mismatch')
        -- All extracted files must still match the checked package manifest before execution.
        check(util.exec('cd '..util.quote(directory..'/bundle')..' && sha256sum -c checksums.sha256 >/dev/null 2>&1'),'package_hash_mismatch')
        return directory..'/bundle'
    end
    local function recovery_directory(recovery)
        local name=recovery.bundle_name or 'recovery-bundle'
        check(name=='recovery-bundle' or (#name==41 and name:match('^recovery%-[0-9a-f]+$')),'recovery_failed')
        return root..'/'..name
    end
    function backend.install(release)
        space();validated_bundle(stage,release)
        local recovery={backup_id=os.date('!%Y%m%dT%H%M%S')..'-'..tostring(tonumber(util.random_hex(4),16)),
            release=release,bundle_name='recovery-'..util.random_hex(16),account_schema=updater.installed().account_schema,fixed_schema=updater.installed().fixed_schema}
        local directory=recovery_directory(recovery)
        -- Prepare a distinct recovery directory BEFORE changing application files.
        -- The last known recovery package and record remain untouched until commit.
        check(fs.rename(stage,directory),'update_failed')
        local bundle=directory..'/bundle'
        local ok=util.exec('BRAND_UPDATE_BACKUP_ID='..util.quote(recovery.backup_id)..' sh '..util.quote(bundle..'/install.sh')..' apply > '..util.quote(root..'/operation.log')..' 2>&1')
        if not ok then util.exec('/etc/init.d/brand-portal restart >/dev/null 2>&1');error('install_failed') end
        -- No fallible file operation after installation before returning its recovery handle.
        return recovery
    end
    function backend.recover(recovery)
        check(type(recovery)=='table' and type(recovery.backup_id)=='string' and recovery.backup_id:match('^[0-9T-]+$'),'recovery_failed')
        check(not fs.lstat((context.state_dir or '/etc/brand-router/state')..'/panel-account.json') or recovery.account_schema==1,'recovery_account_incompatible')
        check(not fs.lstat((context.fixed_root or '/etc/brand-router/fixed')..'/current.json') or recovery.fixed_schema==1,'recovery_fixed_incompatible')
        local release=updater.manifest(recovery.release);local bundle=validated_bundle(recovery_directory(recovery),release)
        check(util.exec('sh '..util.quote(bundle..'/install.sh')..' rollback '..util.quote(recovery.backup_id)..' > '..util.quote(root..'/operation.log')..' 2>&1'),'recovery_failed')
    end
    function backend.discard(recovery)
        if type(recovery)=='table' and recovery.backup_id then util.exec('rm -rf '..util.quote(recovery_directory(recovery))) end
    end
    function backend.health()
        if not util.exec('/etc/init.d/brand-portal restart >/dev/null 2>&1') then return false end
        local portal=json.parse(util.read('/etc/brand-router/portal.json',16384) or '')
        if not portal or type(portal.origin)~='string' or not portal.origin:match('^https://[%d.]+:%d+$') then return false end
        for _=1,5 do
            local ok=util.exec('curl --fail --noproxy "*" --silent --show-error --max-time 3 --cacert /etc/brand-router/portal.crt '..util.quote(portal.origin..'/api/state')..' -o '..util.quote(root..'/health.json')..' 2>/dev/null')
            local state=ok and json.parse(util.read(root..'/health.json',16384) or '')
            if state and type(state.license)=='table' then fs.unlink(root..'/health.json');return true end
            util.exec('sleep 1')
        end
        return false
    end
    return backend
end
return M
