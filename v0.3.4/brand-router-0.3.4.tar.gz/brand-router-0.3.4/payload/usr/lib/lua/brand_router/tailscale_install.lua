local tool=require 'brand_router.tailscale_tool'
local archive=require 'brand_router.tailscale_archive'
local util=require 'brand_router.util'
local fs=require 'nixio.fs'
local json=require 'luci.jsonc'
local M={}
local function check(ok,code) assert(ok,code) end
function M.create(c)
    local root=tool.root(c);local stage=root..'/download';local backend={}
    local function space()
        local raw=util.capture('df -Pk '..util.quote(root),4096) or ''
        local free=tonumber(raw:match('\n[^\n]+%s+%d+%s+%d+%s+(%d+)%s+%d+%%'))
        check(free and free>=2621440,'tailscale_space_required') -- reserve 2 GiB plus bounded extraction workspace
    end
    local function download(url,path,limit,seconds)
        check(util.exec('curl --fail --location --proto "=https" --proto-redir "=https" --connect-timeout 10 --max-time '..seconds..' --max-filesize '..limit..' --silent --show-error '..util.quote(url)..' -o '..util.quote(path)..' 2>/dev/null'),'tailscale_download_failed')
        local st=fs.lstat(path);check(st and st.type=='reg' and st.size>0 and st.size<=limit,'tailscale_download_failed')
    end
    function backend.preflight()
        local release=util.read('/etc/openwrt_release',4096) or ''
        check(release:find("DISTRIB_ID='iStoreOS'",1,true) and release:match("DISTRIB_RELEASE='24%.10[.']") and (util.capture('uname -m',128) or ''):match('^x86_64%s*$'),'tailscale_unsupported_system')
        check(not util.exec('command -v tailscale >/dev/null 2>&1'),'tailscale_external_install')
        space()
        check(not fs.lstat(stage),'tailscale_install_failed')
        check(fs.mkdir(stage,'700'),'tailscale_install_failed')
    end
    function backend.metadata()
        download(tool.BASE..'?mode=json',stage..'/metadata.json',65536,20)
        return json.parse(util.read(stage..'/metadata.json',65536) or '')
    end
    function backend.install(release,phase,id)
        local package=stage..'/package.tgz';local raw=stage..'/package.tar'
        download(tool.BASE..release.filename..'.sha256',stage..'/checksum',256,20)
        local hash=(util.read(stage..'/checksum',256) or ''):match('^([a-f0-9]+)%s*$')
        check(hash and #hash==64,'tailscale_metadata_invalid')
        download(tool.BASE..release.filename,package,tool.MAX_DOWNLOAD,180)
        local bytes=fs.lstat(package).size
        phase('verifying')
        check((util.capture('sha256sum '..util.quote(package),1024) or ''):match('^([a-f0-9]+)')==hash,'tailscale_hash_mismatch')
        space()
        check(util.exec('gzip -dc '..util.quote(package)..' 2>/dev/null | head -c 268435457 > '..util.quote(raw)),'tailscale_archive_invalid')
        phase('installing')
        local dir=root..'/'..id;check(not fs.lstat(dir) and fs.mkdir(dir,'700'),'tailscale_install_failed')
        local installed_bytes=archive.extract(raw,release.version,dir)
        phase('checking_install')
        local client=util.capture(util.quote(dir..'/tailscale')..' version 2>/dev/null',4096) or ''
        local daemon=util.capture(util.quote(dir..'/tailscaled')..' --version 2>/dev/null',4096) or ''
        check(client:match('^(%d+%.%d+%.%d+)')==release.version and daemon:match('^(%d+%.%d+%.%d+)')==release.version,'tailscale_install_failed')
        return {generation=id,version=release.version,installed_bytes=installed_bytes,download_bytes=bytes,sha256=hash,installed_at=os.time()}
    end
    function backend.cleanup(id,failed)
        -- Only fixed owned paths and a validated job id; no caller-chosen removal path.
        check(type(id)=='string' and #id==32 and id:match('^[a-f0-9]+$'),'tailscale_install_failed')
        for _,name in ipairs({'metadata.json','checksum','package.tgz','package.tar'}) do fs.unlink(stage..'/'..name) end
        fs.rmdir(stage)
        if failed then for _,name in ipairs({'tailscale','tailscaled'}) do fs.unlink(root..'/'..id..'/'..name) end;fs.rmdir(root..'/'..id) end
    end
    return backend
end
return M
