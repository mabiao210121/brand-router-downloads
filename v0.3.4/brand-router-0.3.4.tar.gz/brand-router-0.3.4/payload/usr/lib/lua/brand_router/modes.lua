-- Mode plans only. Validation never changes interfaces, leases or proxy processes.
local M={}
local function check(ok,code) if not ok then error({code=code},0) end end
local function integer(n,lo,hi) return type(n)=='number' and n==math.floor(n) and n>=lo and n<=hi end
local function list(value,max)
    check(type(value)=='table' and #value<=max,'invalid_mode_plan')
    local count=0;for k in pairs(value) do check(integer(k,1,#value),'invalid_mode_plan');count=count+1 end
    check(count==#value,'invalid_mode_plan');return value
end
local function ip(value)
    check(type(value)=='string' and value:match('^%d+%.%d+%.%d+%.%d+$'),'invalid_network_address')
    local result=0
    for part in value:gmatch('%d+') do
        check(#part<=3 and tonumber(part)<=255 and (#part==1 or part:sub(1,1)~='0'),'invalid_network_address')
        result=result*256+tonumber(part)
    end
    return result
end
local function subnet(value)
    check(type(value)=='string','invalid_subnet')
    local address,prefix=value:match('^([^/]+)/(%d+)$');prefix=tonumber(prefix)
    check(address and integer(prefix,8,30),'invalid_subnet')
    local first=ip(address);local size=2^(32-prefix)
    check(first%size==0,'subnet_not_network_address')
    local last=first+size-1
    check((first>=167772160 and last<=184549375) or (first>=2886729728 and last<=2887778303) or
        (first>=3232235520 and last<=3232301055),'private_subnet_required')
    return first,last
end
local known={fixed=true,rotation=true,dynamic=true}
local fields={interfaces=true,subnet=true,gateway=true,dhcp_start=true,dhcp_end=true,node_ids=true,
    dynamic_kind=true,session_seconds=true,max_sessions=true}
function M.validate(mode,input,nodes)
    check(known[mode] and type(input)=='table','invalid_mode_plan')
    for key in pairs(input) do check(fields[key],'invalid_mode_plan') end
    local interfaces,seen={},{}
    for _,name in ipairs(list(input.interfaces,8)) do
        check(type(name)=='string' and #name<=15 and name:match('^[A-Za-z0-9][A-Za-z0-9_.%-]*$') and not seen[name],'invalid_business_interface')
        seen[name]=true;interfaces[#interfaces+1]=name
    end
    check(#interfaces>0,'business_interface_required')
    local first,last=subnet(input.subnet)
    local gateway,start,finish=ip(input.gateway),ip(input.dhcp_start),ip(input.dhcp_end)
    check(gateway>first and gateway<last,'gateway_outside_subnet')
    check(start>first and finish<last and start<=finish and not (gateway>=start and gateway<=finish),'invalid_dhcp_range')
    local ids={};seen={}
    for _,id in ipairs(list(input.node_ids or {},256)) do
        check(type(id)=='string' and nodes[id],'node_not_found');check(not seen[id],'duplicate_pool_node')
        seen[id]=true;ids[#ids+1]=id
    end
    if mode=='fixed' then check(#ids==0,'invalid_mode_plan') else check(#ids>0,'pool_nodes_required') end
    local out={interfaces=interfaces,subnet=input.subnet,gateway=input.gateway,dhcp_start=input.dhcp_start,dhcp_end=input.dhcp_end,node_ids=ids}
    if mode=='dynamic' then
        check(input.dynamic_kind=='upstream' or input.dynamic_kind=='session_pool','invalid_dynamic_kind')
        check(integer(input.session_seconds,60,86400) and integer(input.max_sessions,1,200),'invalid_session_limits')
        check(input.max_sessions<=finish-start+1,'insufficient_dhcp_addresses')
        check(input.dynamic_kind~='upstream' or #ids==1,'upstream_requires_one_node')
        out.dynamic_kind=input.dynamic_kind;out.session_seconds=input.session_seconds;out.max_sessions=input.max_sessions
    else
        check(input.dynamic_kind==nil and input.session_seconds==nil and input.max_sessions==nil,'invalid_mode_plan')
    end
    return out
end
function M.validate_all(plans,nodes)
    check(type(plans)=='table','invalid_mode_plan')
    local interfaces,ranges={},{}
    for mode,plan in pairs(plans) do
        local normalized=M.validate(mode,plan,nodes)
        for _,name in ipairs(normalized.interfaces) do
            check(not interfaces[name],'mode_interface_conflict');interfaces[name]=mode
        end
        local first,last=subnet(normalized.subnet)
        for _,range in ipairs(ranges) do check(last<range[1] or first>range[2],'mode_subnet_conflict') end
        ranges[#ranges+1]={first,last}
    end
    return plans
end
function M.references(plans,id)
    for _,plan in pairs(plans or {}) do for _,node_id in ipairs(plan.node_ids or {}) do if node_id==id then return true end end end
    return false
end
function M.summary(mode,plan)
    return {configured=plan~=nil,applied=false,state='not_connected',
        assignment=mode=='fixed' and 'explicit_mac' or mode=='rotation' and 'new_lease_round_robin' or (plan and plan.dynamic_kind or 'not_configured'),
        network_check='saved_plans_only',live_network_checked=false,
        failure_policy='block_without_direct_fallback',lease_renewal=mode=='rotation' and 'keep_assignment' or nil}
end
return M
