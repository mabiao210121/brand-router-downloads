local json=require 'luci.jsonc'
local util=require 'brand_router.util'
local controller=require 'brand_router.controller'
local M={}
function M.create(context)
    local backend={};local permitted={};local cached_rules
    for _,name in pairs(controller.registry) do permitted[name]=true end
    local nft=util.quote(context.nft or '/usr/sbin/nft')
    local function script(name)
        assert(permitted[name],'unknown_brand_service')
        return util.quote((context.init_dir or '/etc/init.d')..'/'..name)
    end
    function backend.capabilities(site)
        -- Reject all flowtables for now; a future zone-specific adapter may prove a narrower exemption.
        local output=util.capture(nft..' -j list ruleset 2>/dev/null',4194304)
        local rules=output and json.parse(output)
        if not rules or type(rules.nftables)~='table' then return false end
        for _,item in ipairs(rules.nftables) do if item.flowtable then return false end end
        return true
    end
    function backend.firewall(rules)
        local exists=util.exec(nft..' list table inet brand_license >/dev/null 2>&1')
        if exists and cached_rules==rules then return true end
        local dir=util.tempdir(context.temp_parent or '/tmp')
        local batch=(exists and 'delete table inet brand_license\n' or '')..rules
        local ok,result=pcall(function()
            util.write(dir..'/rules.nft',batch)
            local path=util.quote(dir..'/rules.nft')
            return util.exec(nft..' -c -f '..path..' >/dev/null 2>&1') and util.exec(nft..' -f '..path..' >/dev/null 2>&1')
        end)
        util.cleanup(dir,{'rules.nft'})
        if ok and result then cached_rules=rules end
        return ok and result or false
    end
    function backend.running(name)
        assert(permitted[name],'unknown_brand_service')
        local value=util.capture('/bin/ubus -t 1 call service list '..util.quote(json.stringify({name=name}))..' 2>/dev/null',65536)
        local object=value and json.parse(value)
        local instances=object and object[name] and object[name].instances
        if type(instances)~='table' then return false end
        local count=0
        for _,instance in pairs(instances) do
            count=count+1;if instance.running~=true then return false end
        end
        return count>0
    end
    function backend.start(name) return util.exec(script(name)..' start >/dev/null 2>&1') end
    function backend.stop(name)
        if not backend.running(name) then return true end
        return util.exec(script(name)..' stop >/dev/null 2>&1')
    end
    function backend.current_license() return require('brand_router.license').status(context) end
    return backend
end
return M
