-- Optional, owner-triggered binary installation. No enrollment, daemon or route changes.
local util=require 'brand_router.util'
local fs=require 'nixio.fs'
local json=require 'luci.jsonc'
local M={BASE='https://pkgs.tailscale.com/stable/',MAX_DOWNLOAD=100663296}
local function check(ok,code) assert(ok,code) end
function M.root(c) return c.tailscale_root or '/etc/brand-router/tailscale-tool' end
local function read(root,name) return json.parse(util.read(root..'/'..name..'.json',16384) or '') end
local function save(root,name,value) util.atomic(root..'/'..name..'.json',json.stringify(value)) end
local function version(v) return type(v)=='string' and #v<=24 and v:match('^%d+%.%d+%.%d+$') and tonumber(v:match('^%d+%.(%d+)'))%2==0 end
function M.release(value)
    check(type(value)=='table' and version(value.TarballsVersion) and type(value.Tarballs)=='table','tailscale_metadata_invalid')
    local name='tailscale_'..value.TarballsVersion..'_amd64.tgz'
    check(value.Tarballs.amd64==name,'tailscale_metadata_invalid')
    return {version=value.TarballsVersion,filename=name}
end
local function current(c)
    local root=M.root(c);local value=read(root,'current')
    if not value then return nil end
    check(version(value.version) and type(value.generation)=='string' and #value.generation==32 and value.generation:match('^[a-f0-9]+$'),'tailscale_state_invalid')
    local dir=root..'/'..value.generation
    for _,name in ipairs({'tailscale','tailscaled'}) do local s=fs.lstat(dir..'/'..name);check(s and s.type=='reg' and s.size>0,'tailscale_state_invalid') end
    return value
end
M.current=current
function M.inspect(c,now)
    now=now or os.time();local root=M.root(c);local job=read(root,'job')
    if job and job.busy and (job.boot~=util.read('/proc/sys/kernel/random/boot_id',128) or now-(job.started_at or 0)>600) then
        job.busy=false;job.phase='interrupted';job.error='tailscale_interrupted'
    end
    local installed=current(c)
    local external=not installed and util.exec('command -v tailscale >/dev/null 2>&1') or false
    return {installed=installed~=nil,version=installed and installed.version,installed_bytes=installed and installed.installed_bytes,
        download_bytes=installed and installed.download_bytes,job=job,external_install=external,
        can_install=not c.allow_lab_http and not installed and not external and not (job and job.busy) and not fs.lstat(root..'/install-lock'),
        state=installed and 'installed_unbound' or external and 'external_install' or 'not_installed',
        preview=c.allow_lab_http==true,remote_available=false,source='Tailscale 官方稳定版'}
end
function M.request(c,input,now,launch)
    check(not c.allow_lab_http,'preview_only');check(input.action=='install' and input.confirm==true,'tailscale_confirmation_required')
    local root=M.root(c);util.private_dir(root,c.private_uid)
    return util.with_lock(root..'/request-lock',function()
        local state=M.inspect(c,now);check(not state.installed,'tailscale_already_installed');check(not state.external_install,'tailscale_external_install')
        check(not (state.job and state.job.busy) and not fs.lstat(root..'/install-lock'),'tailscale_busy')
        local job={id=util.random_hex(16),phase='queued',busy=true,started_at=now,boot=util.read('/proc/sys/kernel/random/boot_id',128)}
        save(root,'job',job)
        if not launch(job.id) then job.busy=false;job.phase='failed';job.error='tailscale_launch_failed';save(root,'job',job);error('tailscale_launch_failed') end
        return {accepted=true,job_id=job.id}
    end)
end
function M.run(c,id,backend)
    local root=M.root(c);local job=read(root,'job')
    if not job or job.id~=id or job.phase~='queued' or not job.busy then return false end
    return util.with_lock(root..'/install-lock',function()
        local function phase(name,release)
            job.phase=name;if release then job.version=release.version end;save(root,'job',job)
        end
        local ok,reason=pcall(function()
            check(not current(c),'tailscale_already_installed');backend.preflight();phase('checking')
            local release=M.release(backend.metadata());phase('downloading',release)
            local installed=backend.install(release,phase,id)
            check(installed.version==release.version and installed.generation==id,'tailscale_install_failed')
            save(root,'current',installed);job.phase='completed'
        end)
        if not ok then
            local code=tostring(reason):match('([a-z_]+)$');local allowed={tailscale_download_failed=true,tailscale_metadata_invalid=true,tailscale_hash_mismatch=true,tailscale_archive_invalid=true,tailscale_space_required=true,tailscale_unsupported_system=true,tailscale_external_install=true,tailscale_already_installed=true,tailscale_install_failed=true}
            job.phase='failed';job.error=allowed[code] and code or 'tailscale_install_failed'
        end
        if backend.cleanup then pcall(backend.cleanup,id,not ok) end
        job.busy=false;job.finished_at=os.time();save(root,'job',job);return ok
    end)
end
return M
