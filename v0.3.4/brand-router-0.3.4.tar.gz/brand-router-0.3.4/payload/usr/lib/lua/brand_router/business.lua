-- Bounded, device-local configuration. Saving never starts a proxy or changes routing.
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local util=require 'brand_router.util'
local share_link=require 'brand_router.share_link'
local modes=require 'brand_router.modes'
local M={}
local MAX_BYTES=524288
local MAX_STORE_BYTES=MAX_BYTES*2+128
local secrets={password=true,uuid=true,obfs_password=true}
local fields={id=true,name=true,protocol=true,server=true,port=true,transport=true,security=true,
    username=true,password=true,uuid=true,method=true,sni=true,public_key=true,short_id=true,
    fingerprint=true,flow=true,path=true,host=true,service_name=true,obfs_password=true,
    congestion=true,alpn=true,note=true,mode=true,authority=true,spider_x=true,vmess_cipher=true,udp_relay_mode=true}
local catalog={
    {id='vless',label='VLESS',transports={'tcp','ws','grpc','httpupgrade','xhttp'},security={'none','tls','reality'}},
    {id='vmess',label='VMess',transports={'tcp','ws','grpc','httpupgrade'},security={'none','tls'}},
    {id='trojan',label='Trojan',transports={'tcp','ws','grpc'},security={'tls'}},
    {id='shadowsocks',label='Shadowsocks',transports={'tcp'},security={'none'}},
    {id='socks5',label='SOCKS5',transports={'tcp'},security={'none'}},
    {id='http',label='HTTP CONNECT',transports={'tcp'},security={'none','tls'}},
    {id='hysteria2',label='Hysteria2',transports={'quic'},security={'tls'}},
    {id='tuic',label='TUIC',transports={'quic'},security={'tls'}}
}
local protocols={};for _,v in ipairs(catalog) do protocols[v.id]=v end
local function fail(code) error({code=code},0) end
local function check(ok,code) if not ok then fail(code) end end
local function oneof(value,values) for _,v in ipairs(values) do if value==v then return true end end return false end
local function integer(v,low,high) return type(v)=='number' and v==math.floor(v) and v>=low and v<=high end
local function text(v,max,required)
    return type(v)=='string' and #v<=max and (not required or #v>0) and not v:find('[%z\1-\31\127]')
end
local function identifier(v) return type(v)=='string' and #v==32 and not v:find('[^a-f0-9]') end
local function host(v)
    if not text(v,253,true) or v:find('[^A-Za-z0-9.:%-]') then return false end
    if v:find(':',1,true) then
        if v:find('[^a-fA-F0-9:]') or v:find(':::') then return false end
        local _,compressed=v:gsub('::','');if compressed>1 then return false end
        if (v:sub(1,1)==':' and v:sub(1,2)~='::') or (v:sub(-1)==':' and v:sub(-2)~='::') then return false end
        local groups=0;for part in v:gmatch('[^:]+') do if #part>4 then return false end;groups=groups+1 end
        return compressed==1 and groups<8 or compressed==0 and groups==8
    end
    if v:match('^[%d.]+$') then
        local n=0;for part in v:gmatch('[^.]+') do if #part>3 or tonumber(part)>255 then return false end;n=n+1 end
        return n==4 and v:match('^%d+%.%d+%.%d+%.%d+$')~=nil
    end
    if v:find('..',1,true) or v:sub(1,1)=='.' or v:sub(-1)=='.' then return false end
    for part in v:gmatch('[^.]+') do if #part>63 or part:sub(1,1)=='-' or part:sub(-1)=='-' then return false end end
    return true
end
local function uuid(v)
    return text(v,36,true) and #v==36 and v:match('^%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x$')
end
local function count(t) local n=0;for _ in pairs(t) do n=n+1 end;return n end
function M.mac(v)
    check(type(v)=='string','invalid_mac')
    v=v:lower():gsub('-',':')
    check(v:match('^%x%x:%x%x:%x%x:%x%x:%x%x:%x%x$') and v~='00:00:00:00:00:00' and
        tonumber(v:sub(1,2),16)%2==0,'invalid_mac')
    return v
end
local function node(input,old)
    check(type(input)=='table','invalid_node')
    for key in pairs(input) do check(fields[key],'unknown_node_field') end
    local n={}
    for key in pairs(fields) do
        if key~='port' then
            local value=input[key] or ''
            check(text(value,key=='note' and 240 or 1024,false),'invalid_node_field')
            if secrets[key] and value=='' and old and old.protocol==input.protocol then value=old[key] or '' end
            n[key]=value
        end
    end
    n.id=old and old.id or util.random_hex(16)
    check(text(n.name,80,true),'node_name_required')
    check(host(n.server),'invalid_server')
    check(integer(input.port,1,65535),'invalid_port');n.port=input.port
    local spec=protocols[n.protocol];check(spec,'unsupported_protocol')
    check(oneof(n.transport,spec.transports),'unsupported_transport')
    check(oneof(n.security,spec.security),'unsupported_security')
    if n.security=='reality' then
        check(oneof(n.transport,{'tcp','grpc','xhttp'}),'reality_transport_conflict')
        check(#n.public_key==43 and not n.public_key:find('[^A-Za-z0-9_-]'),'invalid_reality_key')
        check(#n.short_id<=16 and #n.short_id%2==0 and not n.short_id:find('[^a-fA-F0-9]'),'invalid_short_id')
    else n.public_key='';n.short_id='' end
    if n.security~='none' then check(n.sni=='' or host(n.sni),'invalid_sni') end
    if n.security=='reality' then check(n.sni~='','sni_required') end
    check(oneof(n.fingerprint,{'','chrome','firefox','safari','edge','randomized'}),'invalid_fingerprint')
    check(#n.alpn<=255 and not n.alpn:find('[^A-Za-z0-9._/,%-%+]') and not n.alpn:find(',,',1,true) and
        n.alpn:sub(1,1)~=',' and n.alpn:sub(-1)~=',','invalid_alpn')
    if n.protocol=='vless' or n.protocol=='vmess' or n.protocol=='tuic' then check(uuid(n.uuid),'invalid_uuid') else n.uuid='' end
    if n.protocol=='shadowsocks' then
        check(oneof(n.method,{'aes-128-gcm','aes-256-gcm','chacha20-ietf-poly1305'}),'unsupported_cipher')
    else n.method='' end
    if n.protocol=='vmess' then
        if n.vmess_cipher=='' then n.vmess_cipher='auto' end
        check(oneof(n.vmess_cipher,{'auto','aes-128-gcm','chacha20-poly1305','none','zero'}),'unsupported_cipher')
    else n.vmess_cipher='' end
    if oneof(n.protocol,{'trojan','shadowsocks','hysteria2','tuic'}) then check(n.password~='','password_required') end
    if n.protocol=='socks5' or n.protocol=='http' then
        if n.username=='' and (input.password or '')=='' then n.password='' end
        check((n.username=='')==(n.password==''),'authentication_pair_required')
    else n.username='' end
    if n.protocol=='vless' or n.protocol=='vmess' then n.password='' end
    if n.flow~='' then
        check(n.protocol=='vless' and n.transport=='tcp' and n.security~='none' and
            oneof(n.flow,{'xtls-rprx-vision','xtls-rprx-vision-udp443'}),'flow_transport_conflict')
    end
    if oneof(n.transport,{'ws','httpupgrade','xhttp'}) then
        check(text(n.path,256,true) and n.path:sub(1,1)=='/' and not n.path:find('%s'),'invalid_transport_path')
        check(n.host=='' or host(n.host),'invalid_transport_host')
    else n.path='';n.host='' end
    if n.transport=='grpc' then
        check(text(n.service_name,128,true) and not n.service_name:find('[^A-Za-z0-9_./-]'),'invalid_service_name')
    else n.service_name='' end
    check(n.mode=='' or (n.transport=='grpc' and oneof(n.mode,{'gun','multi','guna'})) or
        (n.transport=='xhttp' and oneof(n.mode,{'auto','packet-up','stream-up','stream-one'})),'invalid_transport_mode')
    check(n.authority=='' or (n.transport=='grpc' and host(n.authority)),'invalid_transport_host')
    check(n.spider_x=='' or (n.security=='reality' and text(n.spider_x,256,false) and n.spider_x:sub(1,1)=='/'),'invalid_transport_path')
    if n.protocol~='hysteria2' then n.obfs_password='' end
    if n.protocol=='tuic' then
        check(oneof(n.congestion,{'cubic','bbr','new_reno'}),'invalid_congestion')
        if n.udp_relay_mode=='' then n.udp_relay_mode='native' end
        check(oneof(n.udp_relay_mode,{'native','quic'}),'invalid_udp_relay_mode')
    else n.congestion='';n.udp_relay_mode='' end
    return n
end
local function location(context)
    local dir=context.business_dir or context.state_dir
    util.private_dir(dir,context.private_uid)
    return dir..'/business.json',dir
end
local function validate(doc)
    check(type(doc)=='table' and (doc.schema==1 or doc.schema==3 or doc.schema==4) and integer(doc.revision,0,9007199254740000) and
        type(doc.nodes)=='table' and type(doc.bindings)=='table','config_corrupt')
    check(#json.stringify(doc)<=MAX_BYTES,'config_capacity')
    check(count(doc.nodes)<=256 and count(doc.bindings)<=1024,'config_capacity')
    local groups=doc.groups or {};check(type(groups)=='table' and count(groups)<=64,'config_capacity')
    local names={}
    for id,g in pairs(groups) do
        check(identifier(id) and type(g)=='table' and g.id==id and text(g.name,80,true) and not names[g.name],'config_corrupt')
        names[g.name]=true
    end
    local seen={}
    for id,n in pairs(doc.nodes) do
        check(identifier(id) and type(n)=='table' and n.id==id,'config_corrupt')
        node(n,n)
    end
    for id,b in pairs(doc.bindings) do
        check(identifier(id) and type(b)=='table' and b.id==id and text(b.name,80,true) and
            text(b.note,240,false) and doc.nodes[b.node_id],'config_corrupt')
        local group=b.group_id or '';check(group=='' or groups[group],'group_not_found')
        check(b.position==nil or integer(b.position,1,1024),'config_corrupt')
        if b.mac~='' or doc.schema==1 then
            local mac=M.mac(b.mac);check(not seen[mac],'duplicate_mac');seen[mac]=true
        end
    end
    check(doc.schema==4 or doc.mode_plans==nil,'config_corrupt')
    modes.validate_all(doc.mode_plans or {},doc.nodes)
    return doc
end
local function read(path,uid)
    local stat=fs.lstat(path)
    if not stat then return {schema=1,revision=0,nodes={},bindings={}} end
    check(stat.type=='reg' and stat.uid==(uid or require('nixio').getuid()) and stat.modedec==600,'config_file_not_private')
    local raw=util.read(path,MAX_STORE_BYTES);local doc=raw and json.parse(raw)
    check(type(doc)=='table','config_corrupt')
    if doc.schema==2 then
        local current,previous=validate(doc.current),validate(doc.previous)
        check(previous.revision==current.revision-1,'config_corrupt')
        return current,previous
    end
    -- Read legacy single-document stores without changing them. A successful
    -- mutation migrates both logical versions into one atomic commit record.
    return validate(doc)
end
local function view(doc)
    local nodes,bindings,groups={},{},{}
    for _,n in pairs(doc.nodes) do
        local copy={};for k,v in pairs(n) do if not secrets[k] then copy[k]=v end end
        copy.credentials={};for k in pairs(secrets) do copy.credentials[k]=n[k]~='' end
        nodes[#nodes+1]=copy
    end
    for _,b in pairs(doc.bindings) do bindings[#bindings+1]=b end
    table.sort(nodes,function(a,b) return a.name==b.name and a.id<b.id or a.name<b.name end)
    table.sort(bindings,function(a,b) return (a.position or 0)==(b.position or 0) and a.id<b.id or (a.position or 0)<(b.position or 0) end)
    for _,g in pairs(doc.groups or {}) do groups[#groups+1]=g end
    table.sort(groups,function(a,b) return a.name<b.name end)
    local summaries={};for _,mode in ipairs({'fixed','rotation','dynamic'}) do summaries[mode]=modes.summary(mode,(doc.mode_plans or {})[mode]) end
    return {revision=doc.revision,nodes=nodes,bindings=bindings,groups=groups,catalog=catalog,mode_plans=doc.mode_plans or {},modes=summaries,
        runtime={applied=false,state='not_connected',message='配置可保存；代理运行与网络下发尚未接通。'},
        limits={nodes=256,bindings=1024,groups=64,batch=200},updated_at=doc.updated_at}
end
function M.get(context)
    local path=location(context);return view(read(path,context.private_uid))
end
-- Internal only: execution adapters need validated secrets; never return this through the portal.
function M.load(context)
    local path=location(context);return read(path,context.private_uid)
end
local function array(value,max)
    check(type(value)=='table' and #value>0 and #value<=max and count(value)==#value,'invalid_rows')
    for k in pairs(value) do check(integer(k,1,#value),'invalid_rows') end
    return value
end
local function parsed(raw) return node(share_link.parse(raw)) end
function M.preview(input)
    local result={}
    for i,raw in ipairs(array(input.links,200)) do
        local ok,n=pcall(parsed,raw)
        if ok then result[i]={name=n.name,server=n.server,port=n.port,protocol=n.protocol,transport=n.transport,security=n.security}
        else result[i]={error=type(n)=='table' and n.code or 'invalid_share_link'} end
    end
    return {results=result}
end
local function ordered(doc)
    local result={};for _,b in pairs(doc.bindings) do result[#result+1]=b end
    table.sort(result,function(a,b) return (a.position or 0)==(b.position or 0) and a.id<b.id or (a.position or 0)<(b.position or 0) end)
    return result
end
local function group(doc,id) check(type(id)=='string' and (id=='' or doc.groups[id]),'group_not_found');return id end
local function same_node(a,b)
    local function value(n,key)
        local v=n[key] or ''
        if v=='' and key=='vmess_cipher' and n.protocol=='vmess' then return 'auto' end
        if v=='' and key=='udp_relay_mode' and n.protocol=='tuic' then return 'native' end
        return v
    end
    for key in pairs(fields) do
        if key~='id' and key~='name' and key~='note' and value(a,key)~=value(b,key) then return false end
    end
    return true
end
local function prune(doc,candidates)
    for id in pairs(candidates) do
        local used=modes.references(doc.mode_plans,id);for _,b in pairs(doc.bindings) do if b.node_id==id then used=true end end
        if not used then doc.nodes[id]=nil end
    end
end
local function save_rows(doc,input)
    local touched,seen,inserted={},{},{}
    for index,r in ipairs(array(input.rows,200)) do
        local ok,err=pcall(function()
            check(type(r)=='table','invalid_rows')
            for k in pairs(r) do check(oneof(k,{'id','mac','link','node_id','note','group_id','after_id'}),'invalid_rows') end
            local old
            if r.id and r.id~='' then check(identifier(r.id) and doc.bindings[r.id],'binding_not_found');old=doc.bindings[r.id] end
            check(not old or not seen[r.id],'invalid_rows');if old then seen[r.id]=true end
            local n
            if r.link and r.link~='' then
                n=parsed(r.link)
                for _,existing in pairs(doc.nodes) do if same_node(n,existing) then n=existing;break end end
                doc.nodes[n.id]=n
            else n=doc.nodes[r.node_id or (old and old.node_id) or ''];check(n,'node_not_found') end
            local mac=r.mac or '';if mac~='' then mac=M.mac(mac) end
            local note=r.note or '';check(text(note,240,false),'invalid_note')
            local position=old and old.position or #ordered(doc)+1
            if r.after_id and r.after_id~='' then
                local after=doc.bindings[inserted[r.after_id] or r.after_id];check(after,'binding_not_found');position=(after.position or 0)+0.5
            end
            if old then touched[old.node_id]=true end
            local id=old and old.id or util.random_hex(16)
            doc.bindings[id]={id=id,name=old and old.name or n.name,mac=mac,node_id=n.id,note=note,
                group_id=group(doc,r.group_id or ''),position=position}
            if r.after_id and r.after_id~='' then inserted[r.after_id]=id end
            for i,b in ipairs(ordered(doc)) do b.position=i end
        end)
        if not ok then error({code=type(err)=='table' and err.code or 'invalid_rows',row=index},0) end
    end
    prune(doc,touched)
end
function M.change(context,input,now)
    local path,dir=location(context)
    return util.with_lock(dir..'/business-lock',function()
        local doc,previous=read(path,context.private_uid)
        check(type(input)=='table' and input.revision==doc.revision,'revision_conflict')
        local before=json.stringify(doc)
        local action=input.action
        doc.schema=doc.mode_plans and 4 or 3;doc.groups=doc.groups or {}
        for i,b in ipairs(ordered(doc)) do b.position=i end
        if action=='save_mode' then
            check(type(input.plan)=='table','invalid_mode_plan')
            local supplied=input.plan.node_ids or {}
            check(type(supplied)=='table' and #supplied<=256 and count(supplied)==#supplied,'invalid_mode_plan')
            for k in pairs(supplied) do check(integer(k,1,#supplied),'invalid_mode_plan') end
            local ids={};for _,id in ipairs(supplied) do ids[#ids+1]=id end
            if input.links~=nil then
                for index,link in ipairs(array(input.links,200)) do
                    local ok,n=pcall(parsed,link)
                    if not ok then error({code=type(n)=='table' and n.code or 'invalid_share_link',row=index},0) end
                    for _,existing in pairs(doc.nodes) do if same_node(n,existing) then n=existing;break end end
                    doc.nodes[n.id]=n;ids[#ids+1]=n.id
                end
            end
            local plan={};for k,v in pairs(input.plan) do plan[k]=v end
            plan.node_ids=ids
            local normalized=modes.validate(input.mode,plan,doc.nodes)
            doc.mode_plans=doc.mode_plans or {};doc.mode_plans[input.mode]=normalized;doc.schema=4
        elseif action=='delete_mode' then
            check(doc.mode_plans and doc.mode_plans[input.mode],'mode_plan_not_found');doc.mode_plans[input.mode]=nil
        elseif action=='save_rows' then save_rows(doc,input)
        elseif action=='save_group' then
            check(text(input.name,80,true),'invalid_group_name')
            local id=input.id
            if id and id~='' then check(doc.groups[id],'group_not_found') else check(count(doc.groups)<64,'config_capacity');id=util.random_hex(16) end
            for other,g in pairs(doc.groups) do check(other==id or g.name~=input.name,'duplicate_group') end
            doc.groups[id]={id=id,name=input.name}
        elseif action=='delete_group' then
            check(doc.groups[input.id],'group_not_found')
            for _,b in pairs(doc.bindings) do check(b.group_id~=input.id,'group_not_empty') end
            doc.groups[input.id]=nil
        elseif action=='move_rows' or action=='delete_rows' then
            local ids=array(input.ids,200);local touched={}
            if action=='move_rows' then group(doc,input.group_id) end
            for _,id in ipairs(ids) do
                check(doc.bindings[id],'binding_not_found')
                if action=='move_rows' then doc.bindings[id].group_id=input.group_id
                else touched[doc.bindings[id].node_id]=true;doc.bindings[id]=nil end
            end
            prune(doc,touched)
        elseif action=='save_node' then
            check(type(input.node)=='table','invalid_node')
            local id=input.node.id
            local old
            if id and id~='' then check(identifier(id) and doc.nodes[id],'node_not_found');old=doc.nodes[id] end
            check(old or count(doc.nodes)<256,'config_capacity')
            local n=node(input.node,old);doc.nodes[n.id]=n
        elseif action=='delete_node' then
            check(identifier(input.id) and doc.nodes[input.id],'node_not_found')
            check(not modes.references(doc.mode_plans,input.id),'node_in_use')
            for _,b in pairs(doc.bindings) do check(b.node_id~=input.id,'node_in_use') end
            doc.nodes[input.id]=nil
        elseif action=='save_binding' then
            local b=input.binding;check(type(b)=='table','invalid_binding')
            for key in pairs(b) do check(oneof(key,{'id','mac','name','note','node_id'}),'invalid_binding') end
            local old
            if b.id and b.id~='' then check(identifier(b.id) and doc.bindings[b.id],'binding_not_found');old=doc.bindings[b.id] end
            check(old or count(doc.bindings)<1024,'config_capacity')
            local mac=M.mac(b.mac)
            for id,other in pairs(doc.bindings) do check(id==b.id or other.mac~=mac,'duplicate_mac') end
            check(text(b.name,80,true),'device_name_required')
            check(text(b.note or '',240,false),'invalid_note')
            check(identifier(b.node_id) and doc.nodes[b.node_id],'node_not_found')
            local id=old and old.id or util.random_hex(16)
            doc.bindings[id]={id=id,mac=mac,name=b.name,note=b.note or '',node_id=b.node_id}
        elseif action=='delete_binding' then
            check(identifier(input.id) and doc.bindings[input.id],'binding_not_found');doc.bindings[input.id]=nil
        elseif action=='restore_previous' then
            if not previous then
                check(fs.lstat(dir..'/business.previous.json'),'no_previous_config')
                previous=read(dir..'/business.previous.json',context.private_uid)
            end
            doc.nodes,doc.bindings,doc.groups=previous.nodes,previous.bindings,previous.groups or {}
            doc.mode_plans=previous.mode_plans;doc.schema=doc.mode_plans and 4 or 3
        else fail('unknown_config_action') end
        for i,b in ipairs(ordered(doc)) do b.position=i end
        validate(doc)
        doc.revision=doc.revision+1;doc.updated_at=now or os.time()
        local encoded=json.stringify(doc)
        check(#encoded<=MAX_BYTES,'config_capacity')
        -- Publish current + previous in one rename. Two independent renames
        -- cannot preserve both versions when the second operation fails.
        -- Legacy business.previous.json remains untouched for recovery; new
        -- stores do not create it. No rollback I/O is needed after a failure.
        local store=json.stringify({schema=2,current=doc,previous=json.parse(before)})
        check(#store<=MAX_STORE_BYTES,'config_capacity')
        util.atomic(path,store)
        return view(doc)
    end)
end
return M
