-- Panel credentials only. Never changes Unix root, rpcd credentials, license or business files.
local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local M={}
local function fail(code) error({code=code},0) end
local function root(c) return c.state_dir or '/etc/brand-router/state' end
local function path(c) return root(c)..'/panel-account.json' end
local function equal(a,b)
    if type(a)~='string' or type(b)~='string' or #a~=#b then return false end
    local same=true;for i=1,#a do if a:byte(i)~=b:byte(i) then same=false end end;return same
end
function M.read(c)
    local st=fs.lstat(path(c));if not st then return nil end
    if st.type~='reg' or st.uid~=(c.private_uid or 0) or st.modedec~=600 then fail('account_unavailable') end
    local a=json.parse(util.read(path(c),8192) or '')
    if type(a)~='table' or a.schema~=1 or a.username~='root' or not ({password=true,none=true,unconfigured=true})[a.mode]
      or type(a.generation)~='string' or #a.generation~=32 or not a.generation:match('^[0-9a-f]+$')
      or type(a.recovery_hash)~='string' or #a.recovery_hash~=64 or not a.recovery_hash:match('^[0-9a-f]+$')
      or (a.mode=='password' and (type(a.password_hash)~='string' or not a.password_hash:match('^%$6%$[A-Za-z0-9./]+%$[A-Za-z0-9./]+$'))) then fail('account_unavailable') end
    return a
end
local function secret_hash(c,value,salt)
    local dir=util.tempdir(c.temp_parent or '/tmp')
    local ok,result=pcall(function()
        util.write(dir..'/secret',value..(salt and '\n' or ''))
        local command=util.quote(c.openssl or '/usr/bin/openssl')..(salt and (' passwd -6 -salt '..util.quote(salt)..' -stdin') or ' dgst -sha256')
        local raw=util.capture(command..' < '..util.quote(dir..'/secret')..' 2>/dev/null',2048) or ''
        return salt and raw:match('(%$6%$[^%s]+)') or raw:match('([0-9a-f]+)%s*$')
    end)
    util.cleanup(dir,{'secret'});if not ok or not result then fail('account_unavailable') end;return result
end
local function password(c,value)
    if type(value)~='string' or #value<8 or #value>128 or value:find('[%z\r\n]') then fail('invalid_panel_password') end
    return secret_hash(c,value,util.random_hex(8))
end
function M.verify(c,a,value)
    if not a or type(value)~='string' or #value>128 or value:find('[%z\r\n]') then return false end
    if a.mode~='password' then return value=='' end
    if #value<8 then return false end
    local salt=a.password_hash:match('^%$6%$([^$]+)%$')
    return salt and equal(secret_hash(c,value,salt),a.password_hash) or false
end
function M.public(c,config)
    local a=M.read(c)
    return {username=a and a.username or config.customer_username,mode=a and a.mode or 'legacy',
      password_required=not a or a.mode=='password',recovery_available=a~=nil,first_setup=a and a.mode=='unconfigured' or false}
end
local function commit(c,mode,hash)
    local code='BRR1.'..util.random_hex(32)
    local a={schema=1,username='root',mode=mode,password_hash=hash,generation=util.random_hex(16),recovery_hash=secret_hash(c,code)}
    util.atomic(path(c),json.stringify(a))
    return {username='root',mode=mode,recovery_code=code,relogin_required=true}
end
function M.initialize(c)
    util.private_dir(root(c),c.private_uid)
    return util.with_lock(root(c)..'/panel-account-lock',function()
        if fs.lstat(path(c)) then fail('account_already_initialized') end
        return commit(c,'unconfigured')
    end)
end
function M.change(c,input,verify_legacy,expected_generation)
    util.private_dir(root(c),c.private_uid)
    return util.with_lock(root(c)..'/panel-account-lock',function()
        local a=M.read(c)
        if (a and a.generation or 'legacy')~=expected_generation then fail('account_changed') end
        if not (a and M.verify(c,a,input.current_password or '') or not a and verify_legacy(input.current_password)) then fail('current_password_incorrect') end
        if input.mode~='password' and input.mode~='none' then fail('invalid_account_mode') end
        if input.mode=='none' and input.confirm_no_password~=true then fail('passwordless_confirmation_required') end
        return commit(c,input.mode,input.mode=='password' and password(c,input.new_password) or nil)
    end)
end
function M.recover(c,input)
    util.private_dir(root(c),c.private_uid)
    return util.with_lock(root(c)..'/panel-account-lock',function()
        local a=M.read(c)
        if not a or type(input.recovery_code)~='string' or not input.recovery_code:match('^BRR1%.[0-9a-f]+$') or #input.recovery_code~=69
          or not equal(secret_hash(c,input.recovery_code),a.recovery_hash) then fail('invalid_recovery_code') end
        return commit(c,'password',password(c,input.new_password))
    end)
end
function M.owner_reset(c,new_password)
    util.private_dir(root(c),c.private_uid)
    return util.with_lock(root(c)..'/panel-account-lock',function() return commit(c,'password',password(c,new_password)) end)
end
return M
