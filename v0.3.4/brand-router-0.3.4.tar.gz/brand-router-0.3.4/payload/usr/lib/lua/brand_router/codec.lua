local M = {}
local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
function M.encode(s)
    local out, acc, bits = {}, 0, 0
    for i = 1, #s do
        acc, bits = acc * 256 + s:byte(i), bits + 8
        while bits >= 6 do
            bits = bits - 6
            local n = math.floor(acc / 2^bits)
            out[#out+1] = chars:sub(n+1, n+1)
            acc = acc % 2^bits
        end
    end
    if bits > 0 then local n = acc * 2^(6-bits); out[#out+1] = chars:sub(n+1,n+1) end
    return table.concat(out)
end
function M.decode(s, maximum)
    maximum = maximum or 16384
    if type(s) ~= 'string' or #s == 0 or #s > maximum * 2 or #s % 4 == 1 or s:find('[^A-Za-z0-9_-]') then return nil end
    local out, acc, bits = {}, 0, 0
    for i = 1, #s do
        local n = chars:find(s:sub(i,i), 1, true)
        if not n then return nil end
        acc, bits = acc * 64 + n - 1, bits + 6
        if bits >= 8 then
            bits = bits - 8
            local byte = math.floor(acc / 2^bits)
            out[#out+1] = string.char(byte)
            acc = acc % 2^bits
        end
    end
    local result = table.concat(out)
    if #result > maximum or M.encode(result) ~= s then return nil end
    return result
end
return M
