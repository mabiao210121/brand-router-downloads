-- Read a bounded tar file in chunks. Only the two official binaries are written.
local fs=require 'nixio.fs'
local M={MAX=268435456}
local function check(ok) assert(ok,'tailscale_archive_invalid') end
local function text(s) return s:match('^[^%z]*') end
local function oct(s) local n=s:gsub('%z',''):match('^%s*([0-7]+)%s*$');return n and tonumber(n,8) end
function M.extract(path,version,destination)
    local st=fs.lstat(path);check(st and st.type=='reg' and st.size<=M.MAX and st.size%512==0)
    local file=assert(io.open(path,'rb'));local output
    local ok,result=pcall(function()
        local prefix='tailscale_'..version..'_amd64/';local seen={};local total,count=0,0
        while true do
            local h=file:read(512);check(h and #h==512)
            if h==string.rep('\0',512) then
                check(file:read(512)==string.rep('\0',512))
                while true do local rest=file:read(65536);if not rest then break end;check(not rest:find('[^%z]')) end
                check(seen.tailscale and seen.tailscaled);return total
            end
            count=count+1;check(count<=10)
            local name=text(h:sub(1,100));local pre=text(h:sub(346,500));if pre~='' then name=pre..'/'..name end
            check(h:sub(258,262)=='ustar' and name:sub(1,#prefix)==prefix)
            local short=name:sub(#prefix+1);check(not seen[short]);seen[short]=true
            local kind=h:sub(157,157);local size,checksum=oct(h:sub(125,136)),oct(h:sub(149,156))
            local sum=0;for i=1,512 do sum=sum+((i>=149 and i<=156) and 32 or h:byte(i)) end
            check(checksum==sum and size and size<=134217728)
            local binary=short=='tailscale' or short=='tailscaled'
            local directory=short=='' or short=='systemd/'
            check((directory and kind=='5' and size==0) or ((binary or short=='systemd/tailscaled.service' or short=='systemd/tailscaled.defaults' or short=='systemd/tailscale-online.target' or short=='systemd/tailscale-wait-online.service') and (kind=='0' or kind=='\0')))
            if not binary then check(size<=65536) end
            if binary then output=assert(io.open(destination..'/'..short,'wb')) end
            local remaining=size;local first=true
            while remaining>0 do
                local chunk=file:read(math.min(65536,remaining));check(chunk and #chunk==math.min(65536,remaining))
                if binary and first then check(chunk:sub(1,6)=='\127ELF\2\1' and chunk:byte(19)==62 and chunk:byte(20)==0);first=false end
                if output then assert(output:write(chunk)) end;remaining=remaining-#chunk
            end
            if binary then check(size>=64);output:close();output=nil;check(fs.chmod(destination..'/'..short,'755'));total=total+size end
            local pad=(512-size%512)%512;if pad>0 then check(#(file:read(pad) or '')==pad) end
        end
    end)
    if output then output:close() end;file:close();if not ok then error(result,0) end;return result
end
return M
