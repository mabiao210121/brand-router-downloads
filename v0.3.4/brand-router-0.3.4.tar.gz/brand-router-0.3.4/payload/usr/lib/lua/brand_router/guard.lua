-- Owns only the brand business zone. A separate owner interface is required.
local M={}
local function interface(name)
    assert(type(name)=='string' and #name>=1 and #name<=15 and not name:find('[^A-Za-z0-9_.-]'),'invalid_business_interface')
    return '"'..name..'"'
end
local function ports(list,reserved)
    local out,seen={},{}
    for _,n in ipairs(list or {}) do
        assert(type(n)=='number' and n%1==0 and n>=1 and n<=65535 and not seen[n],'invalid_business_port')
        assert(not reserved[n],'native_admin_port_reserved')
        seen[n]=true;out[#out+1]=tostring(n)
    end
    return #out>0 and '{ '..table.concat(out,', ')..' }' or nil
end
function M.plan(status, site)
    assert(type(site)=='table' and type(site.business_interfaces)=='table' and #site.business_interfaces>0,'business_interfaces_required')
    interface(site.management_interface)
    local names,seen={},{}
    for _,v in ipairs(site.business_interfaces) do
        assert(v~=site.management_interface and not seen[v],'management_interface_must_be_separate')
        seen[v]=true;names[#names+1]=interface(v)
    end
    assert(type(site.brand_port)=='number' and site.brand_port%1==0 and site.brand_port>=1024 and site.brand_port<=65535,'invalid_brand_port')
    local elements=table.concat(names,', ')
    local reserved={[22]=true,[80]=true,[443]=true,[site.brand_port]=true}
    for _,n in ipairs(site.native_admin_tcp_ports or {}) do
        assert(type(n)=='number' and n%1==0 and n>=1 and n<=65535,'invalid_native_admin_port')
        reserved[n]=true
    end
    local tcp,udp=ports(site.business_tcp_ports,reserved),ports(site.business_udp_ports,{[site.brand_port]=true})
    local rules={ 'table inet brand_license {', ' set customer_ifaces { type ifname; elements = { '..elements..' } }',
        ' chain customer_input { type filter hook input priority -20; policy accept;',
        '  iifname @customer_ifaces tcp dport '..site.brand_port..' accept',
        '  iifname @customer_ifaces udp sport 68 udp dport 67 accept',
        '  iifname @customer_ifaces meta nfproto ipv6 udp sport 546 udp dport 547 accept',
        '  iifname @customer_ifaces meta l4proto ipv6-icmp icmpv6 type { nd-neighbor-solicit, nd-neighbor-advert, nd-router-solicit } accept'}
    if status.business_allowed then
        rules[#rules+1]='  iifname @customer_ifaces meta l4proto { tcp, udp } th dport 53 accept'
        if tcp then rules[#rules+1]='  iifname @customer_ifaces tcp dport '..tcp..' accept' end
        if udp then rules[#rules+1]='  iifname @customer_ifaces udp dport '..udp..' accept' end
    end
    rules[#rules+1]='  iifname @customer_ifaces drop'
    rules[#rules+1]=' }'
    if not status.business_allowed then
        rules[#rules+1]=' chain locked_prerouting { type filter hook prerouting priority -310; policy accept;'
        rules[#rules+1]='  iifname @customer_ifaces udp sport 68 udp dport 67 accept'
        rules[#rules+1]='  iifname @customer_ifaces meta nfproto ipv6 udp sport 546 udp dport 547 accept'
        rules[#rules+1]='  iifname @customer_ifaces meta l4proto ipv6-icmp icmpv6 type { nd-neighbor-solicit, nd-neighbor-advert, nd-router-solicit } accept'
        rules[#rules+1]='  iifname @customer_ifaces fib daddr type local tcp dport '..site.brand_port..' accept'
        rules[#rules+1]='  iifname @customer_ifaces drop'
        rules[#rules+1]=' }'
        rules[#rules+1]=' chain locked_forward { type filter hook forward priority -20; policy accept;'
        rules[#rules+1]='  iifname @customer_ifaces drop'
        rules[#rules+1]='  oifname @customer_ifaces drop'
        rules[#rules+1]=' }'
    end
    rules[#rules+1]='}'
    return {state=status.state,stop_business_services=not status.business_allowed,stop_business_logic=not status.business_allowed,
        customer_native_admin_allowed=false,customer_brand_login_allowed=status.customer_login_allowed,
        retain_owner_management=true,requires_flow_offload_disabled=true,
        nft=table.concat(rules,'\n')..'\n',applied=false}
end
return M
