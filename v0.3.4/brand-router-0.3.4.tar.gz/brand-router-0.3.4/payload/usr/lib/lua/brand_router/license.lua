local json = require 'luci.jsonc'
local fs = require 'nixio.fs'
local codec = require 'brand_router.codec'
local util = require 'brand_router.util'
local identity_module = require 'brand_router.identity'
local clock = require 'brand_router.clock'
local M = {}
local MIN_TIME = 1735689600
local allowed_features = {fixed=true, rotation=true, dynamic=true, manage=true}
local function integer(n, low, high) return type(n)=='number' and n==math.floor(n) and n>=low and n<=high end
local function hex(s, n) return type(s)=='string' and #s==n and not s:find('[^0-9a-f]') end
local function invalid(reason) return {state=reason,business_allowed=false,customer_login_allowed=false,recovery_allowed=true,features={}} end
function M.parse_code(code)
    if type(code)=='table' then return code end
    if type(code)~='string' or #code>16384 then return nil end
    code = code:match('^%s*(.-)%s*$')
    if code:sub(1,5)=='BRL1.' then code=codec.decode(code:sub(6)); if not code then return nil end end
    return json.parse(code)
end
function M.validate(c)
    if type(c)~='table' or c.schema~=1 or (c.state~='active' and c.state~='revoked') or not hex(c.license_id,32) or not hex(c.device_id,64) or not hex(c.hardware_hash,64) then return false end
    for _, n in ipairs({'issued_at','expires_at','stop_at','lease_until'}) do if not integer(c[n],MIN_TIME,4102444800) then return false end end
    if not integer(c.sequence,1,9007199254740991) or not integer(c.cutoff_seconds,0,3600) or c.stop_at~=c.expires_at-c.cutoff_seconds or c.lease_until>c.stop_at then return false end
    if type(c.features)~='table' then return false end
    local seen={}; for k,v in pairs(c.features) do
        if not integer(k,1,4) or not allowed_features[v] or seen[v] then return false end
        seen[v]=true
    end
    return true
end
function M.verify(envelope, context)
    if type(envelope)~='table' or envelope.format~='BRL1' then return nil,'invalid_license' end
    local kid=envelope.key_id
    if type(kid)~='string' or #kid<1 or #kid>48 or kid:find('[^A-Za-z0-9_-]') then return nil,'unknown_key' end
    local raw,sig=codec.decode(envelope.payload),codec.decode(envelope.signature,64)
    if not raw or not sig or #sig~=64 then return nil,'invalid_encoding' end
    local key=context.key_dir .. '/' .. kid .. '.pub'
    if not util.read(key,8192) then return nil,'unknown_key' end
    local dir=util.tempdir(context.temp_parent or '/tmp')
    local ok,valid=pcall(function()
        util.write(dir..'/message','BR-LICENSE/1\0'..kid..'\0'..raw)
        util.write(dir..'/signature',sig)
        return util.exec(util.quote(context.openssl or '/usr/bin/openssl')..' pkeyutl -verify -rawin -pubin -inkey '..util.quote(key)..' -in '..util.quote(dir..'/message')..' -sigfile '..util.quote(dir..'/signature')..' >/dev/null 2>&1')
    end)
    util.cleanup(dir,{'message','signature'})
    if not ok or not valid then return nil,'invalid_signature' end
    local claims=json.parse(raw)
    if not M.validate(claims) then return nil,'invalid_claims' end
    return claims
end
function M.evaluate(c, identity, now, watermark)
    if not M.validate(c) then return invalid('invalid_claims') end
    local state=watermark or {}; local reason='active'
    if c.device_id~=identity.device_id or c.hardware_hash~=identity.hardware_hash then reason='wrong_device'
    elseif now<MIN_TIME or now+300<c.issued_at then reason='clock_not_synchronized'
    elseif now+120<(state.last_time or 0) then reason='clock_rollback'
    elseif c.sequence<(state.sequence or 0) then reason='stale_lease'
    elseif c.state=='revoked' then reason='revoked'
    elseif now>=c.stop_at then reason='expired_cutoff'
    elseif now>=c.lease_until then reason='offline_limit' end
    return {state=reason,business_allowed=reason=='active',customer_login_allowed=reason=='active',recovery_allowed=true,
        expires_at=c.expires_at,stop_at=c.stop_at,lease_until=c.lease_until,license_id=c.license_id,sequence=c.sequence,
        features=reason=='active' and c.features or {}}
end
function M.status(context, now)
    local clock_reason
    if not now then now,clock_reason=clock.effective(context) end
    local identity,identity_error=identity_module.current(context)
    if not identity then return invalid(identity_error) end
    local activation=json.parse(util.read(context.state_dir..'/activation.json') or '') or {}
    local envelope=M.parse_code(activation.envelope)
    if not envelope then return invalid('not_activated') end
    local claims,reason=M.verify(envelope,context)
    if not claims then return invalid(reason) end
    local watermark=activation.watermark or {}
    local result=M.evaluate(claims,identity,now,watermark)
    if clock_reason then result.state=clock_reason;result.business_allowed=false;result.customer_login_allowed=false;result.features={} end
    return result,claims
end
function M.import(code, context, now)
    if not now then
        local reason;now,reason=clock.effective(context)
        if reason then return invalid(reason) end
    end
    local identity,identity_error=identity_module.current(context)
    if not identity then return invalid(identity_error) end
    local envelope=M.parse_code(code)
    local claims,reason=M.verify(envelope,context)
    if not claims then return invalid(reason) end
    local activation=json.parse(util.read(context.state_dir..'/activation.json') or '') or {}
    local watermark=activation.watermark or {}
    local result=M.evaluate(claims,identity,now,watermark)
    if result.state~='active' and result.state~='revoked' and result.state~='expired_cutoff' and result.state~='offline_limit' then return result end
    -- Do not overwrite a usable license with an invalid signature or another machine's token.
    -- One rename commits the token and anti-rollback watermark together. Caller holds the state lock.
    util.atomic(context.state_dir..'/activation.json',json.stringify({envelope=envelope,
        watermark={sequence=claims.sequence,last_time=math.max(now,watermark.last_time or 0)}}))
    return result
end
function M.observe(context, now)
    local clock_reason
    if not now then now,clock_reason=clock.record(context) end
    local result,claims=M.status(context,now)
    if clock_reason then result.state=clock_reason;result.business_allowed=false;result.customer_login_allowed=false;result.features={} end
    if not clock_reason and claims and result.state~='clock_rollback' and result.state~='clock_not_synchronized' and result.state~='wrong_device' then
        local activation=json.parse(util.read(context.state_dir..'/activation.json') or '') or {}
        local state=activation.watermark or {}
        -- Bound SSD writes. Reliable RTC/boot-time synchronization remains a firmware acceptance requirement.
        if now>=(state.last_time or 0)+600 then
            state.last_time=now;state.sequence=math.max(claims.sequence,state.sequence or 0)
            activation.watermark=state;util.atomic(context.state_dir..'/activation.json',json.stringify(activation))
        end
    end
    return result
end
return M
