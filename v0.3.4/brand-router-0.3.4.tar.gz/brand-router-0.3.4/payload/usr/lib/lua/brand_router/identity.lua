local fs=require 'nixio.fs'
local json=require 'luci.jsonc'
local util=require 'brand_router.util'
local codec=require 'brand_router.codec'
local M={}
local function hardware(context)
    local value=util.read(context.hardware_path or '/sys/class/dmi/id/product_uuid',256)
    value=value and value:lower():match('^%s*(.-)%s*$')
    if not value or #value~=36 or not value:match('^%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x$') then return nil end
    if value:gsub('-',''):match('^0+$') or value:gsub('-',''):match('^f+$') then return nil end
    return value
end
local function hardware_hash(value,context)
    local dir=util.tempdir(context.temp_parent or '/tmp')
    util.write(dir..'/hardware','brand-hardware/1\0'..value)
    local hw=(util.capture(util.quote(context.openssl or '/usr/bin/openssl')..' dgst -sha256 '..util.quote(dir..'/hardware')) or ''):match('([0-9a-f]+)%s*$')
    util.cleanup(dir,{'hardware'})
    return hw and #hw==64 and hw or nil
end
function M.current(context)
    local directory=fs.lstat(context.state_dir)
    if not directory then return nil,'not_initialized' end
    if directory.type~='dir' or directory.uid~=(context.private_uid or require('nixio').getuid()) then return nil,'invalid_state_directory' end
    local identity=json.parse(util.read(context.state_dir..'/identity.json') or '')
    if type(identity)~='table' then return nil,'not_initialized' end
    if not util.read(context.state_dir..'/device.key',8192) then return nil,'device_key_missing' end
    local value=hardware(context)
    if not value then return nil,'stable_hardware_identity_required' end
    if hardware_hash(value,context)~=identity.hardware_hash then return nil,'hardware_changed' end
    return identity
end
function M.enrollment(context)
    local root=context.state_dir; local openssl=context.openssl or '/usr/bin/openssl'
    local parent=assert(root:match('^(.*)/[^/]+$'),'invalid_state_directory')
    local uid=context.private_uid or require('nixio').getuid()
    local parent_stat=fs.lstat(parent)
    if not parent_stat then util.private_dir(parent,uid)
    else assert(parent_stat.type=='dir' and (parent_stat.uid==uid or parent_stat.uid==0),'private_state_parent_required') end
    util.private_dir(root,uid)
    local stable_hardware=assert(hardware(context),'stable_hardware_identity_required')
    local identity=json.parse(util.read(root..'/identity.json') or '')
    if not identity then
        local dir=util.tempdir(root)
        local ok,result=pcall(function()
            assert(util.exec(util.quote(openssl)..' genpkey -algorithm ED25519 -out '..util.quote(dir..'/device.key')..' >/dev/null 2>&1'),'device_key_failed')
            assert(util.exec(util.quote(openssl)..' pkey -in '..util.quote(dir..'/device.key')..' -pubout -outform DER -out '..util.quote(dir..'/device.der')..' >/dev/null 2>&1'),'device_public_key_failed')
            local der=assert(util.read(dir..'/device.der',64))
            local did=(util.capture(util.quote(openssl)..' dgst -sha256 '..util.quote(dir..'/device.der')) or ''):match('([0-9a-f]+)%s*$')
            assert(did and #did==64,'device_identity_failed')
            util.write(dir..'/hardware','brand-hardware/1\0'..stable_hardware)
            local hw=(util.capture(util.quote(openssl)..' dgst -sha256 '..util.quote(dir..'/hardware')) or ''):match('([0-9a-f]+)%s*$')
            assert(hw and #hw==64,'hardware_identity_failed')
            util.atomic(root..'/device.key',assert(util.read(dir..'/device.key',8192)))
            local value={device_id=did,hardware_hash=hw,public_key=codec.encode(der)}
            util.atomic(root..'/identity.json',json.stringify(value))
            return value
        end)
        util.cleanup(dir,{'device.key','device.der','hardware'})
        if not ok then error(result) end
        identity=result
    end
    assert(M.current(context),'hardware_changed')
    -- Recovery is explicit: losing this persistent key requires reissuing a device-bound license.
    local keyfile=root..'/device.key'
    assert(util.read(keyfile,8192),'device_key_missing')
    local now=math.max(os.time(),1735689600)
    local payload={schema=1,device_id=identity.device_id,hardware_hash=identity.hardware_hash,public_key=identity.public_key,
        issued_at=now,nonce=util.random_hex(16),purpose='enroll'}
    local raw=json.stringify(payload); local dir=util.tempdir(root)
    local ok,envelope=pcall(function()
        util.write(dir..'/request','BR-REQUEST/1\0'..raw)
        assert(util.exec(util.quote(openssl)..' pkeyutl -sign -rawin -inkey '..util.quote(keyfile)..' -in '..util.quote(dir..'/request')..' -out '..util.quote(dir..'/signature')..' >/dev/null 2>&1'),'device_request_failed')
        return {format='BRREQ1',payload=codec.encode(raw),signature=codec.encode(assert(util.read(dir..'/signature',64)))}
    end)
    util.cleanup(dir,{'request','signature'})
    if not ok then error(envelope) end
    return {machine_code='BRD1.'..codec.encode(json.stringify(envelope)),device_id=identity.device_id}
end
return M
