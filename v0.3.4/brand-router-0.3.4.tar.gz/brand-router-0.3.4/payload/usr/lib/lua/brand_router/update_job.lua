local updater=require 'brand_router.updater'
local util=require 'brand_router.util'
local M={}
function M.run(context,id,backend)
    local root=updater.root(context);local job=updater.read(root,'job')
    if not job or job.id~=id or not job.busy or job.phase~='queued' then return false end
    local installed_recovery;local previous_recovery=updater.read(root,'recovery')
    local function phase(name) job.phase=name;updater.save(root,'job',job) end
    local ok,reason=pcall(function()
        if job.action=='check' then
            phase('checking');local release=updater.manifest(backend.check(phase));updater.save(root,'release',release);updater.save(root,'last-check',{at=os.time()})
            phase('checked')
        elseif job.action=='prepare' or job.action=='upload' then
            require('nixio.fs').unlink(root..'/staged.json')
            phase(job.action=='upload' and 'verifying' or 'downloading')
            local release=updater.manifest(updater.read(root,'release'))
            backend.prepare(release,job.action=='upload',phase)
            updater.save(root,'staged',release);phase('ready')
        elseif job.action=='apply' or job.action=='upgrade' then
            if job.action=='upgrade' then
                require('nixio.fs').unlink(root..'/staged.json')
                local release=updater.manifest(updater.read(root,'release'))
                phase('downloading');backend.prepare(release,false,phase)
                updater.save(root,'staged',release)
            end
            local release=updater.manifest(updater.read(root,'release'));local staged=updater.read(root,'staged')
            assert(staged and staged.sha256==release.sha256,'release_changed')
            phase('installing');local recovery=backend.install(release);installed_recovery=recovery
            updater.save(root,'recovery',recovery)
            phase('verifying_install')
            assert(backend.health(),'new_version_health_failed')
            require('nixio.fs').unlink(root..'/staged.json');phase('completed')
        elseif job.action=='recover' then
            phase('rolling_back');backend.recover(updater.read(root,'recovery'))
            assert(backend.health(),'recovery_health_failed');updater.save(root,'recovery',{});phase('recovered')
        else error('invalid_update_action') end
    end)
    if not ok then
        job.phase='failed'
        local known={update_dns_failed=true,update_connect_failed=true,update_timeout=true,update_tls_failed=true,update_certificate_failed=true,update_http_failed=true,update_write_failed=true,download_failed=true,invalid_release_metadata=true,package_hash_mismatch=true,invalid_update_archive=true,
            preflight_failed=true,install_failed=true,recovery_failed=true,recovery_health_failed=true,storage_reserve_required=true,
            new_version_health_failed=true,recovery_account_incompatible=true,recovery_fixed_incompatible=true,release_changed=true,firmware_not_supported=true,update_package_too_large=true}
        job.error=type(reason)=='table' and reason.code or tostring(reason):match('([a-z_]+)$')
        if not known[job.error] then job.error='update_failed' end
        if installed_recovery then
            -- Recovery must not depend on another successful metadata write.
            local restored=pcall(function() backend.recover(installed_recovery);assert(backend.health(),'recovery_health_failed') end)
            if restored then
                job.phase='rolled_back'
                pcall(updater.save,root,'recovery',previous_recovery or {})
                require('nixio.fs').unlink(root..'/staged.json')
                -- Keep both bundles if restoring metadata itself failed; operator can inspect them.
            else job.error='recovery_failed' end
        end
    end
    job.busy=false;job.finished_at=os.time();updater.save(root,'job',job)
    local history=updater.read(root,'history') or {};table.insert(history,1,{action=job.action,phase=job.phase,error=job.error,at=job.finished_at})
    while #history>10 do table.remove(history) end
    updater.save(root,'history',history)
    if ok and installed_recovery and backend.discard then pcall(backend.discard,previous_recovery) end
    return ok
end
return M
