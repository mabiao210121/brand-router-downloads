-- Only brand-owned services are supervised. Existing ETH deployments are never silently adopted.
local guard=require 'brand_router.guard'
local M={}
M.registry={fixed='brand-fixed',rotation='brand-rotation',dynamic='brand-dynamic',diagnostics='brand-diagnostics'}
function M.halt(reason,site,backend)
    local ok,applied=pcall(function()
        return backend.firewall(guard.plan({state=reason,business_allowed=false},site).nft)
    end)
    for _,name in pairs(M.registry) do pcall(backend.stop,name) end
    return {state=reason,business_allowed=false,enforcement_applied=ok and applied==true or false}
end
local function selected(status,site)
    local permitted={};for _,name in ipairs(status.features or {}) do permitted[name]=true end
    local names,seen={},{}
    for _,mode in ipairs(site.modes or {}) do
        assert(mode=='fixed' or mode=='rotation' or mode=='dynamic','invalid_business_mode')
        assert(not seen[mode],'duplicate_business_mode');seen[mode]=true
        if status.business_allowed and permitted[mode] then names[#names+1]=M.registry[mode] end
    end
    if #names>0 then names[#names+1]=M.registry.diagnostics end
    table.sort(names);return names
end
function M.reconcile(status,site,backend)
    assert(site.enforcement_enabled==true,'enforcement_not_enabled')
    local desired=selected(status,site);local wanted={}
    for _,name in ipairs(desired) do wanted[name]=true end
    local held={state=status.state,business_allowed=false,customer_login_allowed=status.customer_login_allowed}
    if status.business_allowed and #desired==0 then held.state='business_configuration_required' end
    local locked=guard.plan(held,site)
    -- A healthy unchanged business group must not be disconnected once per watchdog tick.
    local steady=status.business_allowed and #desired>0
    if steady then
        for _,name in pairs(M.registry) do
            if backend.running(name)~=not not wanted[name] then steady=false end
        end
    end
    local capable=true
    if status.business_allowed then capable=backend.capabilities(site) end
    local function still_authorized()
        local current=backend.current_license and backend.current_license() or status
        if not current.business_allowed then return false,current.state end
        local fresh=selected(current,site)
        if #fresh~=#desired then return false,'authorization_changed' end
        for n,name in ipairs(fresh) do if name~=desired[n] then return false,'authorization_changed' end end
        return true
    end
    if steady and capable then
        local allowed,reason=still_authorized()
        if not allowed then return M.halt(reason,site,backend) end
        local active=guard.plan(status,site)
        if backend.firewall(active.nft) then return {state='active',business_allowed=true,enforcement_applied=true,services=desired} end
    end
    -- Block packets before stopping processes or starting a new group.
    if not backend.firewall(locked.nft) then
        for _,name in pairs(M.registry) do backend.stop(name) end
        return {state='firewall_apply_failed',business_allowed=false,enforcement_applied=false}
    end
    if not status.business_allowed then
        for _,name in pairs(M.registry) do backend.stop(name) end
        return {state=status.state,business_allowed=false,enforcement_applied=true,services={}}
    end
    if not capable then
        for _,name in pairs(M.registry) do backend.stop(name) end
        return {state='enforcement_capability_check_failed',business_allowed=false,enforcement_applied=true}
    end
    for _,name in pairs(M.registry) do if not wanted[name] then backend.stop(name) end end
    local ready=#desired>0
    for _,name in ipairs(desired) do
        if not backend.running(name) then backend.start(name) end
        if not backend.running(name) then ready=false end
    end
    if status.business_allowed and ready then
        local allowed,reason=still_authorized()
        if not allowed then return M.halt(reason,site,backend) end
        local active=guard.plan(status,site)
        if backend.firewall(active.nft) then return {state='active',business_allowed=true,enforcement_applied=true,services=desired} end
        for _,name in pairs(M.registry) do backend.stop(name) end
        return {state='firewall_apply_failed',business_allowed=false,enforcement_applied=true}
    end
    return {state=status.business_allowed and (ready and held.state or 'business_not_ready') or status.state,
        business_allowed=false,enforcement_applied=true,services=desired}
end
return M
