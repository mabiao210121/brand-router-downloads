-- Validate before replacing the last good zone. Failures close that zone and stop owned services.
local guard=require 'brand_router.guard'
local controller=require 'brand_router.controller'
local M={}
function M.valid(site)
    if type(site)~='table' or site.enforcement_enabled~=true then return false end
    return pcall(function()
        guard.plan({state='configuration_probe',business_allowed=false},site)
        assert(type(site.modes or {})=='table','invalid_business_modes')
        local seen={}
        for key,mode in pairs(site.modes or {}) do
            assert(type(key)=='number' and key%1==0 and key>=1 and key<=3 and
                (mode=='fixed' or mode=='rotation' or mode=='dynamic') and not seen[mode],'invalid_business_modes')
            seen[mode]=true
        end
    end)
end
function M.tick(site,last_good,backend,observe,save)
    if not M.valid(site) then
        if not M.valid(last_good) then return {state='not_enabled',business_allowed=false,enforcement_applied=false},nil end
        return controller.halt('site_configuration_lost',last_good,backend),last_good
    end
    local ok,result=pcall(function()
        if save then save(site) end
        return controller.reconcile(observe(),site,backend)
    end)
    if not ok then result=controller.halt('enforcement_error',site,backend) end
    return result,site
end
return M
