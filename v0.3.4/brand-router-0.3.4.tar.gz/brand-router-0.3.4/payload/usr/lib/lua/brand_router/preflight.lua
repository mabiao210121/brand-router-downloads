local util=require 'brand_router.util'
local resources=require 'brand_router.resources'
local M={}
local required={lua='lua',openssl='openssl-util',ubus='ubus',uci='uci',nft='nftables-json'}
function M.inspect()
    local release=util.read('/etc/openwrt_release',4096) or ''
    local profile=resources.inspect();local missing={}
    for cmd,pkg in pairs(required) do
        if not util.exec('command -v '..cmd..' >/dev/null 2>&1') then missing[#missing+1]=pkg end
    end
    table.sort(missing)
    local compatible=release:find('DISTRIB_ID=')~=nil and release:find('24%.10')~=nil
    return {read_only=true,firmware_supported=compatible,resource_profile=profile,missing_packages=missing,
        install_allowed=false,ready_for_experiment=compatible and profile.minimum_supported and #missing==0,
        next_step='核对具体iStoreOS构建、内核ABI与软件源，验证实验机后再启用安装及业务迁移'}
end
return M
