-- Pure compiler for existing-LAN MAC bindings. Never changes DHCP or chooses a fallback node.
local M={mark=16978,table=18283,priority=18283}
local function check(ok,code) assert(ok,code) end
local function outbound(n,tag)
    check(n.protocol=='vless','fixed_protocol_not_supported')
    local supported={tcp=true,ws=true,grpc=true,httpupgrade=true,xhttp=true}
    check(supported[n.transport],'fixed_transport_not_supported')
    local stream={network=n.transport,security=n.security}
    if n.security=='reality' then
        stream.realitySettings={serverName=n.sni,publicKey=n.public_key,shortId=n.short_id,fingerprint=n.fingerprint~='' and n.fingerprint or 'chrome'}
        if n.spider_x~='' then stream.realitySettings.spiderX=n.spider_x end
    elseif n.security=='tls' then
        stream.tlsSettings={serverName=n.sni~='' and n.sni or n.server,allowInsecure=false}
        if n.fingerprint~='' then stream.tlsSettings.fingerprint=n.fingerprint end
        if n.alpn~='' then local alpn={};for p in n.alpn:gmatch('[^,]+') do alpn[#alpn+1]=p end;stream.tlsSettings.alpn=alpn end
    else check(n.security=='none','fixed_security_not_supported') end
    if n.transport=='grpc' then
        check(n.mode=='' or n.mode=='gun' or n.mode=='multi','fixed_transport_not_supported')
        stream.grpcSettings={serviceName=n.service_name,multiMode=n.mode=='multi'}
        if n.authority~='' then stream.grpcSettings.authority=n.authority end
    elseif n.transport=='ws' then stream.wsSettings={path=n.path};if n.host~='' then stream.wsSettings.headers={Host=n.host} end
    elseif n.transport=='httpupgrade' then stream.httpupgradeSettings={path=n.path,host=n.host}
    elseif n.transport=='xhttp' then stream.xhttpSettings={path=n.path,host=n.host,mode=n.mode~='' and n.mode or 'auto'} end
    local user={id=n.uuid,encryption='none'};if n.flow~='' then user.flow=n.flow end
    return {tag=tag,protocol='vless',settings={vnext={{address=n.server,port=n.port,users={user}}}},streamSettings=stream}
end
function M.compile(doc,iface)
    check(type(iface)=='string' and #iface<=15 and iface:match('^[A-Za-z0-9_.-]+$'),'fixed_interface_required')
    local bindings,used,seen={},{},{}
    for _,b in pairs(doc.bindings) do if b.mac~='' then
        local mac=require('brand_router.business').mac(b.mac);check(not seen[mac],'duplicate_mac');seen[mac]=true
        check(doc.nodes[b.node_id],'node_not_found');used[b.node_id]=true
        bindings[#bindings+1]={id=b.id,node_id=b.node_id,mac=mac}
    end end
    check(#bindings>0 and #bindings<=1024,'fixed_bindings_required')
    table.sort(bindings,function(a,b)return a.id<b.id end)
    local ids={};for id in pairs(used) do ids[#ids+1]=id end;table.sort(ids);check(#ids<=256,'config_capacity')
    local config={log={loglevel='warning'},inbounds={},outbounds={{tag='blocked',protocol='blackhole',settings={response={type='none'}}}},routing={domainStrategy='AsIs',rules={}}}
    -- DNS is translated to upstream TCP by sing-box and uses this node's local SOCKS listener.
    -- This avoids relying on provider UDP support or losing the original client reply address.
    local dns_config={log={level='error'},inbounds={},outbounds={},dns={servers={},rules={},independent_cache=true},route={rules={}}}
    local nodes={};local ports={}
    for index,id in ipairs(ids) do
        local port=36000+(index-1)*2;local tag='node-'..index;local dns=port+1;local probe=38000+index-1
        nodes[id]={port=port,dns_port=dns,probe_port=probe,tag=tag};ports[#ports+1]=tostring(port);ports[#ports+1]=tostring(dns)
        config.outbounds[#config.outbounds+1]=outbound(doc.nodes[id],tag)
        config.inbounds[#config.inbounds+1]={tag=tag..'-traffic',listen='0.0.0.0',port=port,protocol='dokodemo-door',settings={network='tcp,udp',followRedirect=true},streamSettings={sockopt={tproxy='tproxy'}}}
        config.inbounds[#config.inbounds+1]={tag=tag..'-probe',listen='127.0.0.1',port=probe,protocol='socks',settings={auth='noauth',udp=true,ip='127.0.0.1'}}
        config.routing.rules[#config.routing.rules+1]={type='field',inboundTag={tag..'-traffic',tag..'-probe'},outboundTag=tag}
        -- NAT restores the original DNS reply address. A UDP TPROXY reply socket
        -- can otherwise bind the router's own :53 and steal ordinary LAN DNS.
        dns_config.inbounds[#dns_config.inbounds+1]={type='direct',tag=tag..'-dns',listen='0.0.0.0',listen_port=dns,udp_timeout='30s'}
        dns_config.outbounds[#dns_config.outbounds+1]={type='socks',tag=tag,server='127.0.0.1',server_port=probe,version='5'}
        dns_config.dns.servers[#dns_config.dns.servers+1]={type='tcp',tag=tag..'-resolver',server='1.1.1.1',server_port=53,detour=tag}
        dns_config.dns.rules[#dns_config.dns.rules+1]={inbound={tag..'-dns'},action='route',server=tag..'-resolver'}
        dns_config.route.rules[#dns_config.route.rules+1]={inbound={tag..'-dns'},action='hijack-dns'}
    end
    dns_config.dns.rules[#dns_config.dns.rules+1]={action='reject'}
    dns_config.route.rules[#dns_config.route.rules+1]={action='reject'}
    local macs={};for _,b in ipairs(bindings) do macs[#macs+1]=b.mac end
    local function rules(active)
        local lines={'table inet brand_fixed {',' set clients { type ether_addr; elements = { '..table.concat(macs,', ')..' } }',
            ' chain input_guard { type filter hook input priority -21; policy accept;',
            '  iifname != "lo" meta mark != 0x4252 meta l4proto { tcp, udp } th dport { '..table.concat(ports,', ')..' } drop',' }',
            ' chain forward_guard { type filter hook forward priority -21; policy accept;',
            '  iifname "'..iface..'" ether saddr @clients counter drop',' }',
            ' chain prerouting { type filter hook prerouting priority -151; policy accept;',
            '  iifname != "'..iface..'" return','  ether saddr != @clients return',
            '  meta nfproto ipv6 counter drop','  udp sport 68 udp dport 67 return'}
        if active then
            lines[#lines+1]='  meta nfproto ipv4 meta l4proto { tcp, udp } th dport 53 counter meta mark set 0x4252 return'
        end
        -- Owner management stays reachable; router DNS is captured above while active.
        lines[#lines+1]='  fib daddr type local tcp dport { 22, 80, 443, 28283 } return'
        if active then
            for _,b in ipairs(bindings) do local n=nodes[b.node_id]
                lines[#lines+1]='  ether saddr '..b.mac..' meta nfproto ipv4 meta l4proto { tcp, udp } counter meta mark set 0x4252 tproxy ip to :'..n.port..' accept'
            end
        end
        lines[#lines+1]='  counter drop';lines[#lines+1]=' }'
        if active then
            lines[#lines+1]=' chain dns_redirect { type nat hook prerouting priority -101; policy accept;'
            lines[#lines+1]='  iifname != "'..iface..'" return'
            for _,b in ipairs(bindings) do local n=nodes[b.node_id]
                lines[#lines+1]='  ether saddr '..b.mac..' meta nfproto ipv4 meta l4proto { tcp, udp } th dport 53 counter redirect to :'..n.dns_port
            end
            lines[#lines+1]=' }'
        end
        lines[#lines+1]='}'
        return table.concat(lines,'\n')..'\n'
    end
    return {revision=doc.revision,interface=iface,bindings=bindings,nodes=nodes,config=config,dns_config=dns_config,active_nft=rules(true),blocked_nft=rules(false)}
end
return M
