-- Strict regular-file USTAR reader; never ask tar to extract untrusted paths or links.
local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local M={}
local function check(ok) assert(ok,'invalid_update_archive') end
local function text(s) return s:match('^[^%z]*') end
local function oct(s) local n=s:gsub('%z',''):match('^%s*([0-7]+)%s*$');return n and tonumber(n,8) end
function M.parse(raw,version)
    check(type(raw)=='string' and #raw<=8388608 and #raw%512==0)
    local prefix='brand-router-'..version..'/'
    local files,pos,count,total={},1,0,0
    while pos<=#raw do
        local h=raw:sub(pos,pos+511)
        if h==string.rep('\0',512) then
            check(raw:sub(pos)==string.rep('\0',#raw-pos+1) and #raw-pos+1>=1024)
            check(files['install.sh'] and files['files.list'] and files['candidate.json'] and files['checksums.sha256'])
            return files
        end
        local name=text(h:sub(1,100));local pre=text(h:sub(346,500));if pre~='' then name=pre..'/'..name end
        check(h:sub(258,262)=='ustar' and (h:sub(157,157)=='0' or h:sub(157,157)=='\0'))
        check(name:sub(1,#prefix)==prefix)
        name=name:sub(#prefix+1)
        check(name~='' and not name:find('[^%w_./-]') and not name:find('..',1,true) and not name:find('//',1,true) and name:sub(1,1)~='/' and not files[name])
        check(name=='install.sh' or name=='files.list' or name=='candidate.json' or name=='checksums.sha256' or name:sub(1,8)=='payload/')
        local size,mode,checksum=oct(h:sub(125,136)),oct(h:sub(101,108)),oct(h:sub(149,156))
        local sum=0;for i=1,512 do sum=sum+((i>=149 and i<=156) and 32 or h:byte(i)) end
        check(checksum==sum and size and size<=1048576 and (mode==420 or mode==493))
        total=total+size;count=count+1;check(total<=4194304 and count<=80 and pos+511+size<=#raw)
        files[name]={data=raw:sub(pos+512,pos+511+size),mode=mode}
        pos=pos+512+math.ceil(size/512)*512
    end
    error('invalid_update_archive')
end
function M.extract(raw,version,destination)
    local files=M.parse(raw,version)
    local checks,seen={},{}
    for line in files['checksums.sha256'].data:gmatch('[^\n]+') do
        local hash,name=line:match('^([0-9a-f]+)  (.+)$')
        check(hash and #hash==64 and files[name] and name~='checksums.sha256' and not checks[name]);checks[name]=hash
    end
    for name,item in pairs(files) do
        check(name=='checksums.sha256' or checks[name])
        local path=destination..'/'..name;local parent=path:match('^(.*)/[^/]+$')
        check(util.exec('mkdir -p '..util.quote(parent)))
        util.write(path,item.data)
        check(require('nixio.fs').chmod(path,item.mode==493 and '755' or '644'))
        if checks[name] then local hash=(util.capture('sha256sum '..util.quote(path),1024) or ''):match('^([0-9a-f]+)');check(hash==checks[name]) end
    end
    local count=0
    for line in files['files.list'].data:gmatch('[^\n]+') do
        local mode,name=line:match('^(%d+) ([%w_./-]+)$');check(mode and files['payload/'..name] and not seen[name])
        check(tonumber(mode,8)==files['payload/'..name].mode);seen[name]=true;count=count+1
    end
    check(count>0 and count<=64)
    for name in pairs(files) do if name:sub(1,8)=='payload/' then check(seen[name:sub(9)]) end end
    local candidate=json.parse(files['candidate.json'].data);local build=files['payload/usr/share/brand-router/build.json']
    check(candidate and candidate.version==version and candidate.target=='iStoreOS 24.10 x86_64' and build)
    build=json.parse(build.data);check(build and build.schema==1 and build.version==version)
    return build
end
return M
