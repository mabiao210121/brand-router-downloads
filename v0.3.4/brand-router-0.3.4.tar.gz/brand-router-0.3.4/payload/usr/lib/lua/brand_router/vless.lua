-- Parse a bounded VLESS URI locally. Never fetch a subscription or resolve a host.
local M={}
local function check(ok,code) if not ok then error({code=code},0) end end
local function utf8(s)
    local i=1
    while i<=#s do
        local a=s:byte(i);local length=1
        if a>=0xc2 and a<=0xdf then length=2
        elseif a>=0xe0 and a<=0xef then length=3
        elseif a>=0xf0 and a<=0xf4 then length=4
        elseif a>=0x80 then return false end
        for j=1,length-1 do local b=s:byte(i+j);if not b or b<0x80 or b>0xbf then return false end end
        local b=s:byte(i+1)
        if (a==0xe0 and b<0xa0) or (a==0xed and b>=0xa0) or (a==0xf0 and b<0x90) or (a==0xf4 and b>=0x90) then return false end
        i=i+length
    end
    return true
end
local function decode(s)
    check(not s:gsub('%%[%x][%x]',''):find('%%'),'invalid_link_encoding')
    s=s:gsub('%%(%x%x)',function(h) return string.char(tonumber(h,16)) end)
    check(utf8(s) and not s:find('[%z\1-\31\127]'),'invalid_link_encoding')
    return s
end
M.decode=decode
M.valid_utf8=utf8
local allowed={encryption=true,type=true,security=true,sni=true,fp=true,pbk=true,sid=true,flow=true,
    path=true,host=true,serviceName=true,alpn=true,headerType=true,mode=true,authority=true,spx=true,allowInsecure=true}
function M.parse(raw)
    check(type(raw)=='string' and #raw<=4096,'invalid_vless_link')
    raw=raw:match('^%s*(.-)%s*$')
    check(raw:sub(1,8):lower()=='vless://' and not raw:find('%s'),'invalid_vless_link')
    local rest=raw:sub(9)
    local fragment='';local hash=rest:find('#',1,true)
    if hash then fragment=decode(rest:sub(hash+1));rest=rest:sub(1,hash-1) end
    local authority,query=rest:match('^([^?]+)%?(.*)$')
    if not authority then authority=rest;query='' end
    local user,endpoint=authority:match('^([^@]+)@([^@]+)$')
    check(user and endpoint,'invalid_vless_link')
    local server,port=endpoint:match('^%[([^%]]+)%]:(%d+)$')
    if not server then server,port=endpoint:match('^([^:/%[%]]+):(%d+)$') end
    check(server and port,'invalid_vless_link')
    local params={}
    if query~='' then
        check(not query:find('&&',1,true) and query:sub(1,1)~='&' and query:sub(-1)~='&','invalid_vless_link')
        for pair in query:gmatch('[^&]+') do
            local key,value=pair:match('^([^=]+)=(.*)$')
            check(key,'invalid_vless_link');key=decode(key);value=decode(value)
            check(allowed[key],'unsupported_link_parameter')
            check(params[key]==nil,'duplicate_link_parameter');params[key]=value
        end
    end
    check(not params.encryption or params.encryption=='none','unsupported_vless_encryption')
    check(not params.headerType or params.headerType=='none','unsupported_link_parameter')
    check(not params.allowInsecure or params.allowInsecure=='0' or params.allowInsecure=='false','unsupported_link_parameter')
    local transport=params.type or 'tcp';if transport=='raw' then transport='tcp' end
    local security=params.security or 'none'
    check(not (params.pbk or params.sid or params.spx) or security=='reality','link_parameter_conflict')
    check(not (params.path or params.host) or transport=='ws' or transport=='httpupgrade' or transport=='xhttp','link_parameter_conflict')
    check(not (params.serviceName or params.authority) or transport=='grpc','link_parameter_conflict')
    check(not params.mode or transport=='grpc' or transport=='xhttp','link_parameter_conflict')
    check(not (params.sni or params.alpn or params.fp) or security~='none','link_parameter_conflict')
    return {name=fragment~='' and fragment or server..':'..port,protocol='vless',uuid=decode(user):lower(),
        server=server:lower(),port=tonumber(port),transport=transport,security=security,
        sni=params.sni or (security~='none' and server or ''),fingerprint=params.fp or (security~='none' and 'chrome' or ''),public_key=params.pbk or '',short_id=params.sid or '',
        flow=params.flow or '',path=params.path or '/',host=params.host or '',service_name=params.serviceName or '',
        alpn=params.alpn or '',mode=params.mode or '',authority=params.authority or '',spider_x=params.spx or ''}
end
return M
