-- Existing-LAN fixed bindings only. Configuration changes require an explicit apply.
local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local plan=require 'brand_router.fixed_plan'
local M={}
local cached
local function check(ok,code) assert(ok,code) end
local function root(c) return c.fixed_root or '/etc/brand-router/fixed' end
local function read(path) return json.parse(util.read(path,1048576) or '') end
local function current(c)
    local value=read(root(c)..'/current.json')
    if not value then return nil end
    check(type(value.generation)=='string' and #value.generation==32 and not value.generation:find('[^a-f0-9]'),'fixed_state_invalid')
    return value,root(c)..'/'..value.generation
end
function M.config_path(c,dns)
    local _,dir=current(c);check(dir,'fixed_not_applied');return dir..(dns and '/dns.json' or '/xray.json')
end
function M.enabled(c) return fs.lstat(root(c)..'/current.json')~=nil or fs.lstat(root(c)..'/failure.nft')~=nil end
local function running(c)
    local services=json.parse(util.capture("ubus -t 1 call service list '{\"name\":\"brand-fixed\"}' 2>/dev/null",65536) or '')
    local instance=services and services['brand-fixed'] and services['brand-fixed'].instances and services['brand-fixed'].instances.fixed
    if not instance or instance.running~=true then return false end
    local expected=M.config_path(c)
    local dns=services['brand-fixed'].instances.dns
    return instance.command and instance.command[1]=='/usr/bin/xray' and instance.command[4]==expected and dns and dns.running==true and dns.command and dns.command[1]=='/usr/bin/sing-box' and dns.command[4]==M.config_path(c,true)
end
local function firewall(c,text)
    local exists=util.exec('nft list table inet brand_fixed >/dev/null 2>&1')
    if exists and cached==text then return true end
    util.atomic(root(c)..'/batch.nft',(exists and 'delete table inet brand_fixed\n' or '')..text)
    local file=util.quote(root(c)..'/batch.nft')
    local ok=util.exec('nft -c -f '..file..' >/dev/null 2>&1') and util.exec('nft -f '..file..' >/dev/null 2>&1')
    if ok then cached=text end
    return ok
end
local function authorized(c,observe)
    local s=observe and util.with_lock(c.lock_dir or '/var/lock/brand-router-state',function() return require('brand_router.license').observe(c) end) or require('brand_router.license').status(c)
    if s.business_allowed then for _,f in ipairs(s.features or {}) do if f=='fixed' then return true,s.state end end end
    return false,s.state
end
local function routes()
    local rules=util.capture('ip -4 rule show',32768) or ''
    local found=false
    for line in rules:gmatch('[^\n]+') do if line:match('^18283:') then
        check(line:find('fwmark 0x4252',1,true) and line:find('lookup 18283',1,true),'fixed_route_conflict');found=true
    end end
    local table_routes=util.capture('ip -4 route show table 18283 2>/dev/null',16384) or ''
    check(table_routes=='' or table_routes:match('^local default dev lo') or table_routes:match('^local 0.0.0.0/0 dev lo'),'fixed_route_conflict')
    check(util.exec('ip -4 route replace local 0.0.0.0/0 dev lo table 18283'),'fixed_route_failed')
    if not found then check(util.exec('ip -4 rule add fwmark 0x4252 lookup 18283 priority 18283'),'fixed_route_failed') end
end
local function publish(c,v)
    v.observed_at=os.time();util.atomic(c.fixed_status or '/tmp/brand-fixed-status.json',json.stringify(v));return v
end
function M.tick(c)
    return util.with_lock('/var/lock/brand-fixed',function()
        local suspended=util.read(root(c)..'/failure.nft',1048576)
        if suspended then
            check(firewall(c,suspended),'fixed_firewall_failed');util.exec('/etc/init.d/brand-fixed stop >/dev/null 2>&1')
            local state=read(c.fixed_status or '/tmp/brand-fixed-status.json') or {}
            return publish(c,{applied=false,state='apply_failed',revision=state.revision,count=state.count})
        end
        local state,dir=current(c);if not state then return end
        local allowed,reason=authorized(c,true)
        local active=util.read(dir..'/active.nft',1048576);local blocked=util.read(dir..'/blocked.nft',1048576)
        check(active and blocked,'fixed_state_invalid')
        local healthy=running(c)
        if not allowed or not healthy then
            check(firewall(c,blocked),'fixed_firewall_failed')
            if not allowed then util.exec('/etc/init.d/brand-fixed stop >/dev/null 2>&1')
            else
                routes();util.exec('/etc/init.d/brand-fixed start >/dev/null 2>&1')
            end
            return publish(c,{applied=false,state=allowed and 'starting' or reason,revision=state.revision,count=state.count})
        end
        check(firewall(c,active),'fixed_firewall_failed')
        return publish(c,{applied=true,state='active',revision=state.revision,count=state.count})
    end)
end
function M.status(c,revision)
    local value=read(c.fixed_status or '/tmp/brand-fixed-status.json')
    if not value or os.time()-(value.observed_at or 0)>5 then
        return {applied=false,state='not_connected',message='固定绑定尚未运行，或运行状态暂不可确认。'}
    end
    if value.revision~=revision then
        return {applied=false,state='pending',message='配置已保存，尚未应用本次修改；当前转发仍使用上次应用的配置。'}
    end
    return {applied=value.applied==true,state=value.state,count=value.count,
        message=value.applied and ('固定绑定转发已启动，覆盖 '..value.count..' 个 MAC；请用设备实际出口验收。租约轮询和动态会话尚未接通。') or '固定绑定已阻断外网，正在检查授权或代理核心状态；管理入口保留。'}
end
local function apply(c,revision,doc,expected_generation)
    check(not c.allow_lab_http,'preview_only')
    local allowed=authorized(c);check(allowed,'authorization_required')
    check(util.exec('test -x /usr/bin/xray && test -x /usr/bin/sing-box'),'fixed_core_required')
    local rules=json.parse(util.capture('nft -j list ruleset',4194304) or '')
    check(rules and rules.nftables,'fixed_firewall_unavailable')
    for _,v in ipairs(rules.nftables) do check(not v.flowtable,'fixed_offload_not_supported') end
    local lan=json.parse(util.capture('ubus -t 2 call network.interface.lan status',32768) or '')
    check(lan and lan.up and lan.l3_device,'fixed_interface_required')
    check(doc.revision==revision,'revision_conflict')
    check(not next(doc.mode_plans or {}),'fixed_existing_lan_only')
    local p=plan.compile(doc,lan.l3_device)
    util.private_dir(root(c),c.private_uid)
    return util.with_lock('/var/lock/brand-fixed',function()
        local old,old_dir=current(c)
        if expected_generation then check(old and old.generation==expected_generation,'fixed_generation_changed') end
        local generation=util.random_hex(16);local dir=root(c)..'/'..generation;util.private_dir(dir,c.private_uid)
        util.atomic(dir..'/xray.json',json.stringify(p.config));util.atomic(dir..'/active.nft',p.active_nft);util.atomic(dir..'/blocked.nft',p.blocked_nft)
        util.atomic(dir..'/dns.json',json.stringify(p.dns_config))
        local snapshot={revision=doc.revision,nodes={},bindings={},mode_plans={}}
        for _,b in ipairs(p.bindings) do snapshot.bindings[b.id]=b;snapshot.nodes[b.node_id]=doc.nodes[b.node_id] end
        util.atomic(dir..'/document.json',json.stringify(snapshot))
        util.atomic(dir..'/plan.json',json.stringify({bindings=p.bindings,nodes=p.nodes,interface=p.interface,revision=p.revision}))
        check(util.exec('xray run -test -c '..util.quote(dir..'/xray.json')..' > '..util.quote(root(c)..'/check.log')..' 2>&1'),'fixed_core_check_failed')
        check(util.exec('sing-box check -c '..util.quote(dir..'/dns.json')..' >> '..util.quote(root(c)..'/check.log')..' 2>&1'),'fixed_core_check_failed')
        -- Check syntax against a temporary transaction; never flush unrelated tables.
        local exists=util.exec('nft list table inet brand_fixed >/dev/null 2>&1')
        util.atomic(root(c)..'/check.nft',(exists and 'delete table inet brand_fixed\n' or '')..p.active_nft)
        check(util.exec('nft -c -f '..util.quote(root(c)..'/check.nft')..' >/dev/null 2>&1'),'fixed_firewall_failed')
        -- During replacement, old and new registered MACs must both stay blocked.
        local macs,seen={},{};for _,b in ipairs(p.bindings) do seen[b.mac]=true;macs[#macs+1]=b.mac end
        if old_dir then local previous=read(old_dir..'/plan.json');for _,b in ipairs(previous and previous.bindings or {}) do if not seen[b.mac] then macs[#macs+1]=b.mac;seen[b.mac]=true end end end
        local held=p.blocked_nft:gsub('elements = { [^}]+ }','elements = { '..table.concat(macs,', ')..' }',1)
        -- Persist the hold before touching running traffic; supervision must also
        -- restore it after first-apply failure, restart, or firewall table loss.
        util.atomic(root(c)..'/failure.nft',held)
        check(firewall(c,held),'fixed_firewall_failed')
        util.exec('/etc/init.d/brand-fixed stop >/dev/null 2>&1')
        local ok,result=pcall(function()
            check(util.exec('/etc/init.d/brand-license enable && /etc/init.d/brand-license restart >/dev/null 2>&1'),'fixed_supervisor_failed')
            routes()
            if old then util.atomic(root(c)..'/previous.json',json.stringify(old)) end
            util.atomic(root(c)..'/current.json',json.stringify({generation=generation,revision=p.revision,count=#p.bindings}))
            check(authorized(c),'authorization_required')
            check(util.exec('/etc/init.d/brand-fixed start >/dev/null 2>&1'),'fixed_core_start_failed')
            fs.unlink(root(c)..'/failure.nft')
            return {accepted=true,count=#p.bindings,revision=p.revision}
        end)
        if not ok then
            util.exec('/etc/init.d/brand-fixed stop >/dev/null 2>&1')
            util.atomic(root(c)..'/failure.nft',held)
            if old then util.atomic(root(c)..'/current.json',json.stringify(old)) end
            publish(c,{applied=false,state='apply_failed',revision=p.revision,count=#p.bindings})
            error(result,0)
        end
        return result
    end)
end
function M.apply(c,revision)
    return apply(c,revision,require('brand_router.business').load(c))
end
function M.refresh(c)
    -- Upgrades recompile only the applied snapshot, never pending saved edits.
    check(not fs.lstat(root(c)..'/failure.nft'),'fixed_refresh_suspended')
    local state,dir=current(c);check(state,'fixed_not_applied')
    local doc=read(dir..'/document.json')
    if not doc then
        -- Older versions did not retain an input snapshot. Refuse a migration
        -- with pending edits rather than silently applying or guessing them.
        doc=require('brand_router.business').load(c)
        check(doc.revision==state.revision,'fixed_refresh_pending_legacy')
    end
    check(doc.revision==state.revision,'fixed_state_invalid')
    return apply(c,state.revision,doc,state.generation)
end
return M
