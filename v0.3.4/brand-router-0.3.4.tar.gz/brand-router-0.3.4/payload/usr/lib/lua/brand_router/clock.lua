-- A same-boot monotonic floor prevents small wall-clock adjustments from extending a license.
local json=require 'luci.jsonc'
local util=require 'brand_router.util'
local M={}
local function sample(context)
    local uptime=tonumber((util.read(context.uptime_path or '/proc/uptime',128) or ''):match('^[%d.]+'))
    local boot=(util.read(context.boot_id_path or '/proc/sys/kernel/random/boot_id',128) or ''):match('^%s*(.-)%s*$')
    return uptime,boot
end
function M.effective(context,wall)
    wall=wall or os.time()
    local uptime,boot=sample(context)
    if not uptime or not boot or #boot==0 then return wall,'clock_source_unavailable' end
    local state=json.parse(util.read(context.clock_path or '/tmp/brand-router-clock.json') or '')
    if type(state)=='table' and state.boot_id==boot and type(state.wall)=='number' and type(state.uptime)=='number' and uptime>=state.uptime then
        local floor=math.floor(state.wall+uptime-state.uptime)
        return math.max(wall,floor),wall+120<floor and 'clock_rollback' or nil
    end
    return wall,nil
end
function M.record(context,wall)
    wall=wall or os.time()
    local now,reason=M.effective(context,wall)
    local uptime,boot=sample(context)
    if uptime and boot and #boot>0 then
        util.atomic(context.clock_path or '/tmp/brand-router-clock.json',json.stringify({boot_id=boot,wall=now,uptime=uptime}))
    end
    return now,reason
end
return M
