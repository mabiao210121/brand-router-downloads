-- Bounded, offline share-link import. No DNS, subscriptions, shell or network calls.
local json=require 'luci.jsonc'
local codec=require 'brand_router.codec'
local vless=require 'brand_router.vless'
local M={}
local decode=vless.decode
local function check(ok,code) if not ok then error({code=code},0) end end
local function clean(s)
    check(type(s)=='string' and vless.valid_utf8(s) and not s:find('[%z\1-\31\127]'),'invalid_link_encoding')
    return s
end
local function b64(s)
    local data,padding=s:match('^([A-Za-z0-9_+/%-]+)(=*)$')
    check(data and #padding<=2 and (#padding==0 or (#s%4==0 and #padding==(4-#data%4)%4)),'invalid_link_base64')
    check(not (data:find('[+/]') and data:find('[_%-]')),'invalid_link_base64')
    local value=codec.decode(data:gsub('%+','-'):gsub('/','_'),4096)
    check(value,'invalid_link_base64');return value
end
local function split_fragment(rest)
    local pos=rest:find('#',1,true)
    if pos then return rest:sub(1,pos-1),decode(rest:sub(pos+1)) end
    return rest,''
end
local function endpoint(value,default_port)
    -- An optional trailing slash belongs to URI syntax, never to the transport path.
    value=value:gsub('/$','')
    local server,port=value:match('^%[([^%]]+)%]:(%d+)$')
    if not server then server,port=value:match('^([^:/%[%]]+):(%d+)$') end
    if not server and default_port then
        server=value:match('^%[([^%]]+)%]$') or value:match('^([^:/%[%]]+)$');port=default_port
    end
    check(server and port,'invalid_share_link')
    return server:lower(),tonumber(port)
end
local function query(raw,allowed)
    local result={}
    if raw~='' then
        check(not raw:find('&&',1,true) and raw:sub(1,1)~='&' and raw:sub(-1)~='&','invalid_share_link')
        for pair in raw:gmatch('[^&]+') do
            local key,value=pair:match('^([^=]+)=(.*)$');check(key,'invalid_share_link')
            key=decode(key);value=decode(value)
            check(allowed[key],'unsupported_link_parameter')
            check(result[key]==nil,'duplicate_link_parameter');result[key]=value
        end
    end
    return result
end
local function keys(names)
    local out={};for name in names:gmatch('%S+') do out[name]=true end;return out
end
local tls_keys='sni peer alpn allowInsecure allow_insecure insecure'
local function alias(p,names)
    local value
    for name in names:gmatch('%S+') do
        if p[name]~=nil then check(value==nil,'duplicate_link_parameter');value=p[name] end
    end
    return value
end
local function tls(n,p)
    local insecure=alias(p,'allowInsecure allow_insecure insecure')
    check(not insecure or insecure=='0' or insecure=='false','unsupported_link_parameter')
    local sni=alias(p,'sni peer')
    check(n.security~='none' or not (sni or p.alpn or p.fp or insecure),'link_parameter_conflict')
    n.sni=sni or (n.security~='none' and n.server or '')
    n.alpn=p.alpn or '';n.fingerprint=p.fp or ''
end
local function stream(n,p)
    n.transport=p.type or 'tcp';if n.transport=='raw' then n.transport='tcp' end
    n.security=p.security or (n.protocol=='trojan' and 'tls' or 'none')
    local http=n.transport=='ws' or n.transport=='httpupgrade'
    check(not (p.path or p.host) or http,'link_parameter_conflict')
    check(not (p.serviceName or p.authority or p.mode) or n.transport=='grpc','link_parameter_conflict')
    check(not p.headerType or p.headerType=='none','unsupported_link_parameter')
    n.path=p.path or '/';n.host=p.host or '';n.service_name=p.serviceName or ''
    n.authority=p.authority or '';n.mode=p.mode or '';tls(n,p)
end
local function uri(rest,protocol,allowed,default_port)
    local body,name=split_fragment(rest)
    local authority,params=body:match('^([^?]+)%?(.*)$')
    if not authority then authority=body;params='' end
    local user,address=authority:match('^([^@]+)@([^@]+)$')
    if not address then check(not authority:find('@',1,true),'invalid_share_link');address=authority end
    local server,port=endpoint(address,default_port)
    return {name=name~='' and name or server..':'..port,protocol=protocol,server=server,port=port},user,query(params,allowed)
end
local function pair(value)
    local user,password=value:match('^([^:]+):(.*)$')
    check(user,'invalid_link_credentials');return user,password
end
-- VMess exports are a flat JSON object. Read scalar tokens explicitly so that
-- duplicate (including escaped) keys cannot be silently replaced by json-c.
local function flat_json(raw)
    check(vless.valid_utf8(raw),'invalid_link_encoding')
    local pos,out=1,{}
    local function spaces() local _,last=raw:find('^[ \t\r\n]*',pos);pos=(last or pos-1)+1 end
    local function quoted()
        check(raw:sub(pos,pos)=='"','invalid_vmess_json')
        local first=pos;pos=pos+1
        while pos<=#raw do
            local c=raw:sub(pos,pos);pos=pos+1
            if c=='"' then
                local ok,value=pcall(json.parse,raw:sub(first,pos-1))
                check(ok and type(value)=='string','invalid_vmess_json');return clean(value)
            elseif c=='\\' then
                local escape=raw:sub(pos,pos)
                check(escape~='' and ('"\\/bfnrtu'):find(escape,1,true),'invalid_vmess_json')
                if escape=='u' then check(raw:sub(pos+1,pos+4):match('^%x%x%x%x$'),'invalid_vmess_json');pos=pos+4 end
                pos=pos+1
            end
        end
        check(false,'invalid_vmess_json')
    end
    spaces();check(raw:sub(pos,pos)=='{','invalid_vmess_json');pos=pos+1;spaces()
    check(raw:sub(pos,pos)~='}','invalid_vmess_json')
    while true do
        local key=quoted();spaces();check(raw:sub(pos,pos)==':','invalid_vmess_json');pos=pos+1;spaces()
        local value
        if raw:sub(pos,pos)=='"' then value=quoted()
        else
            value=raw:sub(pos):match('^%d+');check(value and (#value==1 or value:sub(1,1)~='0'),'invalid_vmess_json');pos=pos+#value
            check(key=='v' or key=='port' or key=='aid','invalid_vmess_json')
        end
        check(out[key]==nil,'duplicate_link_parameter');out[key]=value;spaces()
        local c=raw:sub(pos,pos);pos=pos+1
        if c=='}' then spaces();check(pos>#raw,'invalid_vmess_json');return out end
        check(c==',','invalid_vmess_json');spaces()
    end
end
local function vmess_json(rest)
    local body,name=split_fragment(rest);local p=flat_json(b64(body))
    local allowed=keys('v ps add port id aid scy net type host path tls sni alpn fp insecure serviceName mode authority pcs vcn')
    for key in pairs(p) do check(allowed[key],'unsupported_link_parameter') end
    check((not p.pcs or p.pcs=='') and (not p.vcn or p.vcn==''),'unsupported_link_parameter')
    check(not p.v or p.v=='2','unsupported_vmess_version')
    check(not p.aid or p.aid=='0','unsupported_vmess_legacy')
    check(p.add and p.port and p.id and p.port:match('^%d+$'),'invalid_vmess_json')
    local server=p.add:gsub('^%[([^%]]+)%]$','%1'):lower()
    local n={name=name~='' and name or (p.ps and p.ps~='' and p.ps or server..':'..p.port),protocol='vmess',
        server=server,port=tonumber(p.port),uuid=p.id:lower(),vmess_cipher=p.scy and p.scy~='' and p.scy or 'auto'}
    local q={type=p.net and p.net~='' and p.net or 'tcp',security=p.tls and p.tls~='' and p.tls or 'none'}
    for _,key in ipairs({'sni','alpn','fp','insecure','authority','mode','serviceName'}) do
        if p[key] and p[key]~='' then q[key]=p[key] end
    end
    if q.type=='grpc' then
        if p.path and p.path~='' then check(not q.serviceName,'duplicate_link_parameter');q.serviceName=p.path end
        if p.type and p.type~='' and p.type~='none' then check(not q.mode,'duplicate_link_parameter');q.mode=p.type end
        if p.host and p.host~='' then check(not q.authority,'duplicate_link_parameter');q.authority=p.host end
    elseif q.type=='ws' or q.type=='httpupgrade' then
        if p.path and p.path~='' then q.path=p.path end
        if p.host and p.host~='' then q.host=p.host end
        check(not p.type or p.type=='' or p.type=='none','unsupported_link_parameter')
    else
        check(not p.type or p.type=='' or p.type=='none','unsupported_link_parameter')
        check(not p.host or p.host=='','link_parameter_conflict')
        check(not p.path or p.path=='' or p.path=='/','link_parameter_conflict')
    end
    -- Empty exporter defaults are ignored; explicit incompatible settings are not.
    if q.security=='none' and q.insecure=='0' then q.insecure=nil end
    stream(n,q);return n
end
function M.parse(raw)
    check(type(raw)=='string' and #raw<=4096,'invalid_share_link')
    raw=raw:match('^%s*(.-)%s*$');check(not raw:find('%s'),'invalid_share_link')
    local scheme,rest=raw:match('^([A-Za-z][A-Za-z0-9+.-]*)://(.+)$')
    check(scheme,'invalid_share_link');scheme=scheme:lower()
    if scheme=='vless' then return vless.parse(raw) end
    if scheme=='vmess' and not rest:find('@',1,true) then return vmess_json(rest) end
    if scheme=='vmess' or scheme=='trojan' then
        local allowed=keys(tls_keys..' fp type security path host serviceName mode authority headerType'..(scheme=='vmess' and ' encryption' or ''))
        local n,user,p=uri(rest,scheme,allowed);check(user,'invalid_link_credentials')
        if scheme=='vmess' then n.uuid=decode(user):lower();n.vmess_cipher=p.encryption or 'auto'
        else n.password=decode(user) end
        stream(n,p);return n
    elseif scheme=='ss' then
        local body,name=split_fragment(rest)
        if not body:find('@',1,true) then
            local user,address=clean(b64(body)):match('^(.*)@([^@]+)$')
            check(user and address,'invalid_share_link')
            local method,password=pair(user);local server,port=endpoint(address)
            return {name=name~='' and name or server..':'..port,protocol='shadowsocks',server=server,port=port,
                method=method,password=password,transport='tcp',security='none'}
        end
        local n,user=uri(body,'shadowsocks',{});check(user,'invalid_link_credentials')
        if not user:find(':',1,true) then user=clean(b64(user));n.method,n.password=pair(user)
        else local method,password=pair(user);n.method=decode(method);n.password=decode(password) end
        n.name=name~='' and name or n.name;n.transport='tcp';n.security='none';return n
    elseif scheme=='socks' or scheme=='socks5' or scheme=='http' or scheme=='https' then
        local protocol=(scheme=='socks' or scheme=='socks5') and 'socks5' or 'http'
        local n,user,p=uri(rest,protocol,scheme=='https' and keys(tls_keys) or {})
        n.transport='tcp';n.security=scheme=='https' and 'tls' or 'none'
        if user then
            if protocol=='socks5' and not user:find(':',1,true) then n.username,n.password=pair(clean(b64(user)))
            else local username,password=pair(user);n.username=decode(username);n.password=decode(password) end
        end
        tls(n,p);return n
    elseif scheme=='hy2' or scheme=='hysteria2' then
        local n,user,p=uri(rest,'hysteria2',keys(tls_keys..' obfs obfs-password'),443)
        n.transport='quic';n.security='tls';n.password=user and decode(user) or ''
        check(not p.obfs or p.obfs=='salamander','unsupported_link_parameter')
        check((p.obfs~=nil)==(p['obfs-password']~=nil and p['obfs-password']~=''),'link_parameter_conflict')
        n.obfs_password=p['obfs-password'] or '';tls(n,p);return n
    elseif scheme=='tuic' then
        local n,user,p=uri(rest,'tuic',keys(tls_keys..' congestion_control congestion-controller udp_relay_mode disable_sni'))
        check(user,'invalid_link_credentials');local uuid,password=pair(user)
        n.uuid=decode(uuid):lower();n.password=decode(password);n.transport='quic';n.security='tls'
        n.congestion=alias(p,'congestion_control congestion-controller') or 'cubic'
        n.udp_relay_mode=p.udp_relay_mode or 'native'
        check(not p.disable_sni or p.disable_sni=='0' or p.disable_sni=='false','unsupported_link_parameter')
        tls(n,p);return n
    end
    check(false,'unsupported_link_scheme')
end
return M
