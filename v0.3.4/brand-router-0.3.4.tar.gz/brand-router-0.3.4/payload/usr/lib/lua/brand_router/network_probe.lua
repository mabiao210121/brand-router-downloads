-- Read-only, bounded inventory. Known routes cannot prove an unused physical network.
local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local M={}
local function range(cidr)
    if type(cidr)~='string' then return end
    local ip,prefix=cidr:match('^(%d+%.%d+%.%d+%.%d+)/(%d+)$');prefix=tonumber(prefix)
    if not ip or not prefix or prefix<1 or prefix>32 then return end
    local n=0;for part in ip:gmatch('%d+') do if tonumber(part)>255 then return end;n=n*256+tonumber(part) end
    local size=2^(32-prefix);local first=math.floor(n/size)*size;return first,first+size-1
end
function M.collect(dump,routes,devices)
    local result={available=type(dump)=='table' and type(dump.interface)=='table',interfaces={},networks={},coverage='known_interfaces_and_routes_only'}
    local seen={}
    for name in (devices or ''):gmatch('[^\n]+') do
        if #name<=15 and name:match('^[%w_.-]+$') and name~='lo' then seen[name]={name=name,roles={}} end
    end
    for _,item in ipairs((dump or {}).interface or {}) do
        local name=item.l3_device or item.device
        if type(name)=='string' and #name<=15 and name:match('^[%w_.-]+$') then
            seen[name]=seen[name] or {name=name,roles={}};table.insert(seen[name].roles,item.interface);seen[name].up=item.up==true
            for _,address in ipairs(item['ipv4-address'] or {}) do
                local cidr=tostring(address.address)..'/'..tostring(address.mask)
                if range(cidr) then table.insert(result.networks,{cidr=cidr,interface=name,source='interface'}) end
            end
        end
    end
    for line in (routes or ''):gmatch('[^\n]+') do
        local cidr=line:match('^(%d+%.%d+%.%d+%.%d+/%d+)')
        if cidr and range(cidr) and #result.networks<256 then table.insert(result.networks,{cidr=cidr,interface=line:match(' dev ([%w_.-]+)') or '',source='route'}) end
    end
    for _,item in pairs(seen) do table.insert(result.interfaces,item) end
    table.sort(result.interfaces,function(a,b)return a.name<b.name end)
    return result
end
function M.inspect(context)
    if context.allow_lab_http then return {available=false,interfaces={},networks={},coverage='preview'} end
    local dump=json.parse(util.capture('ubus call network.interface dump 2>/dev/null',65536) or '')
    return M.collect(dump,util.capture('ip -4 route show table all 2>/dev/null',32768),util.capture('for dev in /sys/class/net/*; do [ -f "$dev/ifindex" ] && basename "$dev"; done 2>/dev/null',4096))
end
function M.check(snapshot,input)
    local first,last=range(input.subnet);assert(first,'invalid_subnet')
    local conflicts={}
    for _,known in ipairs(snapshot.networks or {}) do
        local a,b=range(known.cidr)
        if a and first<=b and last>=a then table.insert(conflicts,known) end
    end
    return {available=snapshot.available,conflicts=conflicts,interfaces=snapshot.interfaces,coverage=snapshot.coverage,
        verdict=not snapshot.available and 'unknown' or #conflicts>0 and 'conflict' or 'no_known_overlap'}
end
return M
