local json=require 'luci.jsonc'
local util=require 'brand_router.util'
local license=require 'brand_router.license'
local identity=require 'brand_router.identity'
local resources=require 'brand_router.resources'
local preflight=require 'brand_router.preflight'
local guard=require 'brand_router.guard'
local M={}
M.methods={status={},preflight={},enrollment={},import={code='String'},guard_plan={}}
-- rpcd exec signatures require objects; native JSONC serializes empty Lua tables as [].
M.signature='{"status":{},"preflight":{},"enrollment":{},"import":{"code":"String"},"guard_plan":{}}'
function M.call(method,input,context)
    assert(M.methods[method],'unknown_method')
    input=input or {};assert(type(input)=='table','invalid_request')
    if method=='status' then
        local enforcement=json.parse(util.read('/tmp/brand-router-enforcement.json') or '')
        return {license=license.status(context),resources=resources.inspect(),prototype=true,
            enforcement=enforcement or {state='not_enabled'},enforcement_applied=enforcement and enforcement.enforcement_applied or false}
    end
    if method=='preflight' then return preflight.inspect() end
    if method=='guard_plan' then
        local site=json.parse(util.read(context.site_path or '/etc/brand-router/site.json') or '')
        assert(site,'site_configuration_required')
        return guard.plan(license.status(context),site)
    end
    return util.with_lock(context.lock_dir or '/var/lock/brand-router-state',function()
        if method=='enrollment' then return identity.enrollment(context) end
        assert(type(input.code)=='string' and #input.code<=16384,'invalid_license')
        return license.import(input.code,context)
    end)
end
return M
