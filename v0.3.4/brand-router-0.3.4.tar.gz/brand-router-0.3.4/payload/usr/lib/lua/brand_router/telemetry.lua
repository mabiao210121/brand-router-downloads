-- Bounded, read-only Linux telemetry. No network scans, config writes or client-controlled paths.
local util=require 'brand_router.util'
local fs=require 'nixio.fs'
local M={}
local function clean(s) return s and s:gsub('%z',''):gsub('[%c]',' '):match('^%s*(.-)%s*$'):sub(1,160) or nil end
local function number(s)
    local n=tonumber(s or '')
    if n and n==n and n>=0 and n<2^53 then return n end
end
local function names(path)
    local out={};if not fs.dir then return out end
    local ok,iter=pcall(fs.dir,path);if not ok or not iter then return out end
    for name in iter do
        if #out>=64 then break end
        if name:match('^[%w_.:-]+$') and name~='.' and name~='..' then out[#out+1]=name end
    end
    table.sort(out);return out
end
function M.collect(read,ls,capture,now)
    local function get(path,max) return read(path,max or 4096) end
    local mem=get('/proc/meminfo',65536) or ''
    local function kib(key) local n=number(mem:match('\n'..key..':%s*(%d+)') or mem:match('^'..key..':%s*(%d+)'));return n and n*1024 end
    local memory={total_bytes=kib('MemTotal'),available_bytes=kib('MemAvailable'),swap_total_bytes=kib('SwapTotal'),swap_free_bytes=kib('SwapFree')}
    if memory.total_bytes and memory.available_bytes and memory.available_bytes<=memory.total_bytes then
        memory.used_bytes=memory.total_bytes-memory.available_bytes
    end
    local stat=get('/proc/stat',131072) or ''
    local cpu={};local counters={}
    for value in (stat:match('^cpu%s+([^\n]+)') or ''):gmatch('%d+') do counters[#counters+1]=number(value) end
    if #counters>=4 then
        cpu.total_ticks=0;for i=1,math.min(8,#counters) do cpu.total_ticks=cpu.total_ticks+counters[i] end
        cpu.idle_ticks=counters[4]+(counters[5] or 0)
    end
    local cores=0;for _ in stat:gmatch('\ncpu%d+%s') do cores=cores+1 end
    cpu.logical_cores=cores>0 and cores or nil
    local info=get('/proc/cpuinfo',262144) or ''
    cpu.model=clean(info:match('model name%s*:%s*([^\n]+)') or info:match('Hardware%s*:%s*([^\n]+)') or info:match('Processor%s*:%s*([^\n]+)'))
    local release=get('/etc/openwrt_release',16384) or ''
    local function setting(key) return clean(release:match(key.."='([^'\n]*)'") or release:match(key..'="([^"\n]*)"')) end
    local system={vendor=clean(get('/sys/class/dmi/id/sys_vendor')),model=clean(get('/sys/class/dmi/id/product_name')),
        firmware=setting('DISTRIB_DESCRIPTION'),target=setting('DISTRIB_TARGET'),architecture=setting('DISTRIB_ARCH'),
        kernel=clean(get('/proc/sys/kernel/osrelease')),uptime_seconds=number((get('/proc/uptime') or ''):match('^(%S+)')),
        boot_time=number(stat:match('\nbtime%s+(%d+)'))}
    local a,b,c=(get('/proc/loadavg') or ''):match('^(%S+)%s+(%S+)%s+(%S+)');cpu.load_1=number(a);cpu.load_5=number(b);cpu.load_15=number(c)
    local storage={filesystems={},disks={}}
    -- Constant command only; mounts and devices from requests are never interpolated.
    local df=capture('df -kP / /overlay 2>/dev/null',8192) or ''
    local seen={}
    for line in df:gmatch('[^\n]+') do
        local dev,total,used,avail,mount=line:match('^(%S+)%s+(%d+)%s+(%d+)%s+(%d+)%s+%S+%s+(/%S*)%s*$')
        if total and not seen[mount] and (mount=='/' or mount=='/overlay') then
            seen[mount]=true;storage.filesystems[#storage.filesystems+1]={mount=mount,total_bytes=tonumber(total)*1024,used_bytes=tonumber(used)*1024,available_bytes=tonumber(avail)*1024}
        end
    end
    for _,name in ipairs(ls('/sys/block')) do
        if #storage.disks>=16 then break end
        if name:match('^sd%a+$') or name:match('^vd%a+$') or name:match('^nvme%d+n%d+$') or name:match('^mmcblk%d+$') then
            local base='/sys/block/'..name
            local sectors=number(get(base..'/size'))
            storage.disks[#storage.disks+1]={name=name,model=clean(get(base..'/device/model')),bytes=sectors and sectors*512}
        end
    end
    local interfaces={}
    local net=get('/proc/net/dev',65536)
    for line in (net or ''):gmatch('[^\n]+') do
        local name,values=line:match('^%s*([%w_.-]+):%s*(.+)$')
        if name and name~='lo' and #interfaces<32 then
            local v={};for n in values:gmatch('%d+') do v[#v+1]=number(n) end
            local base='/sys/class/net/'..name
            local carrier=number(get(base..'/carrier'));local speed=number(get(base..'/speed'))
            interfaces[#interfaces+1]={name=name,ifindex=number(get(base..'/ifindex')),state=clean(get(base..'/operstate')),
                carrier=carrier,speed_mbps=speed and speed>0 and speed or nil,rx_bytes=v[1],tx_bytes=v[9],rx_errors=v[3],tx_errors=v[11],
                kind=get(base..'/device/uevent') and 'hardware' or 'logical'}
        end
    end
    local temperatures={}
    for _,name in ipairs(ls('/sys/class/thermal')) do
        if name:match('^thermal_zone%d+$') and #temperatures<16 then
            local base='/sys/class/thermal/'..name;local value=tonumber(get(base..'/temp') or '')
            if value and value>=-40000 and value<=150000 then temperatures[#temperatures+1]={name=clean(get(base..'/type')) or name,celsius=value/1000} end
        end
    end
    local conntrack={count=number(get('/proc/sys/net/netfilter/nf_conntrack_count')),maximum=number(get('/proc/sys/net/netfilter/nf_conntrack_max'))}
    local leases=get('/tmp/dhcp.leases',524288);local count=nil
    if leases then
        count=0;local seen_mac={}
        for line in leases:gmatch('[^\n]+') do
            local expiry,mac=line:match('^(%d+)%s+([%x:]+)%s+')
            if expiry and (tonumber(expiry)==0 or tonumber(expiry)>now) and not seen_mac[mac:lower()] then count=count+1;seen_mac[mac:lower()]=true end
        end
    end
    return {source='device',sampled_at=now,available=system.uptime_seconds~=nil,system=system,cpu=cpu,memory=memory,storage=storage,
        interfaces=interfaces,interfaces_available=net~=nil,temperatures=temperatures,conntrack=conntrack,dhcp_active_leases=count,proxy_runtime_connected=false}
end
function M.inspect(now)
    local ok,result=pcall(M.collect,util.read,names,util.capture,now or os.time())
    if ok then return result end
    return {source='device',available=false,error='telemetry_unavailable'}
end
return M
