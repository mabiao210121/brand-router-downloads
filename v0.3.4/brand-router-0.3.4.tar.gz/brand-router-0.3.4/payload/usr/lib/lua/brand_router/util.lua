local fs = require 'nixio.fs'
local M = {}
function M.private_dir(path,uid)
    uid=uid or require('nixio').getuid()
    local stat=fs.lstat(path)
    if not stat then assert(fs.mkdir(path,'700'),'private_directory_failed');stat=fs.lstat(path) end
    assert(stat and stat.type=='dir' and stat.uid==uid,'private_directory_required')
    assert(fs.chmod(path,'700'))
end
function M.quote(s) return "'" .. tostring(s):gsub("'", "'\\''") .. "'" end
function M.exec(command)
    local a, _, code = os.execute(command)
    if type(a) == 'number' then return a == 0 end
    return a == true and code == 0
end
function M.read(path, maximum)
    local f = io.open(path, 'rb')
    if not f then return nil end
    local s = f:read((maximum or 16384)+1); f:close()
    if not s or #s > (maximum or 16384) then return nil end
    return s
end
function M.random_hex(bytes)
    local f = assert(io.open('/dev/urandom','rb'))
    local raw = assert(f:read(bytes)); f:close()
    assert(#raw == bytes)
    return (raw:gsub('.',function(x) return string.format('%02x',x:byte()) end))
end
function M.tempdir(parent)
    local dir = parent .. '/br-' .. M.random_hex(16)
    assert(fs.mkdir(dir, '700'), 'private_temporary_directory_failed')
    assert(fs.chmod(dir, '700'))
    return dir
end
function M.write(path, data)
    local f = assert(io.open(path, 'wb')); assert(f:write(data)); f:close()
    assert(fs.chmod(path, '600'))
end
function M.atomic(path, data)
    local temp = path .. '.' .. M.random_hex(12)
    local ok,reason=pcall(function()
        M.write(temp, data)
        assert(fs.rename(temp, path),'atomic_write_failed')
    end)
    if not ok then fs.unlink(temp);error(reason,0) end
end
function M.capture(command, maximum)
    local f = io.popen(command, 'r'); if not f then return nil end
    local s = f:read((maximum or 16384)+1); f:close()
    if not s or #s > (maximum or 16384) then return nil end
    return s
end
function M.cleanup(dir, names)
    for _, name in ipairs(names) do fs.unlink(dir .. '/' .. name) end
    fs.rmdir(dir)
end
function M.with_lock(path, callback)
    -- Atomic mkdir works across RPC/CLI processes. A killed process leaves a lock until explicit recovery/reboot.
    if not fs.mkdir(path,'700') then error('state_busy') end
    local ok,result=pcall(callback)
    fs.rmdir(path)
    if not ok then error(result) end
    return result
end
return M
