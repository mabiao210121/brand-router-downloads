local util=require 'brand_router.util'
local M={}
function M.profile(input)
    local memory=input.memory_mib or 0
    if input.memory_limit_mib and input.memory_limit_mib>0 then memory=math.min(memory,input.memory_limit_mib) end
    -- The physical 4GiB J4125 reports 3510MiB after firmware reservations.
    -- Require at least 3.25GiB visible RAM; 3GiB machines/cgroups still fail.
    local tier=memory>=28672 and 32 or memory>=14336 and 16 or memory>=7168 and 8 or memory>=3328 and 4 or 0
    local disk=input.storage_mib or 0
    -- Decimal 16GB drives lose space to partitions/filesystems. Match the installer
    -- against usable overlay capacity, not the label on the physical disk.
    -- Budgets are integration defaults, not yet enforced by a real proxy core.
    return {tier_gb=tier,effective_memory_mib=memory,storage_mib=disk,minimum_supported=tier>=4 and disk>=13500,
        profile_name='lightweight',business_budgets_enforced=false,
        core_budget_mib=math.min(1024,math.floor(memory*0.25)),cache_mib=32,
        diagnostics_workers=1,history_log_limit_mib=64,backup_limit_mib=64,
        memory_headroom_mib=512,disk_headroom_mib=2048,
        device_target=200,capacity_verified=false}
end
function M.inspect()
    local text=util.read('/proc/meminfo',65536) or ''
    local memory=(tonumber(text:match('MemTotal:%s*(%d+)')) or 0)/1024
    local available=(tonumber(text:match('MemAvailable:%s*(%d+)')) or 0)/1024
    local limit=tonumber(util.read('/sys/fs/cgroup/memory.max',128) or '')
    if not limit then limit=tonumber(util.read('/sys/fs/cgroup/memory/memory.limit_in_bytes',128) or '') end
    local fs=require 'nixio.fs'
    local storage_path=fs.stat('/overlay') and '/overlay' or '/'
    local df=util.capture('df -kP '..storage_path..' 2>/dev/null',4096) or ''
    local total,free
    for line in df:gmatch('[^\n]+') do
        local _,blocks,_,avail=line:match('^(%S+)%s+(%d+)%s+(%d+)%s+(%d+)')
        if blocks then total,free=tonumber(blocks)/1024,tonumber(avail)/1024 end
    end
    local profile=M.profile({memory_mib=memory,memory_limit_mib=limit and limit/1048576,storage_mib=total or 0})
    profile.available_memory_mib=available; profile.available_storage_mib=free or 0
    profile.storage_path=storage_path
    return profile
end
return M
