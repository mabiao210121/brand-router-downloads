-- Read-only installed-version report. This is not an update executor.
local json=require 'luci.jsonc'
local util=require 'brand_router.util'
local M={}
function M.collect(read,preview,now)
    local installed={kind=preview and 'development_preview' or 'unpublished_candidate',published=false}
    if not preview then
        local raw=read('/usr/share/brand-router/build.json',4096)
        local ok,meta=pcall(json.parse,raw or '')
        if ok and type(meta)=='table' and meta.schema==1
            and type(meta.version)=='string' and #meta.version<=64 and meta.version:match('^[%w.+_-]+$')
            and type(meta.build_id)=='string' and #meta.build_id==64 and meta.build_id:match('^[0-9a-f]+$') then
            installed.version=meta.version;installed.build_id=meta.build_id
        end
        local release=read('/etc/openwrt_release',16384) or ''
        installed.firmware=release:match("DISTRIB_DESCRIPTION='([^'\n]+)'")
        if installed.firmware then installed.firmware=installed.firmware:gsub('[%c]',' '):sub(1,160) end
    end
    return {state='not_connected',installed=installed,checked_at=now,
        source={configured=false},automatic_updates=false,history_available=false,
        capabilities={check=false,download=false,upload=false,apply=false,recover=false}}
end
function M.inspect(context,now) return M.collect(util.read,context.allow_lab_http,now) end
return M
