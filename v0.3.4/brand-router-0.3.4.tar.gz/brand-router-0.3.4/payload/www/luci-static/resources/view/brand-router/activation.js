'use strict';
'require view';
'require rpc';
'require ui';

var getStatus = rpc.declare({ object: 'brand.router', method: 'status', expect: {} });
var enroll = rpc.declare({ object: 'brand.router', method: 'enrollment', expect: {} });
var activate = rpc.declare({ object: 'brand.router', method: 'import', params: ['code'], expect: {} });
var states = {active:'授权有效', not_initialized:'尚未生成机器码', not_activated:'尚未激活',
    wrong_device:'授权不属于此设备', hardware_changed:'硬件标识发生变化', revoked:'已停用',
    expired_cutoff:'已到期前 30 分钟的停用时间', invalid_signature:'授权签名无效', unknown_key:'签发公钥未配置',
    stale_lease:'旧授权码不能替代新码', clock_rollback:'系统时间回拨', clock_not_synchronized:'系统时间未同步'};
function deadline(n) { return n ? new Date(n * 1000).toLocaleString('zh-CN', {timeZone:'Asia/Shanghai'}) : '—'; }
function error(result) { if (result.error) throw new Error(result.error); return result; }

return view.extend({
    load: function() { return getStatus(); },
    render: function(data) {
        var machine = E('textarea', {'readonly':'readonly', 'rows':4, 'style':'width:100%' });
        var code = E('textarea', {'rows':5, 'placeholder':'粘贴 BRL1. 开头的授权码', 'style':'width:100%' });
        var state = E('p', {}, states[data.license.state] || data.license.state);
        var cutoff = E('p', {}, '实际停用：' + deadline(data.license.stop_at));
        return E('div', {}, [
            E('h2', {}, '品牌软路由 · 设备授权'),
            E('p', {}, '实验应用：设备授权与品牌客户入口已实现。业务监督和隔离仅在管理员完成现场配置并明确启用后生效。'),
            E('p', {}, '业务监督状态：' + (data.enforcement_applied ? '已应用品牌业务策略' : '未启用或未完整应用；需要管理员检查')),
            E('p', {}, '管理员根据机器码签发授权，期限内本地验证，无需每天连接授权服务器。'),
            state, cutoff,
            E('p', {}, '资源档位：' + data.resources.tier_gb + ' GB；200 台终端容量尚未实测。'),
            E('h3', {}, '1. 取得机器码'), machine,
            E('button', {'class':'cbi-button cbi-button-action', 'click': ui.createHandlerFn(this, function() {
                return enroll().then(error).then(function(r) { machine.value = r.machine_code; });
            })}, '生成 / 读取此设备机器码'),
            E('h3', {}, '2. 导入授权或续期'), code,
            E('button', {'class':'cbi-button cbi-button-apply', 'click': ui.createHandlerFn(this, function() {
                if (!code.value.trim() || code.value.length > 16384) throw new Error('授权码不能为空且不得超过 16KB');
                return activate(code.value.trim()).then(error).then(function(r) {
                    state.textContent = states[r.state] || r.state;
                    cutoff.textContent = '实际停用：' + deadline(r.stop_at);
                    ui.addNotification(null, E('p', {}, r.business_allowed ? '此设备验签通过。' : (states[r.state] || r.state)));
                    code.value = '';
                });
            })}, '验证并保存此设备授权')
        ]);
    },
    handleSaveApply: null,
    handleSave: null,
    handleReset: null
});
