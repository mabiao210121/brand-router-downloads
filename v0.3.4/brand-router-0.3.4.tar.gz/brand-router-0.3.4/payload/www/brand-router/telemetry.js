'use strict';
// Pure interval math. No persistent history, timers or network calls.
const BrandTelemetry = {
  percent(used,total){return Number.isFinite(used)&&Number.isFinite(total)&&total>0&&used>=0&&used<=total?100*used/total:null;},
  delta(current,previous){
    const out={cpu:null,rates:{}};
    if(!previous||!Number.isFinite(current.system?.boot_time)||current.source!==previous.source||current.system?.boot_time!==previous.system?.boot_time)return out;
    const elapsed=current.system?.uptime_seconds-previous.system?.uptime_seconds;
    if(!Number.isFinite(elapsed)||elapsed<1||elapsed>120)return out;
    const a=current.cpu||{},b=previous.cpu||{},total=a.total_ticks-b.total_ticks,idle=a.idle_ticks-b.idle_ticks;
    if(total>0&&idle>=0&&idle<=total)out.cpu=100*(total-idle)/total;
    const old=Array.isArray(previous.interfaces)?previous.interfaces:Object.values(previous.interfaces||{});
    for(const row of Object.values(current.interfaces||{})){
      const before=old.find(x=>x.name===row.name&&x.ifindex===row.ifindex);if(!before)continue;
      const rx=row.rx_bytes-before.rx_bytes,tx=row.tx_bytes-before.tx_bytes;
      out.rates[row.name]={rx:Number.isFinite(rx)&&rx>=0?rx/elapsed:null,tx:Number.isFinite(tx)&&tx>=0?tx/elapsed:null};
    }
    return out;
  }
};
if(typeof module!=='undefined')module.exports=BrandTelemetry;
