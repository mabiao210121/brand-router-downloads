-- One global front pool. No direct fallback and no changes to MAC/exit bindings.
local M={}
local function assert(ok,code) if not ok then error({code=code},0) end;return ok end
-- Compatibility is scoped to explicitly imported front nodes, never global TLS defaults.
function M.parse_link(link,parse)
    if not link:lower():match('^trojan://') then return parse(link) end
    assert(#link<=4096,'invalid_share_link')
    local body,fragment=link:match('^([^#]+)(#.*)$');body=body or link;fragment=fragment or ''
    local authority,query=body:match('^([^?]+)%?(.*)$')
    if not query then return parse(link) end
    local decode=require('brand_router.vless').decode
    local params,parts,seen={},{},{};local insecure
    assert(query~='' and not query:find('&&',1,true) and query:sub(1,1)~='&' and query:sub(-1)~='&','invalid_share_link')
    for part in query:gmatch('[^&]+') do
        local key,value=part:match('^([^=]+)=(.*)$');assert(key,'invalid_share_link')
        key=decode(key);value=decode(value);assert(not seen[key],'duplicate_link_parameter');seen[key]=true
        params[key]=value;parts[#parts+1]={key=key,raw=part}
        if key=='allowInsecure' or key=='allow_insecure' or key=='insecure' then
            assert(value=='1' or value=='true' or value=='0' or value=='false','unsupported_link_parameter')
            local flag=value=='1' or value=='true'
            assert(insecure==nil or insecure==flag,'link_parameter_conflict');insecure=flag
        end
    end
    local tcp=not params.type or params.type=='tcp' or params.type=='raw'
    if tcp and params.host then
        assert((not params.headerType or params.headerType=='none') and params.host==(params.sni or params.peer),'link_parameter_conflict')
    end
    local kept={}
    for _,part in ipairs(parts) do
        if part.key~='allowInsecure' and part.key~='allow_insecure' and part.key~='insecure' and not (tcp and part.key=='host') then kept[#kept+1]=part.raw end
    end
    local n=parse(authority..(#kept>0 and '?'..table.concat(kept,'&') or '')..fragment)
    n.front_allow_insecure=insecure==true
    return n
end
function M.validate(pool,validate_node)
    if pool==nil then return end
    assert(type(pool)=='table' and type(pool.enabled)=='boolean','invalid_front_pool')
    assert(pool.strategy=='roundRobin','invalid_front_strategy')
    assert(type(pool.nodes)=='table' and #pool.nodes<=16,'invalid_front_pool')
    local count=0
    for k,n in pairs(pool.nodes) do
        count=count+1;assert(type(k)=='number' and k>=1 and k<=#pool.nodes and k%1==0,'invalid_front_pool')
        assert(n.protocol=='vless' or n.protocol=='vmess' or n.protocol=='trojan' or n.protocol=='shadowsocks','front_protocol_not_supported')
        assert(n.transport=='tcp' or n.transport=='ws' or n.transport=='grpc','front_transport_not_supported')
        assert(n.front_allow_insecure==nil or type(n.front_allow_insecure)=='boolean','invalid_front_pool')
        assert(not n.front_allow_insecure or (n.protocol=='trojan' and n.security=='tls'),'invalid_front_pool')
        if validate_node then
            local standard={};for key,value in pairs(n) do if key~='front_allow_insecure' then standard[key]=value end end
            validate_node(standard,standard)
        end
    end
    assert(count==#pool.nodes and (not pool.enabled or count>0),'front_pool_empty')
end
function M.view(pool)
    pool=pool or {enabled=false,strategy='roundRobin',nodes={}}
    local result={enabled=pool.enabled,strategy=pool.strategy,nodes={}}
    for i,n in ipairs(pool.nodes) do result.nodes[i]={name=n.name,protocol=n.protocol,server=n.server,port=n.port,allow_insecure=n.front_allow_insecure==true} end
    return result
end
local function outbound(n,tag,base)
    if n.protocol=='vless' then return base(n,tag) end
    if n.protocol=='shadowsocks' then
        return {tag=tag,protocol='shadowsocks',settings={servers={{address=n.server,port=n.port,method=n.method,password=n.password}}}}
    end
    local copy={};for k,v in pairs(n) do copy[k]=v end;copy.protocol='vless';copy.uuid='00000000-0000-4000-8000-000000000001';copy.flow=''
    local out=base(copy,tag);out.protocol=n.protocol
    if n.front_allow_insecure then out.streamSettings.tlsSettings.allowInsecure=true end
    if n.protocol=='trojan' then out.settings={servers={{address=n.server,port=n.port,password=n.password}}}
    else out.settings={vnext={{address=n.server,port=n.port,users={{id=n.uuid,security=n.vmess_cipher or 'auto',alterId=0}}}}} end
    return out
end
function M.attach(config,pool,base)
    M.validate(pool)
    if not pool or not pool.enabled then return end
    local used=false
    for _,o in ipairs(config.outbounds) do
        if o.protocol=='socks' then
            used=true;o.streamSettings={sockopt={dialerProxy='front-pool-loop'}}
        end
    end
    if not used then return end
    config.outbounds[#config.outbounds+1]={tag='front-pool-loop',protocol='loopback',settings={inboundTag='front-pool-route'}}
    for i,n in ipairs(pool.nodes) do
        local tag='front-member-'..i
        config.outbounds[#config.outbounds+1]=outbound(n,tag,base)
        config.inbounds[#config.inbounds+1]={tag='front-probe-'..i,listen='127.0.0.1',port=39000+i,protocol='socks',settings={auth='noauth',udp=false}}
        table.insert(config.routing.rules,1,{type='field',inboundTag={'front-probe-'..i},outboundTag=tag})
    end
    table.insert(config.routing.rules,1,{type='field',inboundTag={'front-pool-route'},balancerTag='front-pool'})
    -- Chained SOCKS UDP support varies by provider. Fail closed rather than send outside the chain.
    for i=#config.routing.rules,1,-1 do
        local r=config.routing.rules[i]
        if r.outboundTag then
            for _,o in ipairs(config.outbounds) do if o.tag==r.outboundTag and o.protocol=='socks' then
                table.insert(config.routing.rules,i,{type='field',inboundTag=r.inboundTag,network='udp',outboundTag='blocked'})
                break
            end end
        end
    end
    config.routing.balancers={{tag='front-pool',selector={'front-member-'},fallbackTag='blocked',strategy={type='roundRobin'}}}
    config.observatory={subjectSelector={'front-member-'},probeUrl='https://www.gstatic.com/generate_204',probeInterval='30s',enableConcurrency=true}
end
function M.probe(c,input)
    local u=require 'brand_router.util';local j=require 'luci.jsonc'
    local doc=require('brand_router.business').load(c)
    assert(input.revision==doc.revision,'revision_conflict')
    local state=require('brand_router.fixed_runtime').status(c,doc.revision)
    assert(state.applied and state.state=='active','front_not_active')
    assert(doc.front_mode and doc.front_mode.enabled,'front_not_active')
    local root=c.fixed_root or '/etc/brand-router/fixed'
    local current=j.parse(u.read(root..'/current.json') or '')
    assert(current and type(current.generation)=='string' and current.generation:match('^[a-f0-9]+$') and #current.generation==32,'front_not_active')
    local plan=j.parse(u.read(root..'/'..current.generation..'/plan.json') or '')
    local port
    if input.stage=='front' then
        assert(type(input.index)=='number' and input.index%1==0 and input.index>=1 and input.index<=#doc.front_mode.nodes,'invalid_front_pool')
        port=39000+input.index
    else
        assert(input.stage=='chain' and type(input.node_id)=='string','invalid_front_pool')
        local node=doc.nodes[input.node_id];local n=plan and plan.nodes[input.node_id]
        assert(node and node.protocol=='socks5' and n,'front_node_unbound');port=n.probe_port
    end
    assert(type(port)=='number' and port>=38000 and port<=39016,'invalid_front_pool')
    local output=u.capture("curl --noproxy '' -fsS --connect-timeout 4 --max-time 8 --socks5-hostname 127.0.0.1:"..port.." https://www.cloudflare.com/cdn-cgi/trace 2>/dev/null",8192) or ''
    local ip=output:match('\nip=([%d%.:a-fA-F]+)')
    -- A concurrent save/apply makes the measurement stale; never report it as the new pool.
    assert(require('brand_router.business').load(c).revision==input.revision,'revision_conflict')
    return {stage=input.stage,state=ip and 'reachable' or 'unreachable',exit_ip=ip,checked_at=os.time(),landing_auth=input.stage=='chain' and (ip and 'passed' or 'unconfirmed') or nil}
end
return M
