local M={mark=16980,route_table=18285}
local outbound=require('brand_router.fixed_plan').outbound
local function check(v,e)assert(v,e)end
function M.compile(doc,plan)
 check(plan and not plan.pool_only,'dynamic_network_required')
 plan=require('brand_router.modes').validate('dynamic',plan,doc.nodes)
 check(#plan.interfaces==1,'dynamic_one_interface_required')
 local config={log={loglevel='warning'},inbounds={},outbounds={{tag='blocked',protocol='blackhole',settings={response={type='none'}}}},routing={domainStrategy='AsIs',rules={}}}
 local dns={log={level='error'},inbounds={},outbounds={},dns={servers={},rules={},independent_cache=true},route={rules={}}}
 local nodes={}
 for i,id in ipairs(plan.node_ids) do
  local tag='dynamic-'..i;local port=44000+(i-1)*2;local probe=45000+i-1
  nodes[id]={port=port,dns_port=port+1,probe_port=probe,line=i}
  config.outbounds[#config.outbounds+1]=outbound(doc.nodes[id],tag)
  config.inbounds[#config.inbounds+1]={tag=tag,listen='0.0.0.0',port=port,protocol='dokodemo-door',settings={network='tcp,udp',followRedirect=true},streamSettings={sockopt={tproxy='tproxy'}}}
  config.inbounds[#config.inbounds+1]={tag=tag..'-probe',listen='127.0.0.1',port=probe,protocol='socks',settings={auth='noauth',udp=true,ip='127.0.0.1'}}
  config.routing.rules[#config.routing.rules+1]={type='field',inboundTag={tag,tag..'-probe'},outboundTag=tag}
  dns.inbounds[#dns.inbounds+1]={type='direct',tag=tag,listen='0.0.0.0',listen_port=port+1,udp_timeout='30s'}
  dns.outbounds[#dns.outbounds+1]={type='socks',tag=tag,server='127.0.0.1',server_port=probe,version='5'}
  dns.dns.servers[#dns.dns.servers+1]={type='tcp',tag=tag,server='1.1.1.1',server_port=53,detour=tag}
  dns.dns.rules[#dns.dns.rules+1]={inbound={tag},action='route',server=tag}
  dns.route.rules[#dns.route.rules+1]={inbound={tag},action='hijack-dns'}
 end
 dns.dns.rules[#dns.dns.rules+1]={action='reject'};dns.route.rules[#dns.route.rules+1]={action='reject'}
 return {schema=1,revision=doc.revision,plan=plan,nodes=nodes,config=config,dns_config=dns}
end
function M.firewall(compiled,state,active)
 local p=compiled.plan;local iface=p.interfaces[1]
 check(type(iface)=='string' and iface:match('^[A-Za-z0-9_.-]+$') and #iface<=15,'invalid_business_interface')
 local r={'table inet brand_dynamic {',
 'chain input_guard { type filter hook input priority -22; policy accept;',
 'iifname != "lo" meta mark != 0x4254 meta l4proto { tcp, udp } th dport 44000-45255 drop','}',
 'chain forward_guard { type filter hook forward priority -22; policy accept; iifname "'..iface..'" drop; }',
 'chain prerouting { type filter hook prerouting priority -152; policy accept;',
 'iifname != "'..iface..'" return','meta nfproto ipv6 drop','udp sport 68 udp dport 67 return',
 'fib daddr type local tcp dport { 22, 80, 443, 28283 } return'}
 local ips={};for ip in pairs(state.clients or {}) do
  check(require('brand_router.dynamic_allocator').inside(ip,p.dhcp_start,p.dhcp_end),'invalid_lease_ip');ips[#ips+1]=ip
 end;table.sort(ips)
 if active and p.dynamic_kind=='upstream' then
  local n=compiled.nodes[p.node_ids[1]]
  r[#r+1]='ip saddr '..p.subnet..' meta l4proto { tcp, udp } th dport 53 meta mark set 0x4254 return'
  r[#r+1]='ip daddr { 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 100.64.0.0/10 } drop'
  r[#r+1]='ip saddr '..p.subnet..' meta l4proto { tcp, udp } meta mark set 0x4254 tproxy ip to :'..n.port..' counter accept'
 elseif active then
  for _,ip in ipairs(ips) do local c=state.clients[ip];local n=compiled.nodes[c.node_id]
   if n and not c.missing then
    check(type(c.mac)=='string' and c.mac:match('^%x%x:%x%x:%x%x:%x%x:%x%x:%x%x$'),'invalid_lease_mac')
    local match='ip saddr '..ip..' ether saddr '..c.mac
    r[#r+1]=match..' meta l4proto { tcp, udp } th dport 53 meta mark set 0x4254 return'
    r[#r+1]=match..' ip daddr { 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 100.64.0.0/10 } drop'
    r[#r+1]=match..' meta l4proto { tcp, udp } meta mark set 0x4254 tproxy ip to :'..n.port..' counter accept'
   end
  end
 end
 r[#r+1]='counter drop';r[#r+1]='}'
 if active then
  r[#r+1]='chain dns_redirect { type nat hook prerouting priority -102; policy accept;'
  r[#r+1]='iifname != "'..iface..'" return'
  if p.dynamic_kind=='upstream' then
   r[#r+1]='ip saddr '..p.subnet..' meta l4proto { tcp, udp } th dport 53 redirect to :'..compiled.nodes[p.node_ids[1]].dns_port
  else for _,ip in ipairs(ips) do local c=state.clients[ip];local n=compiled.nodes[c.node_id]
   if n and not c.missing then r[#r+1]='ip saddr '..ip..' ether saddr '..c.mac..' meta l4proto { tcp, udp } th dport 53 redirect to :'..n.dns_port end
  end end;r[#r+1]='}'
 end
 r[#r+1]='}';return table.concat(r,'\n')..'\n'
end
return M
