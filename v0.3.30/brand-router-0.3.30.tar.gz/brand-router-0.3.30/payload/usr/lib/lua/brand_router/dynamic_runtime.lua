-- Applies only to an owner-prepared, isolated business network. Never edits UCI.
local M={}
local u=require'brand_router.util';local j=require'luci.jsonc';local fs=require'nixio.fs'
local compiler=require'brand_router.dynamic_plan';local allocator=require'brand_router.dynamic_allocator'
local function root(c)return c.dynamic_root or '/etc/brand-router/dynamic'end
local function read(p)return j.parse(u.read(p,2097152) or '')end
local function lock(c,f)return u.with_lock(c.dynamic_lock or '/var/lock/brand-dynamic',f)end
local function config(c)
 local path=root(c)..'/current.json';local raw=u.read(path,2097152)
 if not raw then assert(not fs.lstat(path),'dynamic_state_invalid');return end
 local p=assert(j.parse(raw),'dynamic_state_invalid');assert(type(p)=='table','dynamic_state_invalid')
 assert(type(p.generation)=='string' and #p.generation==32 and p.generation:match('^%x+$'),'dynamic_state_invalid')
 local dir=root(c)..'/'..p.generation;local v=assert(read(dir..'/compiled.json'),'dynamic_state_invalid');return v,dir,p
end
local function allowed(c)
 local l=require('brand_router.license').status(c)
 if l.business_allowed then for _,f in ipairs(l.features or {})do if f=='dynamic' then return true end end end
 return false
end
local cached
local function firewall(c,v,s,active)
 local text=compiler.firewall(v,s,active);local exists=u.exec('nft list table inet brand_dynamic >/dev/null 2>&1')
 if exists and text==cached then return end
 local file=root(c)..'/rules.nft';u.atomic(file,(exists and 'delete table inet brand_dynamic\n' or '')..text)
 assert(u.exec('nft -c -f '..u.quote(file)..' >/dev/null 2>&1'),'dynamic_firewall_invalid')
 assert(u.exec('nft -f '..u.quote(file)..' >/dev/null 2>&1'),'dynamic_firewall_failed');cached=text
end
local function routes()
 local rules=u.capture('ip -4 rule show',32768) or '';local found=false
 for l in rules:gmatch('[^\n]+')do if l:match('^18285:')then assert(l:find('fwmark 0x4254',1,true)and l:find('lookup 18285',1,true),'dynamic_route_conflict');found=true end end
 local r=u.capture('ip -4 route show table 18285 2>/dev/null',16384)or''
 assert(r=='' or r:match('^local default dev lo')or r:match('^local 0.0.0.0/0 dev lo'),'dynamic_route_conflict')
 if r==''then assert(u.exec('ip -4 route replace local 0.0.0.0/0 dev lo table 18285'),'dynamic_route_failed')end
 if not found then assert(u.exec('ip -4 rule add fwmark 0x4254 lookup 18285 priority 18285'),'dynamic_route_failed')end
end
local function healthy(dir)
 local services=j.parse(u.capture("ubus -t 1 call service list '{\"name\":\"brand-dynamic\"}'",65536)or'')
 local ins=services and services['brand-dynamic']and services['brand-dynamic'].instances
 for _,name in ipairs({'core','dns'})do local v=ins and ins[name]
  if not v or not v.running or not v.command or v.command[1]~=(name=='core'and'/usr/bin/xray'or'/usr/bin/sing-box')or v.command[4]~=dir..(name=='core'and'/xray.json'or'/dns.json')then return false end
 end;return true
end
function M.network(c)
 local n=read(c.dynamic_network or '/etc/brand-router/dynamic-network.json')
 if not n then return end
 assert(n.schema==1 and n.isolated==true and type(n.interface)=='string' and n.interface:match('^[%w_.-]+$') and #n.interface<=15,'dynamic_network_invalid')
 return n
end
local function verify_network(c,p)
 local n=assert(M.network(c),'dynamic_network_required')
 assert(#p.interfaces==1 and p.interfaces[1]==n.interface and p.subnet==n.subnet and p.gateway==n.gateway and p.dhcp_start==n.dhcp_start and p.dhcp_end==n.dhcp_end,'dynamic_network_changed')
 local iface=n.interface;local info=j.parse(u.capture('ip -j -4 addr show dev '..u.quote(iface),65536)or'')
 local matched=false;for _,v in ipairs(info or{})do for _,a in ipairs(v.addr_info or{})do if a['local']==p.gateway and a.prefixlen==tonumber(p.subnet:match('/(%d+)$'))then matched=true end end end
 assert(matched,'dynamic_network_changed')
 local defaults=u.capture('ip -4 route show default',16384)or''
 for dev in defaults:gmatch('dev%s+(%S+)')do assert(dev~=iface,'dynamic_management_interface')end
 local portal=read('/etc/brand-router/portal.json')or{}
 assert(not tostring(portal.listen):match('^'..p.gateway:gsub('%.','%%.')..':'),'dynamic_management_interface')
 -- An installer explicitly prepares a reject-forward zone. Do not assume a
 -- saved plan can safely take over an arbitrary port or bridged upstream.
 local fw=j.parse(u.capture('ubus call uci get '..u.quote(j.stringify({config='firewall'})),131072)or'')
 local z=fw and fw.values and fw.values[n.zone or 'brand_dynamic']
 assert(z and z['.type']=='zone' and z.forward=='REJECT' and z.input=='ACCEPT','dynamic_network_firewall_changed')
 local nets=type(z.network)=='table'and z.network or{z.network};assert(#nets==1 and nets[1]=='brand_dynamic','dynamic_network_firewall_changed')
 for _,v in pairs(fw.values)do
  if v['.type']=='forwarding' then assert(v.src~=z.name,'dynamic_network_forwarding_present')end
  if v['.type']=='defaults'then assert(v.flow_offloading~='1'and v.flow_offloading_hw~='1','dynamic_offload_not_supported')end
 end
 return n
end
function M.path(c,dns)local v,dir=config(c);assert(v,'dynamic_not_applied');return dir..(dns and'/dns.json'or'/xray.json')end
function M.guard(c)local v=config(c);if v then firewall(c,v,{clients={}},false)end end
function M.enabled(c)return fs.lstat(root(c)..'/current.json')~=nil end
function M.apply(c,revision)
 assert(not c.allow_lab_http,'preview_only')
 assert(not require('brand_router.network_repair').pending(c),'network_repair_busy')
 return u.with_lock(c.state_dir..'/business-lock',function()return lock(c,function()
  assert(allowed(c),'dynamic_authorization_required');u.private_dir(root(c),c.private_uid)
  local doc=require('brand_router.business').load(c);assert(doc.revision==revision,'revision_conflict')
  local p=assert(doc.mode_plans and doc.mode_plans.dynamic,'dynamic_plan_required')
  local v=compiler.compile(doc,p);verify_network(c,v.plan)
  assert(u.exec('command -v conntrack >/dev/null'),'dynamic_conntrack_required')
  local old,old_dir,previous=config(c)
  if old then assert(old.plan.interfaces[1]==p.interfaces[1] and old.plan.subnet==p.subnet,'dynamic_network_migration_required')end
  local g=u.random_hex(16);local dir=root(c)..'/'..g;u.private_dir(dir,c.private_uid)
  u.atomic(dir..'/compiled.json',j.stringify(v));u.atomic(dir..'/xray.json',j.stringify(v.config));u.atomic(dir..'/dns.json',j.stringify(v.dns_config))
  assert(u.exec('xray run -test -c '..u.quote(dir..'/xray.json')..' >'..u.quote(root(c)..'/core-check.log')..' 2>&1'),'dynamic_core_check_failed')
  assert(u.exec('sing-box check -c '..u.quote(dir..'/dns.json')..' >'..u.quote(root(c)..'/dns-check.log')..' 2>&1'),'dynamic_dns_check_failed')
  -- Keep state within its generation; changing policy is explicit and restarts
  -- sessions, while daemon restarts retain the generation's assignments.
  firewall(c,v,{clients={}},false);routes()
  assert(u.exec('conntrack -D -s '..u.quote(p.subnet)..' >/dev/null 2>&1; result=$?; [ "$result" -le 1 ]'),'dynamic_conntrack_failed')
  u.atomic(root(c)..'/current.json',j.stringify({generation=g,revision=revision}))
  local ok=u.exec('/etc/init.d/brand-dynamic restart >/dev/null 2>&1')
  if ok then ok=false;for i=1,10 do if healthy(dir)then ok=true;break end;require('nixio').nanosleep(1)end end
  if not ok then
   u.exec('/etc/init.d/brand-dynamic stop >/dev/null 2>&1')
   if previous then u.atomic(root(c)..'/current.json',j.stringify(previous));u.exec('/etc/init.d/brand-dynamic restart >/dev/null 2>&1')
   else os.remove(root(c)..'/current.json')end
   os.remove(c.dynamic_status or '/tmp/brand-dynamic-status.json');error('dynamic_start_failed')
  end
  assert(u.exec('/etc/init.d/brand-dynamic enable'),'dynamic_enable_failed')
  return{accepted=true,revision=revision,state='starting'}
 end)end)
end
function M.stop(c)
 assert(not c.allow_lab_http,'preview_only')
 return lock(c,function()
  M.guard(c)
  assert(u.exec('/etc/init.d/brand-dynamic stop >/dev/null 2>&1'),'dynamic_stop_failed')
  assert(u.exec('/etc/init.d/brand-dynamic disable'),'dynamic_stop_failed')
  local pointer=u.read(root(c)..'/current.json',4096)
  if pointer then u.atomic(root(c)..'/stopped.json',pointer);assert(os.remove(root(c)..'/current.json'),'dynamic_stop_failed')end
  os.remove(c.dynamic_status or '/tmp/brand-dynamic-status.json')
  return{applied=false,state='stopped'}
 end)
end
local function flush(ip)
 assert(u.exec('command -v conntrack >/dev/null'),'dynamic_conntrack_required')
 assert(u.exec('conntrack -D -s '..u.quote(ip)..' >/dev/null 2>&1; result=$?; [ "$result" -le 1 ]'),'dynamic_conntrack_failed')
end
function M.tick(c)
 return lock(c,function()
  local v,dir=config(c);if not v then return end
  local ok=allowed(c)and healthy(dir);if ok then ok=pcall(function()verify_network(c,v.plan);routes()end)end
  local s={clients={}}
  if v.plan.dynamic_kind=='session_pool'then
   local f=dir..'/assignments.json';local raw=u.read(f,2097152)
   if not raw and fs.lstat(f)then error('dynamic_state_invalid')end
   s=raw and assert(j.parse(raw),'dynamic_state_invalid')or nil
   local h=assert(io.open(c.lease_file or '/tmp/dhcp.leases','rb'),'dynamic_leases_unavailable');local text=h:read(1048577)or'';h:close();assert(#text<=1048576,'dynamic_leases_invalid')
   local leases={};for l in text:gmatch('[^\n]+')do local exp,mac,ip=l:match('^(%d+)%s+(%S+)%s+(%S+)');assert(exp,'dynamic_leases_invalid');leases[#leases+1]={expires=tonumber(exp),mac=mac,ip=ip}end
   local previous={};for ip,x in pairs(s and s.clients or {})do previous[ip]=x.node_id end
   local changed;s,changed=allocator.reconcile(s,leases,v.plan,os.time())
   if changed then
    local moves={};for ip,id in pairs(previous)do if not s.clients[ip] or s.clients[ip].node_id~=id then moves[#moves+1]=ip end end
    if #moves>0 then firewall(c,v,{clients={}},false);for _,ip in ipairs(moves)do flush(ip)end end
    u.atomic(f,j.stringify(s))
   end
  end
  firewall(c,v,s,ok)
  local clients={};for ip,x in pairs(s.clients)do local n=v.nodes[x.node_id];clients[#clients+1]={ip=ip,line=n and n.line or nil,until_at=x.until_at,state=ok and n and not x.missing and'assigned'or'blocked'}end
  table.sort(clients,function(a,b)return a.ip<b.ip end)
  local result={state=ok and'active'or'blocked',applied=ok,revision=v.revision,kind=v.plan.dynamic_kind,node_count=#v.plan.node_ids,clients=clients,observed_at=os.time(),traffic_verified=false}
  u.atomic(c.dynamic_status or '/tmp/brand-dynamic-status.json',j.stringify(result));return result
 end)
end
function M.status(c,revision)
 local v=read(c.dynamic_status or '/tmp/brand-dynamic-status.json')
 if not v or os.time()-(v.observed_at or 0)>5 then v={applied=false,state='not_connected'}end
 if revision and v.revision and v.revision~=revision then v.applied=false;v.state='pending'end
 v.network=M.network(c);v.network_ready=v.network~=nil;return v
end
return M
