-- Persistent per-device sessions. DHCP renewal never extends the session timer.
local M={}
local function number(ip)
 if type(ip)~='string' or not ip:match('^%d+%.%d+%.%d+%.%d+$') then return end
 local n=0;for v in ip:gmatch('%d+') do if tonumber(v)>255 or (#v>1 and v:sub(1,1)=='0')then return end;n=n*256+tonumber(v) end;return n
end
function M.inside(ip,a,b)local n,x,y=number(ip),number(a),number(b);return n and x and y and n>=x and n<=y or false end
function M.reconcile(s,leases,p,now)
 assert(type(now)=='number' and now>=0,'dynamic_clock_invalid')
 s=s or {schema=1,next_index=1,sequence=0,clients={},last_time=now}
 assert(s.schema==1 and type(s.clients)=='table' and type(s.next_index)=='number' and s.next_index>=1 and s.next_index%1==0 and type(s.sequence)=='number' and s.sequence>=0,'dynamic_state_invalid')
 assert(not s.last_time or now>=s.last_time,'dynamic_clock_rollback')
 local pool=p.node_ids;assert(#pool>0,'pool_nodes_required');local active,macs={},{}
 for _,l in ipairs(leases) do
  if M.inside(l.ip,p.dhcp_start,p.dhcp_end) and (l.expires==0 or l.expires>now) then
   assert(type(l.mac)=='string' and l.mac:match('^%x%x:%x%x:%x%x:%x%x:%x%x:%x%x$'),'invalid_lease_mac')
   l.mac=l.mac:lower();assert(not active[l.ip] and not macs[l.mac],'duplicate_dynamic_lease');active[l.ip]=l;macs[l.mac]=true
  end
 end
 local changed=false;local count=0
 for ip,c in pairs(s.clients) do
  assert(type(c)=='table' and type(c.mac)=='string' and type(c.node_id)=='string' and type(c.expires)=='number' and type(c.until_at)=='number' and type(c.sequence)=='number','dynamic_state_invalid')
  local l=active[ip]
  if (l and l.mac~=c.mac) or (not l and c.expires~=0 and c.expires<=now) then s.clients[ip]=nil;changed=true
  else
   count=count+1
   local missing=not l or nil;if c.missing~=missing then c.missing=missing;changed=true end
   if l and c.expires~=l.expires then c.expires=l.expires;changed=true end
   -- Do not silently switch removed nodes; an explicit apply resets pool policy.
   if l and now>=c.until_at then
    local index;for i,id in ipairs(pool)do if id==c.node_id then index=i;break end end
    if index then c.node_id=pool[index%#pool+1];c.until_at=now+p.session_seconds;c.started_at=now;s.sequence=s.sequence+1;c.sequence=s.sequence;changed=true end
   end
  end
 end
 local pending={};for ip,l in pairs(active)do if not s.clients[ip] then pending[#pending+1]=l end end
 table.sort(pending,function(a,b)return number(a.ip)<number(b.ip)end)
 for _,l in ipairs(pending)do
  if count<p.max_sessions then
   local i=(s.next_index-1)%#pool+1;s.sequence=s.sequence+1
   s.clients[l.ip]={mac=l.mac,node_id=pool[i],expires=l.expires,started_at=now,until_at=now+p.session_seconds,sequence=s.sequence}
   s.next_index=i%#pool+1;count=count+1;changed=true
  end
 end
 if changed then s.last_time=now end
 return s,changed
end
return M
