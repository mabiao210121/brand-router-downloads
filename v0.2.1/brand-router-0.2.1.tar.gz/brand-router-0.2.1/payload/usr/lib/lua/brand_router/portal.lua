-- Customer API. Every protected request rechecks the license and a dedicated rpcd role.
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local util=require 'brand_router.util'
local license=require 'brand_router.license'
local identity=require 'brand_router.identity'
local resources=require 'brand_router.resources'
local telemetry=require 'brand_router.telemetry'
local updates=require 'brand_router.updates'
local updater=require 'brand_router.updater'
local network_probe=require 'brand_router.network_probe'
local business=require 'brand_router.business'
local account=require 'brand_router.panel_account'
local M={}
local function response(code,body,headers)
    return {status=code,body=body,headers=headers or {}}
end
local function error_response(code,name) return response(code,{error=name}) end
local function hex(value,length) return type(value)=='string' and #value==length and not value:find('[^0-9a-f]') end
local function private_dir(path,uid)
    local stat=fs.lstat(path)
    if not stat then assert(fs.mkdir(path,'700'),'private_directory_failed');stat=fs.lstat(path) end
    assert(stat and stat.type=='dir' and stat.uid==uid and stat.modedec==700,'private_directory_required')
end
local function public_status(status)
    return {state=status.state,business_allowed=status.business_allowed,customer_login_allowed=status.customer_login_allowed,
        expires_at=status.expires_at,stop_at=status.stop_at,recovery_allowed=true,features=status.features}
end
function M.create(context,config,backend)
    assert(type(config)=='table' and type(config.origin)=='string','portal_configuration_required')
    local scheme,authority=config.origin:match('^(https?)://([^/]+)$')
    assert(scheme and not authority:find('[%s@#?]'),'invalid_portal_origin')
    if scheme~='https' then
        assert(context.allow_lab_http==true and authority:match('^127%.0%.0%.1:%d+$'),'https_required')
    end
    assert(type(config.customer_username)=='string' and config.customer_username~='root' and
        #config.customer_username>=1 and #config.customer_username<=48 and not config.customer_username:find('[^A-Za-z0-9_.-]'),'dedicated_customer_account_required')
    local name=config.brand_name or '品牌软路由'
    assert(type(name)=='string' and #name<=120,'invalid_brand_name')
    local ram=context.portal_state_dir or '/tmp/brand-router-portal'
    private_dir(ram,context.private_uid or 0)
    private_dir(ram..'/sessions',context.private_uid or 0)
    -- Cookies are host-scoped, not port-scoped. Isolate disposable HTTP
    -- previews so logging into a QA port cannot replace the user's session.
    local cookie_name=scheme=='https' and '__Host-brand_sid' or ('brand_sid_'..authority:match(':(%d+)$'))
    local secure=scheme=='https' and '; Secure' or ''
    local function cookie(token,max_age)
        return cookie_name..'='..token..'; Path=/; HttpOnly; SameSite=Strict; Max-Age='..max_age..secure
    end
    local function token(request)
        local found
        for key,value in (request.headers.cookie or ''):gmatch('([^;=]+)=([^;]*)') do
            if key:match('^%s*(.-)%s*$')==cookie_name then
                if found or not hex(value,64) then return nil end
                found=value
            end
        end
        return found
    end
    local function destroy(value)
        if not hex(value,64) then return end
        local session=json.parse(util.read(ram..'/sessions/'..value..'.json') or '')
        if session and session.auth~='local' and hex(session.rpcd_sid,32) then pcall(backend.destroy,session.rpcd_sid) end
        fs.unlink(ram..'/sessions/'..value..'.json')
    end
    local function throttle(request,kind,limit,now)
        local address=request.remote_addr or ''
        if #address>64 or address:find('[^0-9a-fA-F:.]') or #address==0 then return false end
        return util.with_lock(ram..'/rate-lock',function()
            local path=ram..'/rates.json'
            local slots=json.parse(util.read(path) or '') or {}
            local count=0
            for key,slot in pairs(slots) do
                if type(slot)~='table' or type(slot.started)~='number' or now>=slot.started+60 or now<slot.started then slots[key]=nil
                else count=count+1 end
            end
            local key=kind..':'..address
            if not slots[key] and count>=128 then return false end
            local state=slots[key] or {started=now,count=0}
            state.count=state.count+1;slots[key]=state;util.atomic(path,json.stringify(slots))
            return state.count<=limit
        end)
    end
    local function authorized(request,now)
        local value=token(request)
        if not value then return nil end
        local session=json.parse(util.read(ram..'/sessions/'..value..'.json') or '')
        if not session or not hex(session.rpcd_sid,32) or session.username~=(session.auth=='local' and 'root' or config.customer_username) or
            type(session.expires_at)~='number' or type(session.created_at)~='number' or now>=session.expires_at or now<session.created_at-120 then
            destroy(value);return nil
        end
        local a=account.read(context)
        if session.auth=='local' then
            if not a or session.generation~=a.generation then destroy(value);return nil end
        elseif a or not backend.access(session.rpcd_sid) then destroy(value);return nil end
        return session,value
    end
    local api={}
    function api.handle(request,now)
        now=now or os.time()
        request.headers=request.headers or {}
        local method,path=request.method,request.path
        if request.headers.host~=authority then return error_response(400,'invalid_host') end
        if method~='GET' and method~='POST' then return error_response(405,'method_not_allowed') end
        local allowed={['/api/state']=true,['/api/enrollment']=true,['/api/activate']=true,['/api/login']=true,
            ['/api/dashboard']=true,['/api/logout']=true,['/api/config']=true,['/api/config/change']=true,['/api/config/preview']=true,['/api/update/status']=true,['/api/update/action']=true,['/api/device/status']=true,['/api/network/status']=true,['/api/network/check']=true,['/api/account']=true,['/api/account/change']=true,['/api/account/recover']=true}
        if not allowed[path] then return error_response(404,'not_found') end
        local mutating=path=='/api/account/change' or path=='/api/account/recover' or path=='/api/network/check' or path=='/api/update/action' or path=='/api/activate' or path=='/api/login' or path=='/api/logout' or path=='/api/config/change' or path=='/api/config/preview'
        if mutating~=(method=='POST') then return error_response(405,'method_not_allowed') end
        local input={}
        if method=='POST' then
            if request.headers.origin~=config.origin then return error_response(403,'origin_required') end
            local content_type=(request.headers['content-type'] or ''):match('^%s*([^;]+)')
            if content_type~='application/json' then return error_response(415,'json_required') end
            local maximum=path=='/api/update/action' and 3000000 or (path=='/api/config/preview' or path=='/api/config/change') and 131072 or 16384
            if type(request.body)~='string' or #request.body>maximum then return error_response(413,'document_too_large') end
            input=json.parse(request.body)
            if type(input)~='table' then return error_response(400,'invalid_json') end
            if #request.body>16384 and path=='/api/config/change' and input.action~='save_rows' and input.action~='save_mode' then return error_response(413,'document_too_large') end
        end
        local status=license.status(context,context.test_epoch and now or nil)
        if path=='/api/state' then
            return response(200,{brand_name=name,license=public_status(status),customer_account_configured=true,account=account.public(context,config)})
        end
        if path=='/api/enrollment' then
            if not throttle(request,'enrollment',5,now) then return error_response(429,'rate_limited') end
            return response(200,util.with_lock(context.lock_dir or '/var/lock/brand-router-state',function()
                return identity.enrollment(context)
            end))
        end
        if path=='/api/activate' then
            if not throttle(request,'activate',10,now) then return error_response(429,'rate_limited') end
            if type(input.code)~='string' then return error_response(400,'invalid_license') end
            local result=util.with_lock(context.lock_dir or '/var/lock/brand-router-state',function()
                return license.import(input.code,context,context.test_epoch and now or nil)
            end)
            return response(result.state=='active' and 200 or 422,{license=public_status(result)})
        end
        if path=='/api/logout' then
            local session,value=authorized(request,now)
            if not session then return error_response(401,'login_required') end
            if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            destroy(value);return response(200,{ok=true},{['Set-Cookie']=cookie('',0)})
        end
        if path=='/api/account/recover' then
            if not throttle(request,'recovery',5,now) then return error_response(429,'rate_limited') end
            local ok,result=pcall(account.recover,context,input)
            if not ok then return error_response(422,type(result)=='table' and result.code or 'account_unavailable') end
            destroy(token(request));return response(200,result,{['Set-Cookie']=cookie('',0)})
        end
        -- This gate applies on every request, including a cookie issued before cutoff.
        if not status.customer_login_allowed then
            destroy(token(request));return response(423,{error='authorization_required',license=public_status(status)},
                {['Set-Cookie']=cookie('',0)})
        end
        if path=='/api/login' then
            if not throttle(request,'login',10,now) then return error_response(429,'rate_limited') end
            local a=account.read(context)
            if input.username~=(a and a.username or config.customer_username) or type(input.password)~='string' or #input.password>1024 then
                return error_response(401,'login_failed')
            end
            local rpcd_sid
            if a then
                if not account.verify(context,a,input.password) then return error_response(401,'login_failed') end
                rpcd_sid=util.random_hex(16)
            else
                rpcd_sid=backend.login(input.username,input.password)
                if not hex(rpcd_sid,32) then return error_response(401,'login_failed') end
                if not backend.access(rpcd_sid) then backend.destroy(rpcd_sid);return error_response(403,'customer_role_required') end
            end
            -- A fresh portal cookie never gives the browser an rpcd/LuCI admin token.
            destroy(token(request))
            local value,csrf=util.random_hex(32),util.random_hex(32)
            local created=util.with_lock(ram..'/session-lock',function()
                local index=json.parse(util.read(ram..'/sessions/index.json') or '') or {}
                local count=0
                for sid,expires in pairs(index) do
                    if type(expires)~='number' or now>=expires or not util.read(ram..'/sessions/'..sid..'.json') then
                        destroy(sid);index[sid]=nil
                    else count=count+1 end
                end
                if count>=64 then return false end
                util.atomic(ram..'/sessions/'..value..'.json',json.stringify({rpcd_sid=rpcd_sid,username=input.username,
                    csrf=csrf,created_at=now,expires_at=now+3600,auth=a and 'local' or nil,generation=a and a.generation or nil}))
                index[value]=now+3600;util.atomic(ram..'/sessions/index.json',json.stringify(index))
                return true
            end)
            if not created then if not a then backend.destroy(rpcd_sid) end;return error_response(503,'session_capacity') end
            return response(200,{username=input.username,csrf=csrf},{['Set-Cookie']=cookie(value,3600)})
        end
        local session=authorized(request,now)
        if not session then return error_response(401,'login_required') end
        if path=='/api/account' or path=='/api/account/change' then
            if not mutating then return response(200,account.public(context,config)) end
            if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            if not throttle(request,'account-change',5,now) then return error_response(429,'rate_limited') end
            local ok,result=pcall(account.change,context,input,function(value)
                if type(value)~='string' or #value>1024 then return false end
                local sid=backend.login(config.customer_username,value)
                if not hex(sid,32) then return false end
                local valid=backend.access(sid);backend.destroy(sid);return valid
            end,session.generation or 'legacy')
            if not ok then return error_response(422,type(result)=='table' and result.code or 'account_unavailable') end
            destroy(token(request));return response(200,result,{['Set-Cookie']=cookie('',0)})
        end
        if account.public(context,config).first_setup and path~='/api/dashboard' then return error_response(409,'initial_setup_required') end
        if path=='/api/device/status' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if not throttle(request,'telemetry',30,now) then return error_response(429,'rate_limited') end
            return response(200,telemetry.inspect(now))
        end
        if path=='/api/network/status' or path=='/api/network/check' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating and request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            if not throttle(request,'network-read',20,now) then return error_response(429,'rate_limited') end
            local snapshot=network_probe.inspect(context)
            if not mutating then return response(200,snapshot) end
            local ok,result=pcall(network_probe.check,snapshot,input)
            return ok and response(200,result) or error_response(422,'invalid_subnet')
        end
        if path=='/api/update/status' or path=='/api/update/action' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating then
                if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
                if not throttle(request,'updates',12,now) then return error_response(429,'rate_limited') end
                local ok,result=pcall(updater.request,context,input,now,function(id)
                    return util.exec('/sbin/start-stop-daemon -S -b -m -p '..util.quote(updater.root(context)..'/worker.pid')..' -x /usr/bin/lua -- /usr/libexec/brand-update-worker '..util.quote(id)..' >/dev/null 2>&1')
                end)
                if not ok then return error_response(409,type(result)=='table' and result.code or 'update_failed') end
                return response(200,result)
            end
            local result=updates.inspect(context,now);result.manager=updater.status(context)
            if result.manager.enabled then
                result.state='ready';result.source={configured=true};result.history_available=true
                local idle=not (result.manager.job and result.manager.job.busy)
                result.capabilities={check=idle,download=idle and result.manager.availability=='available',upload=idle and result.manager.availability=='available',apply=idle and result.manager.staged~=nil,recover=idle and result.manager.recoverable}
            end
            return response(200,result)
        end
        if path=='/api/config' or path=='/api/config/change' or path=='/api/config/preview' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating then
                if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
                if not throttle(request,path=='/api/config/preview' and 'preview' or 'configuration',path=='/api/config/preview' and 90 or 30,now) then return error_response(429,'rate_limited') end
            end
            local ok,result=pcall(function()
                if path=='/api/config/preview' then return business.preview(input) end
                if mutating then return business.change(context,input,now) end
                return business.get(context)
            end)
            if not ok then
                local code=type(result)=='table' and result.code or 'configuration_unavailable'
                return response(code=='revision_conflict' and 409 or code=='configuration_unavailable' and 503 or 422,{error=code,row=type(result)=='table' and result.row or nil})
            end
            return response(200,result)
        end
        return response(200,{brand_name=name,username=session.username,csrf=session.csrf,account=account.public(context,config),license=public_status(status),
            resources=resources.inspect(),modules={fixed={enabled=false,stage='configuration_pending'},
                rotation={enabled=false,stage='configuration_pending'},dynamic={enabled=false,stage='configuration_pending'}}})
    end
    return api
end
function M.listen(config,site)
    assert(type(config)=='table' and config.enabled==true,'portal_not_enabled')
    assert(type(config.origin)=='string' and config.origin:match('^https://[^/%s@#?]+$'),'https_required')
    assert(type(config.customer_username)=='string' and config.customer_username~='root' and
        #config.customer_username>=1 and #config.customer_username<=48 and not config.customer_username:find('[^A-Za-z0-9_.-]'),'dedicated_customer_account_required')
    local ip,port=tostring(config.listen):match('^([%d.]+):(%d+)$')
    assert(ip and port,'ipv4_listen_required')
    local parts=0
    for part in ip:gmatch('[^.]+') do assert(tonumber(part) and tonumber(part)<=255,'invalid_listen_address');parts=parts+1 end
    assert(parts==4 and ip:match('^%d+%.%d+%.%d+%.%d+$') and ip~='0.0.0.0','specific_listen_address_required')
    port=tonumber(port)
    assert(port>=1024 and port<=65535 and site and site.brand_port==port,'portal_port_must_match_guard')
    assert(tonumber(config.origin:match(':(%d+)$'))==port,'portal_origin_port_mismatch')
    return config.listen
end
return M
