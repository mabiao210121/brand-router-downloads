-- Explicit DHCP-only changes; never renumber LAN or scan clients.
local util=require 'brand_router.util'
local M={}
function M.plan(v)
    local p={supported=false,message='此网络需要管理员配置，未修改网络。'}
    if not v.simple or v.mask~='255.255.255.0' then return p end
    local prefix,host=(v.ip or ''):match('^(%d+%.%d+%.%d+%.)(%d+)$')
    local start,limit=tonumber(v.start),tonumber(v.limit)
    if not prefix or not start or not limit or start%1~=0 or limit%1~=0 or start<1 or limit<1 or start+limit-1>254 then return p end
    host=tonumber(host);if host>=start and host<start+limit then return p end
    local n,unit=(v.leasetime or ''):match('^(%d+)([mhd])$');n=tonumber(n)
    local minutes=n and n*({m=1,h=60,d=1440})[unit] or nil
    if not minutes then return p end
    local last=start+limit-1;local maximum=host>=start and host-1 or 254
    local used=0;local seen={}
    for line in (v.leases or ''):gmatch('[^\n]+') do
        local expiry,ip=line:match('^(%d+)%s+[%x:]+%s+(%d+%.%d+%.%d+%.%d+)%s')
        local tail=ip and ip:sub(1,#prefix)==prefix and tonumber(ip:sub(#prefix+1))
        if tail and tail>=start and tail<=last and (tonumber(expiry)==0 or tonumber(expiry)>v.now) and not seen[ip] then used=used+1;seen[ip]=true end
    end
    return {supported=true,minutes=minutes,subnet=prefix..'0/24',start=prefix..start,finish=prefix..last,total=limit,used=used,remaining=limit-used,
        expandable=maximum>last,expanded_finish=prefix..maximum,expanded_total=maximum-start+1,fingerprint=v.fingerprint,
        message=maximum>last and '可扩充当前网段地址池；不会改变已有租约和管理地址。' or '当前连续地址池已到网段边界。需要更大容量时，应规划更大网段或独立业务网络，不能直接发放下一网段地址。'}
end
function M.adapter(c)
    local a={};local u=require('uci').cursor()
    function a.inventory()
        local lan=u:get_all('network','lan') or {};local d=u:get_all('dhcp','lan') or {}
        local simple=lan.proto=='static' and d.interface=='lan' and d.ignore~='1' and not d.dhcp_option and not d.dhcp_option_force and not d.tag and not d.instance and not d.match_tag and not d.networkid
        u:foreach('dhcp','host',function() simple=false end)
        local active=0
        u:foreach('dhcp','dhcp',function(x) if x.ignore~='1' then active=active+1;if x.interface~='lan' then simple=false end end end)
        if active~=1 then simple=false end
        for _,name in ipairs({'network','dhcp'}) do if next(u:changes(name) or {}) then simple=false end end
        return {simple=simple,ip=lan.ipaddr,mask=lan.netmask,start=d.start,limit=d.limit,leasetime=d.leasetime or '12h',
            leases=util.read('/tmp/dhcp.leases',524288),now=os.time(),fingerprint=util.capture('sha256sum /etc/config/network /etc/config/dhcp',1024)}
    end
    function a.save(minutes,limit)
        local before=assert(util.read('/etc/config/dhcp',262144),'dhcp_backup_failed')
        util.atomic(c.state_dir..'/dhcp-settings-backup',before)
        local ok=pcall(function()
            assert(u:set('dhcp','lan','leasetime',minutes..'m'))
            if limit then assert(u:set('dhcp','lan','limit',tostring(limit))) end
            assert(u:commit('dhcp'));assert(util.exec('/etc/init.d/dnsmasq restart >/dev/null 2>&1 && /etc/init.d/dnsmasq running >/dev/null 2>&1'))
            local fresh=require('uci').cursor();assert(fresh:get('dhcp','lan','leasetime')==minutes..'m')
            if limit then assert(tonumber(fresh:get('dhcp','lan','limit'))==limit) end
        end)
        if not ok then
            pcall(function() u:revert('dhcp') end)
            util.atomic('/etc/config/dhcp',before)
            assert(util.exec('/etc/init.d/dnsmasq restart >/dev/null 2>&1 && /etc/init.d/dnsmasq running >/dev/null 2>&1'),'dhcp_rollback_failed')
            error('dhcp_save_failed',0)
        end
    end
    return a
end
function M.inspect(c,a)
    if c.allow_lab_http then return {supported=false,message='演示环境不修改 DHCP。'} end
    return M.plan((a or M.adapter(c)).inventory())
end
function M.apply(c,input,a)
    assert(not c.allow_lab_http,'preview_only')
    assert(input.confirm==true,'dhcp_confirmation_required')
    assert(type(input.minutes)=='number' and input.minutes%1==0 and input.minutes>=2 and input.minutes<=43200,'dhcp_invalid_minutes')
    return util.with_lock('/var/lock/brand-router-state',function()
        assert(not require('brand_router.network_repair').pending(c),'network_repair_busy')
        local update=require('brand_router.updater').status(c);assert(not(update.job and update.job.busy),'state_busy')
        a=a or M.adapter(c);local p=M.inspect(c,a)
        assert(p.supported,'dhcp_manual_required');assert(type(input.fingerprint)=='string' and input.fingerprint==p.fingerprint,'revision_conflict')
        assert(input.expand==nil or type(input.expand)=='boolean','dhcp_invalid_request')
        if input.expand then assert(p.expandable,'dhcp_pool_full') end
        a.save(input.minutes,input.expand and p.expanded_total or nil)
        return M.inspect(c,a)
    end)
end
return M
