-- Customer API. Every protected request rechecks the license and a dedicated rpcd role.
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local util=require 'brand_router.util'
local license=require 'brand_router.license'
local identity=require 'brand_router.identity'
local resources=require 'brand_router.resources'
local telemetry=require 'brand_router.telemetry'
local updates=require 'brand_router.updates'
local updater=require 'brand_router.updater'
local network_probe=require 'brand_router.network_probe'
local business=require 'brand_router.business'
local account=require 'brand_router.panel_account'
local M={}
local function response(code,body,headers)
    return {status=code,body=body,headers=headers or {}}
end
local function error_response(code,name) return response(code,{error=name}) end
local function hex(value,length) return type(value)=='string' and #value==length and not value:find('[^0-9a-f]') end
local function private_dir(path,uid)
    local stat=fs.lstat(path)
    if not stat then assert(fs.mkdir(path,'700'),'private_directory_failed');stat=fs.lstat(path) end
    assert(stat and stat.type=='dir' and stat.uid==uid and stat.modedec==700,'private_directory_required')
end
local function public_status(status)
    return {state=status.state,business_allowed=status.business_allowed,customer_login_allowed=status.customer_login_allowed,
        expires_at=status.expires_at,stop_at=status.stop_at,recovery_allowed=true,features=status.features}
end
function M.create(context,config,backend)
    assert(type(config)=='table' and type(config.origin)=='string','portal_configuration_required')
    local scheme,authority=config.origin:match('^(https?)://([^/]+)$')
    assert(scheme and not authority:find('[%s@#?]'),'invalid_portal_origin')
    if scheme~='https' then
        assert(context.allow_lab_http==true and authority:match('^127%.0%.0%.1:%d+$'),'https_required')
    end
    assert(type(config.customer_username)=='string' and config.customer_username~='root' and
        #config.customer_username>=1 and #config.customer_username<=48 and not config.customer_username:find('[^A-Za-z0-9_.-]'),'dedicated_customer_account_required')
    local name=config.brand_name or '工控机管理系统'
    assert(type(name)=='string' and #name<=120,'invalid_brand_name')
    local ram=context.portal_state_dir or '/tmp/brand-router-portal'
    private_dir(ram,context.private_uid or 0)
    private_dir(ram..'/sessions',context.private_uid or 0)
    -- Cookies are host-scoped, not port-scoped. Isolate disposable HTTP
    -- previews so logging into a QA port cannot replace the user's session.
    local cookie_name=scheme=='https' and '__Host-brand_sid' or ('brand_sid_'..authority:match(':(%d+)$'))
    local secure=scheme=='https' and '; Secure' or ''
    local function cookie(token,max_age)
        return cookie_name..'='..token..'; Path=/; HttpOnly; SameSite=Strict; Max-Age='..max_age..secure
    end
    local function token(request)
        local found
        for key,value in (request.headers.cookie or ''):gmatch('([^;=]+)=([^;]*)') do
            if key:match('^%s*(.-)%s*$')==cookie_name then
                if found or not hex(value,64) then return nil end
                found=value
            end
        end
        return found
    end
    local function destroy(value)
        if not hex(value,64) then return end
        local session=json.parse(util.read(ram..'/sessions/'..value..'.json') or '')
        if session and session.auth~='local' and hex(session.rpcd_sid,32) then pcall(backend.destroy,session.rpcd_sid) end
        fs.unlink(ram..'/sessions/'..value..'.json')
    end
    local function throttle(request,kind,limit,now)
        local address=request.remote_addr or ''
        if #address>64 or address:find('[^0-9a-fA-F:.]') or #address==0 then return false end
        return util.with_lock(ram..'/rate-lock',function()
            local path=ram..'/rates.json'
            local slots=json.parse(util.read(path) or '') or {}
            local count=0
            for key,slot in pairs(slots) do
                if type(slot)~='table' or type(slot.started)~='number' or now>=slot.started+60 or now<slot.started then slots[key]=nil
                else count=count+1 end
            end
            local key=kind..':'..address
            if not slots[key] and count>=128 then return false end
            local state=slots[key] or {started=now,count=0}
            state.count=state.count+1;slots[key]=state;util.atomic(path,json.stringify(slots))
            return state.count<=limit
        end)
    end
    local function authorized(request,now)
        local value=token(request)
        if not value then return nil end
        local session=json.parse(util.read(ram..'/sessions/'..value..'.json') or '')
        if not session or not hex(session.rpcd_sid,32) or session.username~=(session.auth=='local' and 'root' or config.customer_username) or
            type(session.expires_at)~='number' or type(session.created_at)~='number' or (session.expires_at~=0 and now>=session.expires_at) or now<session.created_at-120 then
            destroy(value);return nil
        end
        local a=account.read(context)
        if session.auth=='local' then
            if not a or session.generation~=a.generation then destroy(value);return nil end
        elseif a then destroy(value);return nil
        else
            local access=backend.access(session.rpcd_sid)
            if access==nil then error('portal_unavailable') end
            if not access then destroy(value);return nil end
        end
        request.refresh_cookie=value
        return session,value
    end
    local api={}
    local function handle(request,now)
        now=now or os.time()
        request.headers=request.headers or {}
        local method,path=request.method,request.path
        if request.headers.host~=authority then return error_response(400,'invalid_host') end
        if method~='GET' and method~='POST' then return error_response(405,'method_not_allowed') end
        local allowed={['/api/state']=true,['/api/enrollment']=true,['/api/activate']=true,['/api/login']=true,
            ['/api/dashboard']=true,['/api/logout']=true,['/api/config']=true,['/api/config/change']=true,['/api/config/preview']=true,['/api/fixed/status']=true,['/api/fixed/apply']=true,['/api/update/status']=true,['/api/update/action']=true,['/api/device/status']=true,['/api/network/status']=true,['/api/network/check']=true,['/api/account']=true,['/api/account/change']=true,['/api/account/recover']=true}
        allowed['/api/network/repair']=true;allowed['/api/network/repair-status']=true;
        allowed['/api/dhcp/settings']=true;allowed['/api/node/test']=true;allowed['/api/tailscale/status']=true;allowed['/api/tailscale/install']=true;allowed['/api/tailscale/assist']=true
        if not allowed[path] then return error_response(404,'not_found') end
        local mutating=path=='/api/fixed/apply' or path=='/api/account/change' or path=='/api/account/recover' or path=='/api/network/check' or path=='/api/update/action' or path=='/api/activate' or path=='/api/login' or path=='/api/logout' or path=='/api/config/change' or path=='/api/config/preview'
        mutating=mutating or path=='/api/dhcp/settings' and request.method=='POST' or path=='/api/network/repair' or path=='/api/node/test' or path=='/api/tailscale/install' or path=='/api/tailscale/assist'
        if mutating~=(method=='POST') then return error_response(405,'method_not_allowed') end
        local input={}
        if method=='POST' then
            if request.headers.origin~=config.origin then return error_response(403,'origin_required') end
            local content_type=(request.headers['content-type'] or ''):match('^%s*([^;]+)')
            if content_type~='application/json' then return error_response(415,'json_required') end
            local maximum=path=='/api/update/action' and 3000000 or (path=='/api/config/preview' or path=='/api/config/change') and 131072 or 16384
            if type(request.body)~='string' or #request.body>maximum then return error_response(413,'document_too_large') end
            input=json.parse(request.body)
            if type(input)~='table' then return error_response(400,'invalid_json') end
            if #request.body>16384 and path=='/api/config/change' and input.action~='save_rows' and input.action~='save_mode' then return error_response(413,'document_too_large') end
        end
        local status=license.status(context,context.test_epoch and now or nil)
        if path=='/api/state' then
            return response(200,{brand_name=name,license=public_status(status),customer_account_configured=true,account=account.public(context,config)})
        end
        if path=='/api/enrollment' then
            if not throttle(request,'enrollment',5,now) then return error_response(429,'rate_limited') end
            return response(200,util.with_lock(context.lock_dir or '/var/lock/brand-router-state',function()
                return identity.enrollment(context)
            end))
        end
        if path=='/api/activate' then
            if not throttle(request,'activate',10,now) then return error_response(429,'rate_limited') end
            if type(input.code)~='string' then return error_response(400,'invalid_license') end
            local result=util.with_lock(context.lock_dir or '/var/lock/brand-router-state',function()
                return license.import(input.code,context,context.test_epoch and now or nil)
            end)
            return response(result.state=='active' and 200 or 422,{license=public_status(result)})
        end
        if path=='/api/logout' then
            -- Explicit revocation must not depend on rpcd or license availability.
            -- The private local session plus its CSRF token identifies this login.
            local value=token(request)
            local session=value and json.parse(util.read(ram..'/sessions/'..value..'.json') or '')
            if not session then return error_response(401,'login_required') end
            if not hex(session.csrf,64) or request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            destroy(value);return response(200,{ok=true},{['Set-Cookie']=cookie('',0)})
        end
        if path=='/api/account/recover' then
            if not throttle(request,'recovery',5,now) then return error_response(429,'rate_limited') end
            local ok,result=pcall(account.recover,context,input)
            if not ok then return error_response(422,type(result)=='table' and result.code or 'account_unavailable') end
            destroy(token(request));return response(200,result,{['Set-Cookie']=cookie('',0)})
        end
        -- This gate applies on every request, including a cookie issued before cutoff.
        if not status.customer_login_allowed then
            destroy(token(request));return response(423,{error='authorization_required',license=public_status(status)},
                {['Set-Cookie']=cookie('',0)})
        end
        if path=='/api/login' then
            if not throttle(request,'login',10,now) then return error_response(429,'rate_limited') end
            local a=account.read(context)
            if input.username~=(a and a.username or config.customer_username) or type(input.password)~='string' or #input.password>1024 then
                return error_response(401,'login_failed')
            end
            local rpcd_sid
            if a then
                if not account.verify(context,a,input.password) then return error_response(401,'login_failed') end
                rpcd_sid=util.random_hex(16)
            else
                rpcd_sid=backend.login(input.username,input.password)
                if not hex(rpcd_sid,32) then return error_response(401,'login_failed') end
                if not backend.access(rpcd_sid) then backend.destroy(rpcd_sid);return error_response(403,'customer_role_required') end
            end
            -- A fresh portal cookie never gives the browser an rpcd/LuCI admin token.
            destroy(token(request))
            local value,csrf=util.random_hex(32),util.random_hex(32)
            local created=util.with_lock(ram..'/session-lock',function()
                local index=json.parse(util.read(ram..'/sessions/index.json') or '') or {}
                local count=0
                for sid,expires in pairs(index) do
                    local prior=hex(sid,64) and json.parse(util.read(ram..'/sessions/'..sid..'.json') or '')
                    local revoked=not prior or (a and (prior.auth~='local' or prior.generation~=a.generation)) or (not a and prior.auth=='local')
                    if revoked or type(expires)~='number' or (expires~=0 and now>=expires) or not util.read(ram..'/sessions/'..sid..'.json') then
                        destroy(sid);index[sid]=nil
                    else count=count+1 end
                end
                if count>=64 then return false end
                util.atomic(ram..'/sessions/'..value..'.json',json.stringify({rpcd_sid=rpcd_sid,username=input.username,
                    csrf=csrf,created_at=now,expires_at=0,auth=a and 'local' or nil,generation=a and a.generation or nil}))
                index[value]=0;util.atomic(ram..'/sessions/index.json',json.stringify(index))
                return true
            end)
            if not created then if not a then backend.destroy(rpcd_sid) end;return error_response(503,'session_capacity') end
            return response(200,{username=input.username,csrf=csrf},{['Set-Cookie']=cookie(value,34560000)})
        end
        local session=authorized(request,now)
        if not session then return error_response(401,'login_required') end
        if path=='/api/account' or path=='/api/account/change' then
            if not mutating then return response(200,account.public(context,config)) end
            if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            if not throttle(request,'account-change',5,now) then return error_response(429,'rate_limited') end
            local ok,result=pcall(account.change,context,input,function(value)
                if type(value)~='string' or #value>1024 then return false end
                local sid=backend.login(config.customer_username,value)
                if not hex(sid,32) then return false end
                local valid=backend.access(sid);backend.destroy(sid);return valid
            end,session.generation or 'legacy')
            if not ok then return error_response(422,type(result)=='table' and result.code or 'account_unavailable') end
            destroy(token(request));return response(200,result,{['Set-Cookie']=cookie('',0)})
        end
        if account.public(context,config).first_setup and path~='/api/dashboard' then return error_response(409,'initial_setup_required') end
        if mutating and (path=='/api/config/change' or path=='/api/account/change' or path=='/api/tailscale/assist') and require('brand_router.network_repair').pending(context) then return error_response(409,'network_repair_busy') end
        if path=='/api/tailscale/status' or path=='/api/tailscale/install' or path=='/api/tailscale/assist' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating and request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            if not throttle(request,mutating and 'tailscale-install' or 'tailscale-status',mutating and 3 or 40,now) then return error_response(429,'rate_limited') end
            local ok,result=pcall(function()
                local tool=require 'brand_router.tailscale_tool'
                if not mutating then local value=tool.inspect(context,now);value.assist=require('brand_router.tailscale_assist').inspect(context);return value end
                if path=='/api/tailscale/assist' then return require('brand_router.tailscale_assist').action(context,input) end
                return tool.request(context,input,now,function(id)
                    return util.exec('/sbin/start-stop-daemon -S -b -m -p '..util.quote(tool.root(context)..'/worker.pid')..' -x /usr/bin/lua -- /usr/libexec/brand-tailscale-worker '..util.quote(id)..' >/dev/null 2>&1')
                end)
            end)
            if ok then return response(200,result) end
            local code=tostring(result):match('([a-z_]+)$')
            local known={preview_only=true,tailscale_confirmation_required=true,tailscale_already_installed=true,tailscale_external_install=true,tailscale_busy=true,tailscale_launch_failed=true,tailscale_state_invalid=true,tailscale_stop_failed=true,tailscale_start_failed=true,tailscale_session_active=true,tailscale_not_installed=true,tailscale_action_invalid=true}
            return error_response(409,known[code] and code or 'tailscale_install_failed')
        end
        if path=='/api/dhcp/settings' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if request.method=='POST' and request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            if not throttle(request,'dhcp-settings',12,now) then return error_response(429,'rate_limited') end
            local ok,result=pcall(function()
                local dhcp=require 'brand_router.dhcp_settings'
                return request.method=='POST' and dhcp.apply(context,input) or dhcp.inspect(context)
            end)
            if ok then return response(200,result) end
            local code=tostring(result):match('([a-z_]+)$')
            local known={dhcp_invalid_minutes=true,dhcp_confirmation_required=true,dhcp_manual_required=true,dhcp_pool_full=true,dhcp_save_failed=true,dhcp_rollback_failed=true,revision_conflict=true,network_repair_busy=true,state_busy=true}
            return error_response(409,known[code] and code or 'dhcp_save_failed')
        end
        if path=='/api/device/status' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if not throttle(request,'telemetry',30,now) then return error_response(429,'rate_limited') end
            return response(200,telemetry.inspect(now))
        end
        if path=='/api/network/repair-status' or path=='/api/network/repair' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating and request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            if not throttle(request,'network-repair',12,now) then return error_response(429,'rate_limited') end
            local ctx={};for k,v in pairs(context) do ctx[k]=v end;ctx.repair_host=request.headers.host
            local ok,result=pcall(function()
                local r=require 'brand_router.network_repair'
                return mutating and r.request(ctx,input) or r.inspect(ctx)
            end)
            if ok then return response(200,result) end
            return error_response(409,'network_repair_failed')
        end
        if path=='/api/network/status' or path=='/api/network/check' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating and request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            if not throttle(request,'network-read',20,now) then return error_response(429,'rate_limited') end
            local snapshot=network_probe.inspect(context)
            if not mutating then return response(200,snapshot) end
            local ok,result=pcall(network_probe.check,snapshot,input)
            return ok and response(200,result) or error_response(422,'invalid_subnet')
        end
        if path=='/api/update/status' or path=='/api/update/action' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating then
                if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
                if not throttle(request,'updates',12,now) then return error_response(429,'rate_limited') end
                local ok,result=pcall(updater.request,context,input,now,function(id)
                    return util.exec('/sbin/start-stop-daemon -S -b -m -p '..util.quote(updater.root(context)..'/worker.pid')..' -x /usr/bin/lua -- /usr/libexec/brand-update-worker '..util.quote(id)..' >/dev/null 2>&1')
                end)
                if not ok then return error_response(409,type(result)=='table' and result.code or 'update_failed') end
                return response(200,result)
            end
            local result=updates.inspect(context,now);result.manager=updater.public(updater.status(context))
            if result.manager.enabled then
                result.state='ready';result.source={configured=true};result.history_available=true
                if result.manager.release and result.manager.release.build_id==result.installed.build_id then result.installed.published=true;result.installed.kind='published' end
                local idle=not (result.manager.job and result.manager.job.busy)
                result.capabilities={check=idle,download=idle and result.manager.availability=='available',upload=idle and result.manager.availability=='available',apply=idle and result.manager.staged~=nil,recover=idle and result.manager.recoverable}
            end
            return response(200,result)
        end
        if path=='/api/node/test' then
            local manage=false;for _,f in pairs(status.features or {}) do if f=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
            if not throttle(request,'node_probe',90,now) then return error_response(429,'rate_limited') end
            local ok,result=pcall(require('brand_router.node_probe').test,context,input)
            if not ok then
                local code=tostring(result):match('([a-z_]+)$')
                local known={preview_only=true,node_not_found=true,revision_conflict=true,probe_protocol_unsupported=true,probe_core_required=true,probe_config_invalid=true,state_busy=true}
                return error_response(409,known[code] and code or 'probe_failed')
            end
            return response(200,result)
        end
        if path=='/api/fixed/status' or path=='/api/fixed/apply' then
            local manage=false;for _,f in pairs(status.features or {}) do if f=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating then
                if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
                if not throttle(request,'fixed_apply',6,now) then return error_response(429,'rate_limited') end
            end
            local ok,result=pcall(function()
                local fixed=require 'brand_router.fixed_runtime'
                if mutating then
                    assert(input.confirm==true,'fixed_confirmation_required')
                    return fixed.apply(context,input.revision)
                end
                return fixed.status(context,business.get(context).revision)
            end)
            if not ok then
                local code=type(result)=='table' and result.code or tostring(result):match('([a-z_]+)$')
                local permitted={preview_only=true,authorization_required=true,revision_conflict=true,fixed_core_required=true,fixed_protocol_not_supported=true,fixed_transport_not_supported=true,fixed_bindings_required=true,fixed_existing_lan_only=true,fixed_offload_not_supported=true,fixed_confirmation_required=true}
                return error_response(409,permitted[code] and code or 'fixed_apply_failed')
            end
            return response(200,result)
        end
        if path=='/api/config' or path=='/api/config/change' or path=='/api/config/preview' then
            local manage=false;for _,feature in pairs(status.features or {}) do if feature=='manage' then manage=true end end
            if not manage then return error_response(403,'feature_required') end
            if mutating then
                if request.headers['x-csrf-token']~=session.csrf then return error_response(403,'csrf_required') end
                if not throttle(request,path=='/api/config/preview' and 'preview' or 'configuration',path=='/api/config/preview' and 90 or 30,now) then return error_response(429,'rate_limited') end
            end
            local ok,result=pcall(function()
                if path=='/api/config/preview' then return business.preview(input) end
                if mutating then return business.change(context,input,now) end
                return business.get(context)
            end)
            if not ok then
                local code=type(result)=='table' and result.code or 'configuration_unavailable'
                return response(code=='revision_conflict' and 409 or code=='configuration_unavailable' and 503 or 422,{error=code,row=type(result)=='table' and result.row or nil})
            end
            if path~='/api/config/preview' then
                result.runtime=require('brand_router.fixed_runtime').status(context,result.revision)
                result.client_addresses=require('brand_router.telemetry').inspect_addresses(result.bindings,now)
                local good,dhcp=pcall(require('brand_router.dhcp_settings').inspect,context)
                result.dhcp_summary=good and dhcp or {supported=false,message='当前租约读取失败，请刷新重试。'}
            end
            return response(200,result)
        end
        return response(200,{brand_name=name,username=session.username,csrf=session.csrf,account=account.public(context,config),license=public_status(status),
            resources=resources.inspect(),modules={fixed={enabled=false,stage='configuration_pending'},
                rotation={enabled=false,stage='configuration_pending'},dynamic={enabled=false,stage='configuration_pending'}}})
    end
    function api.handle(request,now)
        request.refresh_cookie=nil
        local result=handle(request,now)
        if request.refresh_cookie and result.status==200 then
            result.headers=result.headers or {}
            if not result.headers['Set-Cookie'] then result.headers['Set-Cookie']=cookie(request.refresh_cookie,34560000) end
        end
        return result
    end
    return api
end
function M.listen(config,site)
    assert(type(config)=='table' and config.enabled==true,'portal_not_enabled')
    assert(type(config.origin)=='string' and config.origin:match('^https://[^/%s@#?]+$'),'https_required')
    assert(type(config.customer_username)=='string' and config.customer_username~='root' and
        #config.customer_username>=1 and #config.customer_username<=48 and not config.customer_username:find('[^A-Za-z0-9_.-]'),'dedicated_customer_account_required')
    local ip,port=tostring(config.listen):match('^([%d.]+):(%d+)$')
    assert(ip and port,'ipv4_listen_required')
    local parts=0
    for part in ip:gmatch('[^.]+') do assert(tonumber(part) and tonumber(part)<=255,'invalid_listen_address');parts=parts+1 end
    assert(parts==4 and ip:match('^%d+%.%d+%.%d+%.%d+$') and ip~='0.0.0.0','specific_listen_address_required')
    port=tonumber(port)
    assert(port>=1024 and port<=65535 and site and site.brand_port==port,'portal_port_must_match_guard')
    assert(tonumber(config.origin:match(':(%d+)$'))==port,'portal_origin_port_mismatch')
    return config.listen
end
return M
