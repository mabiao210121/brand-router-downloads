'use strict';
// Never take a destination from URL parameters or user-provided data.
const localName=/^gkglht(?:-[a-f0-9]{8})?\.local$/i.test(location.hostname);
location.replace(localName?'/cgi-bin/brand-entry':'/index.html');
