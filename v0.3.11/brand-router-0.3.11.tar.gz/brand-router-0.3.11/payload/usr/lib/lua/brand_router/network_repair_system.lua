local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local fs=require 'nixio.fs'
local M={}
local paths={'/etc/config/network','/etc/config/dhcp','/etc/brand-router/portal.json','/etc/brand-router/portal.crt'}
local function read(p) return json.parse(util.read(p,262144) or '') end
local function run(cmd) assert(util.exec('timeout 25 '..cmd..' >/dev/null 2>&1'),'network_repair_command_failed') end
function M.new(c)
    local a={};local dir=require('brand_router.network_repair').root(c)
    function a.verified()
        local site=read('/etc/brand-router/site.json') or {}
        return site.network_repair_verified==true
    end
    function a.boot() return (util.read('/proc/sys/kernel/random/boot_id') or ''):match('%S+') end
    function a.uptime() return assert(tonumber((util.read('/proc/uptime') or ''):match('^[%d.]+'))) end
    function a.host() return c.repair_host end
    function a.sleep(n) require('nixio').nanosleep(n) end
    function a.inventory()
        local u=require('uci').cursor();local lan=u:get_all('network','lan') or {};local dh=u:get_all('dhcp','lan') or {}
        local portal=read('/etc/brand-router/portal.json') or {};local ip,port=tostring(portal.listen):match('^([%d.]+):(%d+)$')
        local s=require('brand_router.network_probe').inspect(c)
        local status=json.parse(util.capture('ubus -t 3 call network.interface.lan status',32768) or '') or {}
        local simple=lan.proto=='static' and status.up==true and type(status['ipv4-address'])=='table' and #status['ipv4-address']==1
            and status['ipv4-address'][1].address==lan.ipaddr and status['ipv4-address'][1].mask==24
            and dh.interface=='lan' and dh.ignore~='1' and dh.start and dh.limit and not lan.gateway and not lan.dns
            and type(port)=='string' and tonumber(port)>=1024 and tonumber(port)<=65535 and portal.origin=='https://'..tostring(portal.listen)
        if type(status.l3_device)~='string' or status.l3_device:find('[^%w_-]') then simple=false end
        for _,kind in ipairs({'route','route6','rule','rule6','bridge-vlan'}) do u:foreach('network',kind,function() simple=false end) end
        u:foreach('network','interface',function(x) if not ({lan=true,wan=true,wan6=true,loopback=true})[x['.name']] then simple=false end end)
        for _,kind in ipairs({'host','domain','ipset','boot','relay'}) do u:foreach('dhcp',kind,function() simple=false end) end
        u:foreach('dhcp','dhcp',function(x) if x.interface~='lan' and x.ignore~='1' then simple=false end end)
        if dh.dhcp_option or dh.dhcp_option_force or dh.ra_flags then simple=false end
        u:foreach('dhcp','dnsmasq',function(x) if x.server or x.address or x.interface or x.listen_address then simple=false end end)
        for _,kind in ipairs({'rule','redirect','nat'}) do u:foreach('firewall',kind,function(x) if x.src_ip or x.dest_ip then simple=false end end) end
        for _,name in ipairs({'network','dhcp','firewall'}) do if next(u:changes(name) or {}) then simple=false end end
        local doc=require('brand_router.business').load(c)
        if next(doc.mode_plans or {}) then simple=false end
        if fs.lstat('/var/lock/brand-fixed') or fs.lstat('/var/lock/brand-router-install') then simple=false end
        local update=require('brand_router.updater').status(c)
        if update.job and update.job.busy then simple=false end
        -- Only observed standard devices; VPNs and extra routed interfaces require manual review.
        local dump=json.parse(util.capture('ubus -t 3 call network.interface dump',65536) or '')
        if not dump then simple=false else
            for _,v in ipairs(dump.interface or {}) do
                if v.up and not ({lan=true,wan=true,wan6=true,loopback=true})[v.interface] then simple=false end
            end
        end
        local fingerprint=util.capture('sha256sum /etc/config/network /etc/config/dhcp /etc/config/firewall /etc/brand-router/portal.json /etc/brand-router/portal.crt',4096)
        if not fingerprint or #fingerprint<320 then simple=false end
        return {simple=simple,ip=lan.ipaddr,mask=lan.netmask,portal_ip=ip,port=port,device=status.l3_device,snapshot=s,fingerprint=fingerprint}
    end
    function a.backup(s)
        local b={files={},fixed=require('brand_router.fixed_runtime').enabled(c)}
        for _,p in ipairs(paths) do
            local st=fs.lstat(p);assert(st and st.type=='reg','network_repair_backup_failed')
            b.files[p]=assert(util.read(p,262144),'network_repair_backup_failed')
        end
        local raw=json.stringify(b);assert(#raw<=240000,'network_repair_backup_large')
        util.atomic(dir..'/backup.json',raw);run('/bin/sync')
    end
    function a.worker_running()
        local result=json.parse(util.capture("ubus -t 2 call service list '{\"name\":\"brand-network-repair\"}'",16384) or '')
        if not result then return true end
        local svc=result['brand-network-repair']
        for _,v in pairs(svc and svc.instances or {}) do if v.running then return true end end
        return false
    end
    function a.launch()
        return util.exec('/etc/init.d/brand-network-repair enable >/dev/null 2>&1') and util.exec('/etc/init.d/brand-network-repair start >/dev/null 2>&1')
    end
    local function refresh()
        local b=assert(read(dir..'/backup.json'))
        if b.fixed then
            run('/usr/libexec/brand-network-repair refresh')
        end
    end
    local function reload(ip)
        run('/etc/init.d/network reload')
        local ready=false
        for i=1,12 do
            local lan=json.parse(util.capture('ubus -t 2 call network.interface.lan status',32768) or '')
            if lan and lan.up and lan['ipv4-address'] and lan['ipv4-address'][1] and lan['ipv4-address'][1].address==ip then ready=true;break end
            a.sleep(1)
        end
        assert(ready,'network_repair_interface_failed')
        local dnsok=pcall(run,'/etc/init.d/dnsmasq restart');local fwok=pcall(run,'/etc/init.d/firewall reload')
        local fixedok=pcall(refresh);run('/etc/init.d/brand-portal restart')
        assert(dnsok and fwok and fixedok,'network_repair_services_failed')
    end
    function a.apply(s)
        local p=read('/etc/brand-router/portal.json');assert(p,'network_repair_config_invalid')
        -- Preserve private key and include both addresses for rollback/reconnection.
        run('/usr/bin/openssl req -x509 -key /etc/brand-router/portal.key -out '..util.quote(dir..'/next.crt')..
            ' -days 3650 -subj /CN=BrandRouter-local -addext '..util.quote('subjectAltName=IP:'..s.old_ip..',IP:'..s.new_ip))
        local u=require('uci').cursor()
        assert(u:set('network','lan','ipaddr',s.new_ip));assert(u:set('network','lan','netmask','255.255.255.0'))
        assert(u:set('dhcp','lan','start','50'));assert(u:set('dhcp','lan','limit','200'))
        assert(u:commit('network'));assert(u:commit('dhcp'))
        p.listen=s.new_ip..':'..s.port;p.origin=s.new_url
        util.atomic('/etc/brand-router/portal.json',json.stringify(p));util.atomic('/etc/brand-router/portal.crt',assert(util.read(dir..'/next.crt')))
        run('/bin/sync');reload(s.new_ip)
        for i=1,6 do if a.healthy(s) then return end;a.sleep(1) end
        error('network_repair_unhealthy')
    end
    function a.restore(s)
        local b=assert(read(dir..'/backup.json'),'network_repair_backup_missing')
        for _,p in ipairs(paths) do assert(type(b.files[p])=='string','network_repair_backup_invalid') end
        for _,p in ipairs(paths) do util.atomic(p,b.files[p]) end
        run('/bin/sync');reload(s.old_ip)
        for i=1,6 do if a.restored(s) then return end;a.sleep(1) end
        error('network_repair_restore_failed')
    end
    local function health(ip,port)
        local lan=json.parse(util.capture('ubus -t 2 call network.interface.lan status',32768) or '')
        if not (lan and lan.up and lan['ipv4-address'] and lan['ipv4-address'][1] and lan['ipv4-address'][1].address==ip) then return false end
        local b=read(dir..'/backup.json')
        if b and b.fixed and not require('brand_router.fixed_runtime').runtime_healthy(c) then return false end
        -- Local certificate can be self-signed; only this locally generated endpoint is probed.
        return util.exec('curl --noproxy "*" -kfsS --connect-timeout 2 --max-time 4 '..util.quote('https://'..ip..':'..port..'/api/state')..' >/dev/null 2>&1')
    end
    function a.healthy(s) return health(s.new_ip,s.port) end
    function a.restored(s) return health(s.old_ip,s.port) end
    return a
end
return M
