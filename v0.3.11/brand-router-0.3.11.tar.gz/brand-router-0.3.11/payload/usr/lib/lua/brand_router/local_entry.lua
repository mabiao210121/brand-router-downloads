-- LAN discovery metadata and narrow integration with the native web landing page.
local util=require 'brand_router.util'
local json=require 'luci.jsonc'
local M={}
local pending='/etc/brand-router/entry-reload-pending'
local function finish_pending()
    if util.read(pending,8)=='1' then
        assert(util.exec('/etc/init.d/uhttpd reload >/dev/null 2>&1'),'entry_reload_failed')
        util.atomic(pending,'0')
    end
end
function M.target(config,site)
    local listen=require('brand_router.portal').listen(config,site)
    local ip,port=listen:match('^([%d.]+):(%d+)$')
    assert(config.origin=='https://'..ip..':'..port,'entry_origin_mismatch')
    return ip,config.origin
end
function M.host_allowed(host)
    host=(host or ''):lower():gsub(':80$',''):gsub(':443$','')
    return host=='gkglht.local' or host:match('^gkglht%-%x%x%x%x%x%x%x%x%.local$')~=nil
end
function M.indexes(existing)
    if existing==nil then return {'brand-entry.html','index.html','index.htm'} end
    if type(existing)=='string' then existing={existing} end
    assert(type(existing)=='table' and #existing>0,'entry_custom_index')
    local first=existing[1]=='brand-entry.html' and existing[2] or existing[1]
    assert(first=='index.html','entry_custom_index')
    local result={'brand-entry.html'}
    for _,v in ipairs(existing) do
        assert(v=='brand-entry.html' or v=='index.html' or v=='index.htm','entry_custom_index')
        if v~='brand-entry.html' then result[#result+1]=v end
    end
    return result
end
function M.setup()
    local c=require('uci').cursor()
    assert(c:get('uhttpd','main','home')=='/www','entry_custom_webroot')
    local previous=c:get('uhttpd','main','index_page')
    local desired=M.indexes(previous)
    local id=util.read('/etc/brand-router/entry-id',32)
    if not id then id=util.random_hex(4);util.atomic('/etc/brand-router/entry-id',id) end
    assert(id:match('^%x%x%x%x%x%x%x%x$'),'entry_id_invalid')
    if json.stringify(previous)~=json.stringify(desired) then
        local backup='/etc/brand-router/entry-native-index.json'
        if not util.read(backup,4096) then util.atomic(backup,json.stringify({present=previous~=nil,value=previous})) end
        util.atomic(pending,'1')
        c:set('uhttpd','main','index_page',desired);assert(c:commit('uhttpd'),'entry_commit_failed')
        if not util.exec('/etc/init.d/uhttpd reload >/dev/null 2>&1') then
            if previous~=nil then c:set('uhttpd','main','index_page',previous)
            else c:delete('uhttpd','main','index_page') end
            assert(c:commit('uhttpd'),'entry_rollback_failed')
            util.exec('/etc/init.d/uhttpd reload >/dev/null 2>&1')
            error('entry_reload_failed')
        end
        util.atomic(pending,'0')
    end
    finish_pending()
    return 'gkglht-'..id..'.local'
end
function M.remove()
    local c=require('uci').cursor()
    local current=c:get('uhttpd','main','index_page')
    if type(current)=='string' then current={current} end
    if type(current)~='table' then finish_pending();return end
    local filtered,found={},false
    for _,v in ipairs(current) do if v=='brand-entry.html' then found=true else filtered[#filtered+1]=v end end
    if not found then finish_pending();return end
    util.atomic(pending,'1')
    local backup=json.parse(util.read('/etc/brand-router/entry-native-index.json',4096) or '')
    if backup and json.stringify(current)==json.stringify(M.indexes(backup.value)) then
        if backup.present then c:set('uhttpd','main','index_page',backup.value) else c:delete('uhttpd','main','index_page') end
    elseif #filtered>0 then c:set('uhttpd','main','index_page',filtered)
    else c:delete('uhttpd','main','index_page') end
    assert(c:commit('uhttpd'),'entry_restore_failed')
    if not util.exec('/etc/init.d/uhttpd reload >/dev/null 2>&1') then
        c:set('uhttpd','main','index_page',current)
        assert(c:commit('uhttpd'),'entry_rollback_failed')
        util.exec('/etc/init.d/uhttpd reload >/dev/null 2>&1')
        error('entry_reload_failed')
    end
    util.atomic(pending,'0')
end
return M
