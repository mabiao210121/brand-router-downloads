local json=require 'luci.jsonc'
local util=require 'brand_router.util'
local codec=require 'brand_router.codec'
local license=require 'brand_router.license'
local identity=require 'brand_router.identity'
local clock=require 'brand_router.clock'
local M={URL='https://license.wanyushoperp.com/v1/refresh',INTERVAL=300}
local attempted
function M.refresh(context,transport)
    local now,reason=clock.effective(context)
    if reason then return {state=reason} end
    local _,claims=license.status(context,now)
    if not claims or claims.mode~='online' then return {state='offline_authorization'} end
    local device=assert(identity.current(context),'device_identity_unavailable')
    local nonce=util.random_hex(16)
    local payload={schema=1,device_id=device.device_id,hardware_hash=device.hardware_hash,
        public_key=device.public_key,issued_at=now,nonce=nonce,license_id=claims.license_id}
    local dir=util.tempdir(context.temp_parent or '/tmp')
    local ok,result=pcall(function()
        local raw=json.stringify(payload)
        util.write(dir..'/message','BR-REQUEST/1\0'..raw)
        assert(util.exec(util.quote(context.openssl or '/usr/bin/openssl')..' pkeyutl -sign -rawin -inkey '..util.quote(context.state_dir..'/device.key')..' -in '..util.quote(dir..'/message')..' -out '..util.quote(dir..'/signature')..' >/dev/null 2>&1'),'request_sign_failed')
        local request={format='BRREQ1',payload=codec.encode(raw),signature=codec.encode(assert(util.read(dir..'/signature',64)))}
        local response
        if transport then response=transport(request) else
            util.write(dir..'/request',json.stringify(request))
            -- Fixed HTTPS destination; no redirects, proxy environment or certificate bypass.
            assert(util.exec('curl --noproxy "*" --fail --silent --proto "=https" --connect-timeout 3 --max-time 5 --max-filesize 16384 -H "Content-Type: application/json" --data-binary @'..util.quote(dir..'/request')..' '..util.quote(M.URL)..' -o '..util.quote(dir..'/response')..' 2>/dev/null'),'server_unavailable')
            response=json.parse(util.read(dir..'/response',16384) or '')
        end
        local fresh=assert(license.verify(response,context),'invalid_response')
        assert(fresh.mode=='online' and fresh.license_id==claims.license_id and fresh.request_nonce==nonce,'response_mismatch')
        return util.with_lock(context.lock_dir or '/var/lock/brand-router-state',function()
            local _,current=license.status(context,now)
            assert(current and current.license_id==claims.license_id and current.mode=='online','authorization_changed')
            local value=license.import(response,context,now)
            assert(value.state=='active' or value.state=='revoked' or value.state=='expired_cutoff' or value.state=='offline_limit','response_rejected')
            return {state=value.state,checked_at=now,lease_until=value.lease_until}
        end)
    end)
    util.cleanup(dir,{'message','signature','request','response'})
    if not ok then return {state='check_failed',checked_at=now} end
    return result
end
function M.tick(context)
    local now=os.time()
    if attempted and now>=attempted and now-attempted<M.INTERVAL then return end
    attempted=now
    local ok,value=pcall(M.refresh,context)
    util.atomic('/tmp/brand-router-online.json',json.stringify(ok and value or {state='check_failed',checked_at=now}))
end
return M
