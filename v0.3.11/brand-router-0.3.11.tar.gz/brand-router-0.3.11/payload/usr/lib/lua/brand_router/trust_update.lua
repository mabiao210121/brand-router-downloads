-- Explicit root-maintenance import. Adds a key authenticated by existing trust;
-- never removes old trust or changes activation state.
local M={}
local util=require 'brand_router.util'
local codec=require 'brand_router.codec'
local json=require 'luci.jsonc'
function M.import(c,input)
    assert(type(input)=='table' and input.format=='BRTRUST1','invalid_trust_update')
    local old=input.key_id
    assert(type(old)=='string' and #old<=48 and old:match('^[A-Za-z0-9_-]+$'),'invalid_trust_update')
    local raw,sig=codec.decode(input.payload),codec.decode(input.signature,64)
    assert(raw and #raw<=4096 and sig and #sig==64,'invalid_trust_update')
    assert(util.read(c.key_dir..'/'..old..'.pub',8192),'unknown_key')
    local doc=json.parse(raw)
    assert(type(doc)=='table' and type(doc.key_id)=='string' and #doc.key_id<=48 and doc.key_id:match('^[A-Za-z0-9_-]+$'),'invalid_trust_update')
    assert(type(doc.public_key_pem)=='string' and #doc.public_key_pem<=4096 and not doc.public_key_pem:find('PRIVATE'),'invalid_trust_update')
    local dir=util.tempdir(c.temp_parent or '/tmp')
    local ok,result=pcall(function()
        util.write(dir..'/message','BR-TRUST/1\0'..old..'\0'..raw)
        util.write(dir..'/signature',sig)
        util.write(dir..'/key.pub',doc.public_key_pem)
        local openssl=util.quote(c.openssl or '/usr/bin/openssl')
        assert(util.exec(openssl..' pkeyutl -verify -rawin -pubin -inkey '..util.quote(c.key_dir..'/'..old..'.pub')..' -in '..util.quote(dir..'/message')..' -sigfile '..util.quote(dir..'/signature')..' >/dev/null 2>&1'),'invalid_signature')
        local desc=util.capture(openssl..' pkey -pubin -in '..util.quote(dir..'/key.pub')..' -text -noout 2>/dev/null',8192)
        assert(desc and desc:find('ED25519'),'wrong_key_type')
        local lock=assert(require('nixio').open(c.lock_dir..'-trust.fd','w','600'),'state_busy')
        if not lock:lock('tlock') then lock:close();error('state_busy') end
        local saved,value=pcall(function()
            local dest=c.key_dir..'/'..doc.key_id..'.pub'
            local existing=util.read(dest,8192)
            assert(not existing or existing==doc.public_key_pem,'key_id_conflict')
            if not existing then util.atomic(dest,doc.public_key_pem) end
            return {imported=true,key_id=doc.key_id}
        end)
        lock:close()
        if not saved then error(value,0) end
        return value
    end)
    util.cleanup(dir,{'message','signature','key.pub'})
    if not ok then error('trust_update_failed',0) end
    return result
end
return M
