-- Optional userspace support session. Never changes host routes, DNS or firewall.
local util=require 'brand_router.util'
local fs=require 'nixio.fs'
local json=require 'luci.jsonc'
local tool=require 'brand_router.tailscale_tool'
local M={}
local function read(c,name) return json.parse(util.read(tool.root(c)..'/'..name..'.json',32768) or '') end
local function save(c,name,value) util.atomic(tool.root(c)..'/'..name..'.json',json.stringify(value)) end
local function uptime() return tonumber((util.read('/proc/uptime',128) or ''):match('^([%d.]+)')) end
function M.valid(lease,now,up,boot)
    return type(lease)=='table' and lease.enabled==true and type(up)=='number' and
        type(lease.deadline)=='number' and type(lease.uptime)=='number' and
        type(lease.expires_at)=='number' and lease.boot==boot and
        up>=lease.uptime and up<lease.deadline and now<lease.expires_at
end
function M.active(c)
    local lease=read(c,'assist-lease')
    return M.valid(lease,os.time(),uptime(),util.read('/proc/sys/kernel/random/boot_id',128)) and lease or nil
end
function M.directory(c)
    assert(M.active(c),'tailscale_session_expired')
    local installed=tool.current(c);assert(installed,'tailscale_not_installed')
    return tool.root(c)..'/'..installed.generation
end
function M.public(raw)
    raw=type(raw)=='table' and raw or {}
    local result={state='connecting'}
    if raw.BackendState=='NeedsLogin' then result.state='needs_login'
    elseif raw.BackendState=='NeedsMachineAuth' then result.state='needs_approval'
    elseif raw.BackendState=='Running' then result.state='connected'
    elseif raw.BackendState=='Stopped' then result.state='stopped' end
    if result.state=='needs_login' and type(raw.AuthURL)=='string' and #raw.AuthURL<2048 and raw.AuthURL:match('^https://login%.tailscale%.com/a/[A-Za-z0-9_%-]+$') then result.auth_url=raw.AuthURL end
    if result.state=='needs_login' and not result.auth_url then result.state='awaiting_auth' end
    for _,ip in pairs(type(raw.TailscaleIPs)=='table' and raw.TailscaleIPs or {}) do
        if type(ip)=='string' then
            local a,b,d,e=ip:match('^(%d+)%.(%d+)%.(%d+)%.(%d+)$')
            if a=='100' and tonumber(b)>=64 and tonumber(b)<=127 and tonumber(d)<=255 and tonumber(e)<=255 then result.ip=ip;break end
        end
    end
    if result.state=='connected' and result.ip then result.command='ssh root@'..result.ip end
    return result
end
function M.inspect(c)
    local lease=M.active(c)
    if not lease then
        if M.closed(c) then return {state='off',enabled=false} end
        return {state='stop_unconfirmed',enabled=true}
    end
    local result=read(c,'assist-status') or {state='starting'}
    if result.session~=lease.id or os.time()-(result.checked_at or 0)>20 then result={state='connecting'} end
    -- Re-filter persisted status too: old versions or diagnostics may contain
    -- identity, peer or host fields. Never trust a cached record as public data.
    local states={starting=true,connecting=true,awaiting_auth=true,needs_login=true,needs_approval=true,connected=true,stopped=true}
    local state=states[result.state] and result.state or 'connecting'
    local mapped={needs_login='NeedsLogin',needs_approval='NeedsMachineAuth',connected='Running',stopped='Stopped'}
    local clean=M.public({BackendState=mapped[state],AuthURL=result.auth_url,TailscaleIPs={result.ip}})
    if state=='starting' or state=='awaiting_auth' then clean.state=state end
    clean.enabled=true;clean.expires_at=lease.expires_at
    return clean
end
function M.owned(c,pid)
    local raw=util.read('/proc/'..pid..'/cmdline',4096)
    if raw==nil then
        local status=util.read('/proc/'..pid..'/status',4096) or ''
        if status:match('\nKthread:%s*1\n') or status:match('\nState:%s*Z') then return false end
        -- Only a proven disappearance is absence; failed reads are unknown.
        local stat,a,b=fs.stat('/proc/'..pid)
        if not stat and (a==2 or b==2 or a==3 or b==3) then return false end
        return nil
    end
    local first=raw:match('^[^%z]+') or ''
    local prefix=tool.root(c)..'/'
    local generation=first:sub(1,#prefix)==prefix and first:sub(#prefix+1):match('^([a-f0-9]+)/tailscaled$')
    return generation and #generation==32 or false
end
function M.runtime(c)
    local raw=json.parse(util.capture([[ubus -t 2 call service list '{"name":"brand-assist"}' 2>/dev/null]],32768) or '')
    local ok,iterator=pcall(fs.dir,'/proc')
    if type(raw)~='table' or not ok or type(iterator)~='function' then return {known=false} end
    local pids={};local known=true
    for name in iterator do
        if name:match('^%d+$') then
            local owned=M.owned(c,name)
            if owned==nil then known=false elseif owned then pids[#pids+1]=tonumber(name) end
        end
    end
    return {known=known,present=raw['brand-assist']~=nil,pids=pids}
end
function M.closed(c)
    local state=M.runtime(c)
    return state.known and not state.present and #state.pids==0
end
function M.stop(c)
    -- Disk failure cannot prevent cutoff. Check invalidation only AFTER every
    -- shutdown path has run, so callers cannot restart a stale active lease.
    local invalidated=pcall(function() save(c,'assist-lease',{enabled=false}) end)
    if not invalidated then invalidated=fs.unlink(tool.root(c)..'/assist-lease.json')==true end
    util.exec('/etc/init.d/brand-assist stop >/dev/null 2>&1')
    if not M.closed(c) then
        -- Independent fallback when the init script fails. Remove procd ownership
        -- before reaping an orphan so it cannot respawn after reporting closed.
        util.exec([[ubus -t 2 call service delete '{"name":"brand-assist"}' >/dev/null 2>&1]])
        local state=M.runtime(c)
        if state.present==false and state.pids then
            for _,pid in ipairs(state.pids) do
                if M.owned(c,tostring(pid)) then require('nixio').kill(pid,15) end
            end
            if #state.pids>0 then require('nixio').nanosleep(0,200000000) end
            for _,pid in ipairs(state.pids) do
                if M.owned(c,tostring(pid)) then require('nixio').kill(pid,9) end
            end
        end
    end
    -- procd deletion is asynchronous: a service may remain while its daemon
    -- handles SIGTERM (default grace is five seconds). Verify after that grace.
    local stopped=M.closed(c)
    for _=1,30 do
        if stopped then break end
        require('nixio').nanosleep(0,200000000)
        stopped=M.closed(c)
    end
    if stopped then fs.unlink(tool.root(c)..'/assist-status.json') end
    return stopped and invalidated
end
-- iStoreOS does not ship GNU timeout. Fork only our fixed CLI, then reap it;
-- never leave a shell parent or depend on a missing optional utility.
function M.capture(c,command)
    local nixio=require 'nixio'
    local path=tool.root(c)..'/cli-output'
    util.write(path,'')
    local pid=assert(nixio.fork(),'tailscale_cli_failed')
    if pid==0 then
        nixio.exec('/bin/sh','-c','exec '..command..' > '..util.quote(path)..' 2>/dev/null')
        os.exit(127)
    end
    local exited=false
    for _=1,30 do
        if nixio.waitpid(pid,'nohang')==pid then exited=true;break end
        nixio.nanosleep(0,100000000)
    end
    if not exited then nixio.kill(pid,9);nixio.waitpid(pid) end
    local raw=util.read(path,262144);fs.unlink(path)
    return raw
end
function M.action(c,input)
    assert(not c.allow_lab_http,'preview_only')
    assert(input.confirm==true,'tailscale_confirmation_required')
    local root=tool.root(c)
    if input.action=='stop' then
        -- Stopping must work even when directory permissions or a stale lock
        -- prevent writes. Starting still requires the serialized writable path.
        local ok,stopped=pcall(util.with_lock,root..'/assist-lock',function() return M.stop(c) end)
        if not ok then stopped=M.stop(c) end
        assert(stopped,'tailscale_stop_failed')
        return {accepted=true,state='off'}
    end
    util.private_dir(root,c.private_uid)
    return util.with_lock(root..'/assist-lock',function()
        assert(input.action=='start','tailscale_action_invalid')
        assert(tool.current(c),'tailscale_not_installed')
        assert(not M.active(c),'tailscale_session_active')
        assert(M.stop(c),'tailscale_stop_failed')
        local up=assert(uptime(),'tailscale_clock_failed')
        local boot=assert(util.read('/proc/sys/kernel/random/boot_id',128),'tailscale_clock_failed')
        save(c,'assist-lease',{id=util.random_hex(16),enabled=true,uptime=up,deadline=up+1800,boot=boot,expires_at=os.time()+1800})
        fs.unlink(root..'/assist-status.json')
        if not util.exec('/etc/init.d/brand-assist start >/dev/null 2>&1') then
            M.stop(c);error('tailscale_start_failed')
        end
        return {accepted=true,state='starting'}
    end)
end
function M.watch(c)
    local root=tool.root(c);local dir=M.directory(c)
    local cli=util.quote(dir..'/tailscale')..' --socket='..util.quote(root..'/tailscaled.sock')
    local up_attempts=0
    while true do
        local lease=M.active(c)
        if not lease then
            -- Never leave after a failed cutoff; procd also restarts a killed monitor.
            if M.stop(c) then return end
        else
        local raw=json.parse(M.capture(c,cli..' status --json --peers=false') or '')
        if raw and (raw.BackendState=='Stopped' or (raw.BackendState=='NeedsLogin' and (not raw.AuthURL or raw.AuthURL=='')) or raw.BackendState=='NoState') and up_attempts==0 then
            up_attempts=up_attempts+1
            M.capture(c,cli..' up --timeout=2s --reset --accept-dns=false --accept-routes=false --netfilter-mode=off --ssh=false --hostname=brand-support')
        end
        local result=M.public(raw);result.session=lease.id;result.checked_at=os.time();save(c,'assist-status',result)
        end
        require('nixio').nanosleep(2)
    end
end
return M
