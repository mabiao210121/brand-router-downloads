-- Operator-triggered application updates. No automatic checks, firmware flash or network edits.
local json=require 'luci.jsonc'
local util=require 'brand_router.util'
local fs=require 'nixio.fs'
local codec=require 'brand_router.codec'
local M={BASE='https://raw.githubusercontent.com/mabiao210121/brand-router-downloads/main',MAX_PACKAGE=2097152}
local function fail(code) error({code=code},0) end
local function validhex(s) return type(s)=='string' and #s==64 and s:match('^[0-9a-f]+$') end
function M.manifest(value)
    if type(value)~='table' or value.schema~=1 or type(value.version)~='string' or not value.version:match('^%d+%.%d+%.%d+$') or #value.version>32
        or not validhex(value.build_id) or not validhex(value.sha256) or type(value.bytes)~='number' or value.bytes%1~=0 or value.bytes<1 or value.bytes>M.MAX_PACKAGE
        or value.target~='iStoreOS 24.10 x86_64' or type(value.notes)~='string' or #value.notes>4000 then fail('invalid_release_metadata') end
    return {schema=1,version=value.version,build_id=value.build_id,sha256=value.sha256,bytes=value.bytes,target=value.target,notes=value.notes}
end
function M.root(context) return context.update_root or '/etc/brand-router/updates' end
function M.read(root,name) return json.parse(util.read(root..'/'..name..'.json',32768) or '') end
function M.save(root,name,value) util.atomic(root..'/'..name..'.json',json.stringify(value)) end
function M.installed() return json.parse(util.read('/usr/share/brand-router/build.json',4096) or '') or {} end
function M.compare(a,b)
    if a==b then return 0 end
    local function parts(v) local x,y,z=(v or ''):match('^(%d+)%.(%d+)%.(%d+)$');return x and {tonumber(x),tonumber(y),tonumber(z)} end
    a,b=parts(a),parts(b);if not a or not b then return nil end
    for i=1,3 do if a[i]~=b[i] then return a[i]>b[i] and 1 or -1 end end
    return 0
end
function M.status(context)
    if context.allow_lab_http then return {enabled=false,reason='preview_only',history={}} end
    local root=M.root(context);local job=M.read(root,'job');local boot=util.read('/proc/sys/kernel/random/boot_id',128)
    if job and job.busy and job.boot~=boot then job.busy=false;job.phase='interrupted';job.error='update_interrupted';M.save(root,'job',job) end
    local release=M.read(root,'release');if release then local ok,v=pcall(M.manifest,release);release=ok and v or nil end
    local staged=M.read(root,'staged');local installed=M.installed();local relation=release and M.compare(release.version,installed.version)
    local package=fs.lstat(root..'/staging/package.tar.gz')
    if staged and (not package or package.type~='reg' or package.size~=staged.bytes) then staged=nil end
    local history=M.read(root,'history') or {};local recovery=M.read(root,'recovery')
    return {enabled=true,source=M.BASE..'/stable.json',job=job,release=release,history=history,last_check=M.read(root,'last-check'),
        staged=staged and release and staged.sha256==release.sha256 and staged or nil,
        availability=not release and 'unchecked' or installed.build_id==release.build_id and 'current' or relation==1 and 'available' or 'installed_not_older',
        recoverable=recovery and recovery.backup_id~=nil and (not fs.lstat((context.state_dir or '/etc/brand-router/state')..'/panel-account.json') or recovery.account_schema==1) and (not fs.lstat((context.fixed_root or '/etc/brand-router/fixed')..'/current.json') or recovery.fixed_schema==1) or false,upload_limit=M.MAX_PACKAGE}
end
-- Customer responses are projections, never internal job/state records.
function M.public(value)
    local function pick(raw,keys)
        if type(raw)~='table' then return nil end
        local out={};for _,key in ipairs(keys) do
            local v=raw[key]
            local code=key=='action' or key=='phase' or key=='error' or key=='reason' or key=='availability'
            if code then
                if type(v)=='string' and #v<=64 and v:match('^[a-z_]+$') then out[key]=v end
            elseif type(v)=='string' or type(v)=='number' or type(v)=='boolean' then out[key]=v end
        end;return out
    end
    local out=pick(value,{'enabled','reason','availability','recoverable','upload_limit'}) or {}
    out.job=pick(value.job,{'action','phase','busy','started_at','finished_at','error'})
    out.last_check=pick(value.last_check,{'at'})
    out.release=pick(value.release,{'version','build_id','bytes','target','notes'})
    out.staged=pick(value.staged,{'version','build_id','bytes'})
    out.history={};for i,row in ipairs(value.history or {}) do
        if i>10 then break end;out.history[#out.history+1]=pick(row,{'action','phase','error','at'})
    end
    return out
end
function M.request(context,input,now,launch)
    if require('brand_router.network_repair').pending(context) then fail('network_repair_busy') end
    if context.allow_lab_http then fail('preview_only') end
    local action=input.action;local allowed={check=true,prepare=true,upload=true,apply=true,upgrade=true,recover=true}
    if not allowed[action] then fail('invalid_update_action') end
    local root=M.root(context);util.private_dir(root,context.private_uid)
    local lock=root..'/request-lock'
    return util.with_lock(lock,function()
        local status=M.status(context)
        if status.job and status.job.busy then fail('update_busy') end
        local release=status.release
        if action~='check' and action~='recover' then
            if not release then fail('check_release_first') end
            if input.build_id~=release.build_id then fail('release_changed') end
            if status.availability~='available' then fail('no_newer_release') end
        end
        if action=='upgrade' and input.confirm~=true then fail('update_confirmation_required') end
        if action=='apply' and (not status.staged or input.confirm~=true) then fail('update_confirmation_required') end
        if action=='recover' and (not status.recoverable or input.confirm~=true) then fail('recovery_unavailable') end
        local upload
        if action=='upload' then
            upload=codec.decode(input.package,M.MAX_PACKAGE)
            if not upload or #upload~=release.bytes then fail('invalid_update_upload') end
        end
        local job={id=util.random_hex(16),action=action,phase='queued',busy=true,started_at=now,boot=util.read('/proc/sys/kernel/random/boot_id',128)}
        if upload then util.atomic(root..'/upload.bin',upload) end
        M.save(root,'job',job)
        if not launch(job.id) then job.busy=false;job.phase='failed';job.error='update_start_failed';M.save(root,'job',job);fail('update_start_failed') end
        return {accepted=true,job_id=job.id}
    end)
end
return M
